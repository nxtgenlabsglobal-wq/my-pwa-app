import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  writeBatch,
} from 'firebase/firestore';
import { db, auth } from '../firebase/config';
import { handleFirestoreError, OperationType } from '../firebase/firestoreErrors';
import {
  Student,
  Batch,
  AttendanceRecord,
  FeePayment,
  InstituteSettings,
  ClassTest,
  TestResult,
  SyncStatus,
} from '../types';
import {
  getStoredData,
  saveStoredData,
  getOfflineQueue,
  saveOfflineQueue,
  OfflineMutation,
} from '../utils/storage';

type SyncCallback = (data: {
  students: Student[];
  batches: Batch[];
  attendance: AttendanceRecord[];
  payments: FeePayment[];
  settings: InstituteSettings;
  tests: ClassTest[];
  testResults: TestResult[];
}) => void;

type StatusCallback = (status: SyncStatus, message?: string) => void;

class SyncService {
  private ownerId: string | null = null;
  private unsubscribers: (() => void)[] = [];
  private onDataSynced: SyncCallback | null = null;
  private onStatusChange: StatusCallback | null = null;
  private isSyncing = false;
  private status: SyncStatus = 'offline';

  constructor() {
    // Listen for browser online / offline events
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => {
        this.updateStatus('syncing', 'Network reconnected. Syncing pending data...');
        this.processOfflineQueue();
      });
      window.addEventListener('offline', () => {
        this.updateStatus('offline', 'Working offline. Changes are saved locally.');
      });
    }
  }

  public setCallbacks(dataCallback: SyncCallback, statusCallback: StatusCallback) {
    this.onDataSynced = dataCallback;
    this.onStatusChange = statusCallback;
  }

  private updateStatus(status: SyncStatus, message?: string) {
    this.status = status;
    if (this.onStatusChange) {
      this.onStatusChange(status, message);
    }
  }

  public getStatus(): SyncStatus {
    return this.status;
  }

  /**
   * Initializes real-time sync when user logs in
   */
  public async initUserSync(ownerId: string) {
    this.ownerId = ownerId;
    this.cleanup();

    if (!navigator.onLine) {
      this.updateStatus('offline', 'Operating in offline mode.');
      return;
    }

    this.updateStatus('syncing', 'Connecting to cloud database...');

    try {
      // 1. First-time setup check: determine if cloud has data
      const studentsPath = `centers/${ownerId}/students`;
      const cloudStudentsSnap = await getDocs(collection(db, studentsPath));

      const localData = getStoredData();

      if (cloudStudentsSnap.empty) {
        // Cloud is empty for this owner: seed/migrate local data to cloud
        await this.uploadLocalDataToCloud(ownerId, localData);
      } else {
        // Cloud has data: fetch and merge with local
        await this.pullInitialCloudData(ownerId, localData);
      }

      // 2. Set up real-time snapshot listeners for bidirectional synchronization
      this.setupListeners(ownerId);

      // 3. Process any pending offline mutations
      await this.processOfflineQueue();

      this.updateStatus('synced', 'All changes synchronized with cloud.');
    } catch (err: any) {
      console.error('Error during initUserSync:', err);
      this.updateStatus('error', err?.message || 'Sync connection failed.');
    }
  }

  private setupListeners(ownerId: string) {
    // Listen to Settings
    const settingsPath = `centers/${ownerId}/settings/main`;
    const unsubSettings = onSnapshot(
      doc(db, settingsPath),
      (docSnap) => {
        if (docSnap.exists()) {
          const cloudSettings = docSnap.data() as InstituteSettings;
          saveStoredData({ settings: cloudSettings });
        }
      },
      (error) => handleFirestoreError(error, OperationType.GET, settingsPath)
    );
    this.unsubscribers.push(unsubSettings);

    // Listen to Students
    const studentsPath = `centers/${ownerId}/students`;
    const unsubStudents = onSnapshot(
      collection(db, studentsPath),
      (snap) => {
        const cloudStudents: Student[] = [];
        snap.forEach((d) => cloudStudents.push(d.data() as Student));
        if (cloudStudents.length > 0) {
          saveStoredData({ students: cloudStudents });
          this.triggerDataUpdate();
        }
      },
      (error) => handleFirestoreError(error, OperationType.GET, studentsPath)
    );
    this.unsubscribers.push(unsubStudents);

    // Listen to Batches
    const batchesPath = `centers/${ownerId}/batches`;
    const unsubBatches = onSnapshot(
      collection(db, batchesPath),
      (snap) => {
        const cloudBatches: Batch[] = [];
        snap.forEach((d) => cloudBatches.push(d.data() as Batch));
        if (cloudBatches.length > 0) {
          saveStoredData({ batches: cloudBatches });
          this.triggerDataUpdate();
        }
      },
      (error) => handleFirestoreError(error, OperationType.GET, batchesPath)
    );
    this.unsubscribers.push(unsubBatches);

    // Listen to Attendance
    const attendancePath = `centers/${ownerId}/attendance`;
    const unsubAttendance = onSnapshot(
      collection(db, attendancePath),
      (snap) => {
        const cloudAttendance: AttendanceRecord[] = [];
        snap.forEach((d) => cloudAttendance.push(d.data() as AttendanceRecord));
        if (cloudAttendance.length > 0) {
          saveStoredData({ attendance: cloudAttendance });
          this.triggerDataUpdate();
        }
      },
      (error) => handleFirestoreError(error, OperationType.GET, attendancePath)
    );
    this.unsubscribers.push(unsubAttendance);

    // Listen to Payments
    const paymentsPath = `centers/${ownerId}/payments`;
    const unsubPayments = onSnapshot(
      collection(db, paymentsPath),
      (snap) => {
        const cloudPayments: FeePayment[] = [];
        snap.forEach((d) => {
          const item = d.data() as FeePayment;
          // Ensure Cash Only
          cloudPayments.push({ ...item, paymentMode: 'Cash' });
        });
        if (cloudPayments.length > 0) {
          saveStoredData({ payments: cloudPayments });
          this.triggerDataUpdate();
        }
      },
      (error) => handleFirestoreError(error, OperationType.GET, paymentsPath)
    );
    this.unsubscribers.push(unsubPayments);

    // Listen to Tests
    const testsPath = `centers/${ownerId}/tests`;
    const unsubTests = onSnapshot(
      collection(db, testsPath),
      (snap) => {
        const cloudTests: ClassTest[] = [];
        snap.forEach((d) => cloudTests.push(d.data() as ClassTest));
        if (cloudTests.length > 0) {
          saveStoredData({ tests: cloudTests });
          this.triggerDataUpdate();
        }
      },
      (error) => handleFirestoreError(error, OperationType.GET, testsPath)
    );
    this.unsubscribers.push(unsubTests);

    // Listen to Test Results
    const testResultsPath = `centers/${ownerId}/testResults`;
    const unsubResults = onSnapshot(
      collection(db, testResultsPath),
      (snap) => {
        const cloudResults: TestResult[] = [];
        snap.forEach((d) => cloudResults.push(d.data() as TestResult));
        if (cloudResults.length > 0) {
          saveStoredData({ testResults: cloudResults });
          this.triggerDataUpdate();
        }
      },
      (error) => handleFirestoreError(error, OperationType.GET, testResultsPath)
    );
    this.unsubscribers.push(unsubResults);
  }

  private triggerDataUpdate() {
    if (this.onDataSynced) {
      const current = getStoredData();
      this.onDataSynced(current);
    }
  }

  /**
   * Uploads local dataset to cloud for first-time owner login
   */
  private async uploadLocalDataToCloud(ownerId: string, localData: ReturnType<typeof getStoredData>) {
    const batch = writeBatch(db);

    // Settings
    const settingsRef = doc(db, `centers/${ownerId}/settings/main`);
    batch.set(settingsRef, {
      ...localData.settings,
      updatedAt: new Date().toISOString(),
    });

    // Batches
    localData.batches.forEach((b) => {
      const ref = doc(db, `centers/${ownerId}/batches`, b.id);
      batch.set(ref, { ...b, updatedAt: b.updatedAt || new Date().toISOString() });
    });

    // Students
    localData.students.forEach((s) => {
      const ref = doc(db, `centers/${ownerId}/students`, s.id);
      batch.set(ref, { ...s, updatedAt: s.updatedAt || new Date().toISOString() });
    });

    // Attendance
    localData.attendance.forEach((a) => {
      const ref = doc(db, `centers/${ownerId}/attendance`, a.id);
      batch.set(ref, { ...a, updatedAt: a.updatedAt || new Date().toISOString() });
    });

    // Payments (Cash Only)
    localData.payments.forEach((p) => {
      const ref = doc(db, `centers/${ownerId}/payments`, p.id);
      batch.set(ref, {
        ...p,
        paymentMode: 'Cash' as const,
        updatedAt: p.updatedAt || new Date().toISOString(),
      });
    });

    // Tests
    localData.tests.forEach((t) => {
      const ref = doc(db, `centers/${ownerId}/tests`, t.id);
      batch.set(ref, { ...t, updatedAt: t.updatedAt || new Date().toISOString() });
    });

    // Test Results
    localData.testResults.forEach((tr) => {
      const ref = doc(db, `centers/${ownerId}/testResults`, tr.id);
      batch.set(ref, { ...tr, updatedAt: tr.updatedAt || new Date().toISOString() });
    });

    await batch.commit();
  }

  /**
   * Pull initial cloud data and merge by ID (conflict resolution: cloud wins if newer)
   */
  private async pullInitialCloudData(ownerId: string, localData: ReturnType<typeof getStoredData>) {
    // 1. Settings
    const settingsSnap = await getDocs(collection(db, `centers/${ownerId}/settings`));
    let mergedSettings = localData.settings;
    settingsSnap.forEach((d) => {
      if (d.id === 'main') {
        mergedSettings = { ...mergedSettings, ...(d.data() as InstituteSettings) };
      }
    });

    // 2. Students
    const studentsSnap = await getDocs(collection(db, `centers/${ownerId}/students`));
    const cloudStudentsMap = new Map<string, Student>();
    studentsSnap.forEach((d) => cloudStudentsMap.set(d.id, d.data() as Student));

    const mergedStudents: Student[] = [];
    cloudStudentsMap.forEach((s) => mergedStudents.push(s));
    localData.students.forEach((s) => {
      if (!cloudStudentsMap.has(s.id)) {
        mergedStudents.push(s);
        // Queue push to cloud
        this.queueMutation({
          id: `mut-${Date.now()}-${s.id}`,
          type: 'upsert',
          collectionName: 'students',
          documentId: s.id,
          data: s,
          timestamp: new Date().toISOString(),
        });
      }
    });

    // 3. Batches
    const batchesSnap = await getDocs(collection(db, `centers/${ownerId}/batches`));
    const cloudBatchesMap = new Map<string, Batch>();
    batchesSnap.forEach((d) => cloudBatchesMap.set(d.id, d.data() as Batch));

    const mergedBatches: Batch[] = [];
    cloudBatchesMap.forEach((b) => mergedBatches.push(b));
    localData.batches.forEach((b) => {
      if (!cloudBatchesMap.has(b.id)) {
        mergedBatches.push(b);
        this.queueMutation({
          id: `mut-${Date.now()}-${b.id}`,
          type: 'upsert',
          collectionName: 'batches',
          documentId: b.id,
          data: b,
          timestamp: new Date().toISOString(),
        });
      }
    });

    // 4. Payments
    const paymentsSnap = await getDocs(collection(db, `centers/${ownerId}/payments`));
    const cloudPaymentsMap = new Map<string, FeePayment>();
    paymentsSnap.forEach((d) => {
      const p = d.data() as FeePayment;
      cloudPaymentsMap.set(d.id, { ...p, paymentMode: 'Cash' });
    });

    const mergedPayments: FeePayment[] = [];
    cloudPaymentsMap.forEach((p) => mergedPayments.push(p));
    localData.payments.forEach((p) => {
      if (!cloudPaymentsMap.has(p.id)) {
        mergedPayments.push({ ...p, paymentMode: 'Cash' });
        this.queueMutation({
          id: `mut-${Date.now()}-${p.id}`,
          type: 'upsert',
          collectionName: 'payments',
          documentId: p.id,
          data: { ...p, paymentMode: 'Cash' },
          timestamp: new Date().toISOString(),
        });
      }
    });

    // 5. Attendance
    const attendanceSnap = await getDocs(collection(db, `centers/${ownerId}/attendance`));
    const cloudAttMap = new Map<string, AttendanceRecord>();
    attendanceSnap.forEach((d) => cloudAttMap.set(d.id, d.data() as AttendanceRecord));

    const mergedAttendance: AttendanceRecord[] = [];
    cloudAttMap.forEach((a) => mergedAttendance.push(a));
    localData.attendance.forEach((a) => {
      if (!cloudAttMap.has(a.id)) {
        mergedAttendance.push(a);
        this.queueMutation({
          id: `mut-${Date.now()}-${a.id}`,
          type: 'upsert',
          collectionName: 'attendance',
          documentId: a.id,
          data: a,
          timestamp: new Date().toISOString(),
        });
      }
    });

    // 6. Tests & Test Results
    const testsSnap = await getDocs(collection(db, `centers/${ownerId}/tests`));
    const mergedTests: ClassTest[] = [];
    testsSnap.forEach((d) => mergedTests.push(d.data() as ClassTest));
    if (mergedTests.length === 0) mergedTests.push(...localData.tests);

    const testResultsSnap = await getDocs(collection(db, `centers/${ownerId}/testResults`));
    const mergedResults: TestResult[] = [];
    testResultsSnap.forEach((d) => mergedResults.push(d.data() as TestResult));
    if (mergedResults.length === 0) mergedResults.push(...localData.testResults);

    // Save consolidated merged state to LocalStorage
    saveStoredData({
      settings: mergedSettings,
      students: mergedStudents,
      batches: mergedBatches,
      attendance: mergedAttendance,
      payments: mergedPayments,
      tests: mergedTests,
      testResults: mergedResults,
    });

    this.triggerDataUpdate();
  }

  /**
   * Queue an offline mutation
   */
  public queueMutation(mutation: OfflineMutation) {
    const queue = getOfflineQueue();
    // Dedup by collection + doc ID
    const filtered = queue.filter(
      (m) => !(m.collectionName === mutation.collectionName && m.documentId === mutation.documentId)
    );
    filtered.push(mutation);
    saveOfflineQueue(filtered);
  }

  /**
   * Process and drain the offline queue to Firestore
   */
  public async processOfflineQueue(): Promise<boolean> {
    if (!this.ownerId || !navigator.onLine || this.isSyncing) return false;

    const queue = getOfflineQueue();
    if (queue.length === 0) {
      this.updateStatus('synced', 'All changes synchronized.');
      return true;
    }

    this.isSyncing = true;
    this.updateStatus('syncing', `Synchronizing ${queue.length} pending offline items...`);

    const remainingQueue: OfflineMutation[] = [];

    for (const mutation of queue) {
      try {
        const path = `centers/${this.ownerId}/${mutation.collectionName}/${mutation.documentId}`;
        const docRef = doc(db, path);

        if (mutation.type === 'delete') {
          await deleteDoc(docRef);
        } else {
          await setDoc(docRef, {
            ...mutation.data,
            updatedAt: new Date().toISOString(),
          });
        }
      } catch (err: any) {
        console.warn(`Failed to sync item ${mutation.documentId}, will retry later:`, err);
        remainingQueue.push(mutation);
      }
    }

    saveOfflineQueue(remainingQueue);
    this.isSyncing = false;

    if (remainingQueue.length === 0) {
      this.updateStatus('synced', 'All offline changes saved to cloud.');
      return true;
    } else {
      this.updateStatus(
        'error',
        `${remainingQueue.length} items waiting for stronger network connection.`
      );
      return false;
    }
  }

  /**
   * Immediately sync a document to Firestore (or queue if offline)
   */
  public async syncDocument(
    collectionName: 'settings' | 'batches' | 'students' | 'attendance' | 'payments' | 'tests' | 'testResults',
    documentId: string,
    data: any,
    isDelete = false
  ) {
    const mutation: OfflineMutation = {
      id: `mut-${Date.now()}-${documentId}`,
      type: isDelete ? 'delete' : 'upsert',
      collectionName,
      documentId,
      data,
      timestamp: new Date().toISOString(),
    };

    if (!this.ownerId || !navigator.onLine) {
      this.queueMutation(mutation);
      this.updateStatus('offline', 'Change saved offline. Will sync when connected.');
      return;
    }

    try {
      this.updateStatus('syncing', 'Synchronizing with cloud...');
      const path = `centers/${this.ownerId}/${collectionName}/${documentId}`;
      const docRef = doc(db, path);

      if (isDelete) {
        await deleteDoc(docRef);
      } else {
        await setDoc(docRef, {
          ...data,
          updatedAt: new Date().toISOString(),
        });
      }
      this.updateStatus('synced', 'Cloud backup synchronized.');
    } catch (err) {
      console.warn('Network sync failed, queuing change locally:', err);
      this.queueMutation(mutation);
      this.updateStatus('error', 'Sync failed. Queued for automatic retry.');
    }
  }

  /**
   * Manual force sync triggered by the owner
   */
  public async manualSyncNow(): Promise<{ success: boolean; message: string }> {
    if (!navigator.onLine) {
      return { success: false, message: 'Device is offline. Connect to internet first.' };
    }
    if (!this.ownerId) {
      return { success: false, message: 'Please sign in to sync with cloud.' };
    }

    this.updateStatus('syncing', 'Force syncing with cloud database...');
    try {
      const localData = getStoredData();
      await this.pullInitialCloudData(this.ownerId, localData);
      const queueSuccess = await this.processOfflineQueue();
      this.updateStatus('synced', 'All records up to date on cloud.');
      return {
        success: queueSuccess,
        message: 'Successfully synchronized with cloud database.',
      };
    } catch (err: any) {
      this.updateStatus('error', err?.message || 'Sync encountered an error.');
      return { success: false, message: err?.message || 'Sync failed.' };
    }
  }

  public cleanup() {
    this.unsubscribers.forEach((unsub) => {
      try {
        unsub();
      } catch {}
    });
    this.unsubscribers = [];
  }
}

export const syncService = new SyncService();
