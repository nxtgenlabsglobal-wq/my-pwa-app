import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  CheckCircle2,
  Clock,
  IndianRupee,
  AlertTriangle,
  ArrowRight,
  Plus,
  CalendarCheck,
  CreditCard,
  MessageSquare,
  Banknote,
  Cloud,
  RefreshCw,
  CloudOff,
} from 'lucide-react';
import { formatCurrency, formatDate, formatMonthName } from '../../utils/formatters';

export const DashboardView: React.FC = () => {
  const {
    students,
    batches,
    attendance,
    payments,
    settings,
    todayDate,
    currentMonth,
    studentFeeSummaries,
    syncStatus,
    syncMessage,
    manualSyncNow,
    authUser,
    setActiveTab,
    setIsAddStudentModalOpen,
    setEditingStudent,
    setIsRecordPaymentModalOpen,
    setPreselectedPaymentStudentId,
    setReceiptModalPayment,
    setWhatsAppModalData,
    setSelectedStudentId,
  } = useApp();

  const activeStudents = students.filter((s) => s.isActive);
  const inactiveStudentsCount = students.length - activeStudents.length;

  // Today's attendance stats
  const todayAttendanceRecords = attendance.filter((a) => a.date === todayDate);
  const todayPresentCount = todayAttendanceRecords.filter((a) => a.status === 'present').length;
  const todayAbsentCount = todayAttendanceRecords.filter((a) => a.status === 'absent').length;
  const todayLateCount = todayAttendanceRecords.filter((a) => a.status === 'late').length;
  const todayMarkedTotal = todayAttendanceRecords.length;

  const todayAttendanceRate =
    todayMarkedTotal > 0
      ? Math.round(((todayPresentCount + todayLateCount) / todayMarkedTotal) * 100)
      : 0;

  // Fees this month: CASH ONLY
  const paymentsThisMonth = payments.filter((p) => p.monthFor === currentMonth);
  const totalFeesCollectedThisMonth = paymentsThisMonth.reduce((sum, p) => sum + p.amount, 0);

  // Total pending fees for active students this month
  const totalPendingFeesThisMonth = studentFeeSummaries
    .filter((s) => s.student.isActive)
    .reduce((sum, s) => sum + s.balanceThisMonth, 0);

  // Overdue students list (pending dues past defaultFeeDueDay)
  const overdueStudents = studentFeeSummaries
    .filter((s) => s.isOverdue)
    .sort((a, b) => b.balanceThisMonth - a.balanceThisMonth);

  // Recent payment transactions (latest 5)
  const recentPayments = [...payments]
    .sort((a, b) => new Date(b.recordedAt).getTime() - new Date(a.recordedAt).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-6 pb-20 lg:pb-8">
      {/* Top Banner & Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-blue-600 tracking-wide uppercase">
              Institute Dashboard
            </span>
            {syncStatus === 'synced' && (
              <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Auto-Synced
              </span>
            )}
            {syncStatus === 'offline' && (
              <span className="text-[11px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-200 flex items-center gap-1">
                <CloudOff className="w-3 h-3" /> Offline Mode
              </span>
            )}
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-0.5">
            Welcome back, {authUser?.displayName || settings.ownerName || 'Director'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {settings.name} · Managing {activeStudents.length} active students across {batches.length} batches
          </p>
        </div>

        {/* Quick action buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveTab('attendance')}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 py-2.5 px-3.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200/80 rounded-xl transition-colors cursor-pointer"
          >
            <CalendarCheck className="w-4 h-4 text-blue-600" />
            <span>Mark Attendance</span>
          </button>

          <button
            onClick={() => {
              setPreselectedPaymentStudentId(null);
              setIsRecordPaymentModalOpen(true);
            }}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 py-2.5 px-3.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors shadow-xs cursor-pointer"
          >
            <IndianRupee className="w-4 h-4 text-emerald-400" />
            <span>Record Cash Fee</span>
          </button>

          <button
            onClick={() => {
              setEditingStudent(null);
              setIsAddStudentModalOpen(true);
            }}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 py-2.5 px-3.5 text-xs font-semibold text-blue-800 bg-blue-50 hover:bg-blue-100 rounded-xl border border-blue-200 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Student</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Grid (Cash Only fees) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* KPI 1: Active Students */}
        <div
          onClick={() => setActiveTab('students')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-slate-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Active Students</span>
            <Users className="w-4 h-4 text-blue-600 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
            {activeStudents.length}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            Total {students.length} enrolled {inactiveStudentsCount > 0 && `(${inactiveStudentsCount} inactive)`}
          </p>
        </div>

        {/* KPI 2: Today's Attendance % */}
        <div
          onClick={() => setActiveTab('attendance')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-slate-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Today's Attendance</span>
            <CalendarCheck className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono tabular-nums">
              {todayAttendanceRate}%
            </span>
            <span className="text-xs font-semibold text-emerald-600 font-mono">
              {todayPresentCount} Present
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {todayAbsentCount} Absent · {todayLateCount} Late · {todayMarkedTotal} Marked
          </p>
        </div>

        {/* KPI 3: Cash Fees Collected This Month */}
        <div
          onClick={() => setActiveTab('fees')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-slate-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Cash Fees ({formatMonthName(currentMonth).split(' ')[0]})</span>
            <Banknote className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-700 font-mono tabular-nums">
            {formatCurrency(totalFeesCollectedThisMonth)}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            From {paymentsThisMonth.length} cash vouchers
          </p>
        </div>

        {/* KPI 4: Pending Fees */}
        <div
          onClick={() => setActiveTab('fees')}
          className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-slate-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Total Pending Cash Dues</span>
            <AlertTriangle className="w-4 h-4 text-rose-500 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-rose-600 font-mono tabular-nums">
            {formatCurrency(totalPendingFeesThisMonth)}
          </div>
          <p className="text-[11px] text-slate-500 mt-1">
            {overdueStudents.length} students overdue past {settings.defaultFeeDueDay || 5}th
          </p>
        </div>
      </div>

      {/* Middle Split: Batch Attendance & Urgent Fee Overdue Alert */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Batch Attendance Register Snapshot */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Today's Class Attendance</h2>
              <p className="text-xs text-slate-500">{formatDate(todayDate)}</p>
            </div>
            <button
              onClick={() => setActiveTab('attendance')}
              className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <span>Full Register</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {batches.map((batch) => {
              const batchStudents = activeStudents.filter((s) => s.batchId === batch.id);
              const batchRecords = todayAttendanceRecords.filter((a) => a.batchId === batch.id);
              const isMarked = batchRecords.length > 0;
              const presentCount = batchRecords.filter((a) => a.status === 'present').length;
              const absentCount = batchRecords.filter((a) => a.status === 'absent').length;

              return (
                <div
                  key={batch.id}
                  className="flex items-center justify-between p-3 rounded-xl border border-slate-100 bg-slate-50/70 hover:bg-slate-100/60 transition-colors"
                >
                  <div className="min-w-0 flex-1 pr-3">
                    <p className="text-xs font-bold text-slate-800 truncate">{batch.name}</p>
                    <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                      {batch.timing} · {batchStudents.length} students enrolled
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {isMarked ? (
                      <div className="text-right">
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          Marked ({presentCount}P / {absentCount}A)
                        </span>
                      </div>
                    ) : (
                      <button
                        onClick={() => setActiveTab('attendance')}
                        className="py-1 px-3 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors cursor-pointer"
                      >
                        Mark Now
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Urgent Pending Fee Reminders with 1-Tap WhatsApp */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-bold text-slate-900">Pending Fee Dues</h2>
                {overdueStudents.length > 0 && (
                  <span className="text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-200 px-1.5 py-0.5 rounded-full">
                    {overdueStudents.length} Overdue
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500">
                Cash due date was {settings.defaultFeeDueDay || 5}th of this month
              </p>
            </div>

            <button
              onClick={() => setActiveTab('fees')}
              className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex-1 space-y-2.5 overflow-y-auto max-h-[280px]">
            {overdueStudents.length === 0 ? (
              <div className="py-10 text-center text-xs text-slate-400">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2 opacity-80" />
                All active students have cleared their fees for this month!
              </div>
            ) : (
              overdueStudents.slice(0, 5).map((item) => (
                <div
                  key={item.student.id}
                  className="flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:border-slate-300 transition-colors"
                >
                  <div
                    onClick={() => setSelectedStudentId(item.student.id)}
                    className="min-w-0 cursor-pointer"
                  >
                    <p className="text-xs font-bold text-slate-900 hover:text-blue-600 transition-colors truncate">
                      {item.student.name}
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                      {item.batch?.name || 'Class'} · Ph: {item.student.parentContact}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <div className="text-right">
                      <p className="text-xs font-extrabold text-rose-600 font-mono">
                        {formatCurrency(item.balanceThisMonth)}
                      </p>
                      <p className="text-[10px] text-slate-400">Pending</p>
                    </div>

                    <button
                      onClick={() =>
                        setWhatsAppModalData({
                          student: item.student,
                          type: 'fee_reminder',
                        })
                      }
                      className="p-2 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 transition-colors cursor-pointer"
                      title="Send WhatsApp Cash Fee Reminder"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                    </button>

                    <button
                      onClick={() => {
                        setPreselectedPaymentStudentId(item.student.id);
                        setIsRecordPaymentModalOpen(true);
                      }}
                      className="py-1 px-2.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                    >
                      Pay
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Recent Cash Payments Section */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Recent Cash Payment Receipts</h2>
            <p className="text-xs text-slate-500">Official cash vouchers recorded at counter</p>
          </div>
          <button
            onClick={() => setActiveTab('fees')}
            className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 cursor-pointer"
          >
            <span>Billing Ledger</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 text-slate-400 font-semibold">
                <th className="pb-2.5">Receipt #</th>
                <th className="pb-2.5">Student</th>
                <th className="pb-2.5">Date</th>
                <th className="pb-2.5">Month</th>
                <th className="pb-2.5">Payment Mode</th>
                <th className="pb-2.5 text-right">Cash Amount</th>
                <th className="pb-2.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {recentPayments.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-6 text-center text-slate-400">
                    No cash payment history recorded yet.
                  </td>
                </tr>
              ) : (
                recentPayments.map((pay) => {
                  const student = students.find((s) => s.id === pay.studentId);
                  return (
                    <tr key={pay.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-2.5 font-mono font-medium text-slate-900">
                        {pay.receiptNo}
                      </td>
                      <td className="py-2.5 font-semibold text-slate-800">
                        {student?.name || 'Unknown Student'}
                      </td>
                      <td className="py-2.5 font-mono text-slate-500">
                        {formatDate(pay.date)}
                      </td>
                      <td className="py-2.5 text-slate-600">
                        {formatMonthName(pay.monthFor)}
                      </td>
                      <td className="py-2.5">
                        <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 font-semibold border border-emerald-200">
                          Cash
                        </span>
                      </td>
                      <td className="py-2.5 text-right font-extrabold text-emerald-700 font-mono">
                        {formatCurrency(pay.amount)}
                      </td>
                      <td className="py-2.5 text-right">
                        {student && (
                          <button
                            onClick={() =>
                              setReceiptModalPayment({ payment: pay, student })
                            }
                            className="text-blue-600 hover:text-blue-800 font-semibold cursor-pointer"
                          >
                            Receipt
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
