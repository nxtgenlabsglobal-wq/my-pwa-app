import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  BarChart3,
  CalendarCheck,
  CreditCard,
  AlertTriangle,
  Download,
  FileSpreadsheet,
  Award,
  Plus,
  MessageSquare,
  Edit2,
  Trash2,
  Banknote,
} from 'lucide-react';
import { formatCurrency, formatDate, formatMonthName, exportToCSV } from '../../utils/formatters';
import { generateReportPDF } from '../../utils/pdfGenerator';
import { ClassTest } from '../../types';

export const ReportsView: React.FC = () => {
  const {
    students,
    batches,
    payments,
    settings,
    tests,
    testResults,
    currentMonth,
    studentFeeSummaries,
    getStudentAttendanceSummary,
    addTest,
    deleteTest,
    saveTestResults,
    setWhatsAppModalData,
  } = useApp();

  const [activeReport, setActiveReport] = useState<'attendance' | 'collection' | 'outstanding' | 'tests'>('attendance');
  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonth);
  const [selectedBatchId, setSelectedBatchId] = useState<string>('all');

  // Test creation modal state
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [testBatchId, setTestBatchId] = useState(batches[0]?.id || '');
  const [testTitle, setTestTitle] = useState('');
  const [testSubject, setTestSubject] = useState('');
  const [testTotalMarks, setTestTotalMarks] = useState('50');
  const [testDate, setTestDate] = useState(new Date().toISOString().split('T')[0]);

  // Selected test for marks entry
  const [selectedTestId, setSelectedTestId] = useState<string | null>(tests[0]?.id || null);
  const [marksMap, setMarksMap] = useState<Record<string, number>>({});

  const selectedBatch = batches.find((b) => b.id === selectedBatchId);

  // 1. Attendance Report Data
  const attendanceReportData = useMemo(() => {
    return students
      .filter((s) => s.isActive && (selectedBatchId === 'all' || s.batchId === selectedBatchId))
      .map((student) => {
        const batch = batches.find((b) => b.id === student.batchId);
        const summary = getStudentAttendanceSummary(student.id, selectedMonth);
        return {
          rollNo: student.rollNo,
          name: student.name,
          batchName: batch?.name || 'Class',
          totalDays: summary.totalDays,
          presentDays: summary.presentDays,
          absentDays: summary.absentDays,
          lateDays: summary.lateDays,
          percentage: summary.percentage,
        };
      })
      .sort((a, b) => b.percentage - a.percentage);
  }, [students, batches, selectedBatchId, selectedMonth, getStudentAttendanceSummary]);

  // 2. Collection Report Data (Cash Only)
  const collectionReportData = useMemo(() => {
    return payments
      .filter((p) => p.monthFor === selectedMonth)
      .map((p) => {
        const student = students.find((s) => s.id === p.studentId);
        const batch = student ? batches.find((b) => b.id === student.batchId) : undefined;
        return {
          receiptNo: p.receiptNo,
          date: p.date,
          studentName: student?.name || 'Unknown',
          rollNo: student?.rollNo || 'N/A',
          batchName: batch?.name || '',
          amount: p.amount,
          mode: 'Cash',
          remarks: p.remarks || 'Cash at counter',
        };
      });
  }, [payments, selectedMonth, students, batches]);

  const totalCashCollectionsMonth = collectionReportData.reduce((sum, r) => sum + r.amount, 0);

  // 3. Outstanding Fees Report Data (Cash Only)
  const outstandingReportData = useMemo(() => {
    return studentFeeSummaries
      .filter(
        (s) =>
          s.student.isActive &&
          s.balanceThisMonth > 0 &&
          (selectedBatchId === 'all' || s.student.batchId === selectedBatchId)
      )
      .map((s) => ({
        rollNo: s.student.rollNo,
        name: s.student.name,
        batchName: s.batch?.name || '',
        parentContact: s.student.parentContact,
        monthlyFee: s.totalDueThisMonth,
        paid: s.paidThisMonth,
        due: s.balanceThisMonth,
        isOverdue: s.isOverdue,
      }))
      .sort((a, b) => b.due - a.due);
  }, [studentFeeSummaries, selectedBatchId]);

  const totalOutstanding = outstandingReportData.reduce((sum, s) => sum + s.due, 0);

  // 4. Test Performance Data
  const currentTest = tests.find((t) => t.id === selectedTestId);
  const testBatchStudents = useMemo(() => {
    if (!currentTest) return [];
    return students.filter((s) => s.batchId === currentTest.batchId && s.isActive);
  }, [students, currentTest]);

  // Initialize marksMap when test changes
  React.useEffect(() => {
    if (currentTest) {
      const map: Record<string, number> = {};
      testBatchStudents.forEach((student) => {
        const found = testResults.find(
          (r) => r.testId === currentTest.id && r.studentId === student.id
        );
        map[student.id] = found ? found.marksObtained : 0;
      });
      setMarksMap(map);
    }
  }, [selectedTestId, currentTest, testBatchStudents, testResults]);

  const handleSaveMarks = () => {
    if (!currentTest) return;
    const payload = testBatchStudents.map((s) => ({
      studentId: s.id,
      marksObtained: marksMap[s.id] ?? 0,
    }));
    saveTestResults(currentTest.id, payload);
  };

  const handleCreateTest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testTitle.trim()) return;

    addTest({
      batchId: testBatchId,
      title: testTitle.trim(),
      subject: testSubject.trim() || 'General Test',
      totalMarks: parseInt(testTotalMarks, 10) || 50,
      date: testDate,
    });

    setIsTestModalOpen(false);
    setTestTitle('');
    setTestSubject('');
  };

  // Export handlers
  const handleExportCSV = () => {
    if (activeReport === 'attendance') {
      const rows = attendanceReportData.map((r) => ({
        'Roll No': r.rollNo,
        'Student Name': r.name,
        Batch: r.batchName,
        'Total Sessions': r.totalDays,
        'Present Count': r.presentDays,
        'Absent Count': r.absentDays,
        'Late Count': r.lateDays,
        'Attendance %': `${r.percentage}%`,
        Month: formatMonthName(selectedMonth),
      }));
      exportToCSV(`Attendance_Report_${selectedMonth}`, rows);
    } else if (activeReport === 'collection') {
      const rows = collectionReportData.map((r) => ({
        'Receipt No': r.receiptNo,
        'Date of Payment': r.date,
        'Student Name': r.studentName,
        'Roll No': r.rollNo,
        Batch: r.batchName,
        'Cash Amount (INR)': r.amount,
        'Payment Mode': 'Cash',
        Month: formatMonthName(selectedMonth),
      }));
      exportToCSV(`Cash_Fee_Collection_Report_${selectedMonth}`, rows);
    } else if (activeReport === 'outstanding') {
      const rows = outstandingReportData.map((r) => ({
        'Roll No': r.rollNo,
        'Student Name': r.name,
        Batch: r.batchName,
        'Parent Phone': r.parentContact,
        'Monthly Tuition Fee': r.monthlyFee,
        'Paid This Month': r.paid,
        'Outstanding Cash Due (INR)': r.due,
        'Overdue Status': r.isOverdue ? 'OVERDUE' : 'PENDING',
        Month: formatMonthName(selectedMonth),
      }));
      exportToCSV(`Outstanding_Cash_Fees_${selectedMonth}`, rows);
    } else {
      // Test Performance CSV
      if (!currentTest) return;
      const rows = testBatchStudents.map((s) => {
        const marks = marksMap[s.id] ?? 0;
        const pct = Math.round((marks / currentTest.totalMarks) * 100);
        return {
          'Roll No': s.rollNo,
          'Student Name': s.name,
          'Test Title': currentTest.title,
          Subject: currentTest.subject,
          'Date of Test': currentTest.date,
          'Marks Obtained': marks,
          'Total Marks': currentTest.totalMarks,
          'Percentage (%)': `${pct}%`,
        };
      });
      exportToCSV(`Test_Marks_${currentTest.title.replace(/\s+/g, '_')}`, rows);
    }
  };

  const handleExportPDF = () => {
    if (activeReport === 'attendance') {
      const headers = ['Roll #', 'Student Name', 'Class / Batch', 'Sessions', 'Present', 'Absent', 'Attendance %'];
      const rows = attendanceReportData.map((r) => [
        r.rollNo,
        r.name,
        r.batchName,
        r.totalDays,
        r.presentDays,
        r.absentDays,
        `${r.percentage}%`,
      ]);
      generateReportPDF(
        `Monthly Attendance Summary - ${formatMonthName(selectedMonth)}`,
        headers,
        rows,
        settings,
        `Batch: ${selectedBatchId === 'all' ? 'All Batches' : selectedBatch?.name}`
      );
    } else if (activeReport === 'collection') {
      const headers = ['Receipt #', 'Date', 'Student Name', 'Batch', 'Payment Method', 'Cash Amount (INR)'];
      const rows = collectionReportData.map((r) => [
        r.receiptNo,
        formatDate(r.date),
        r.studentName,
        r.batchName,
        'Cash',
        formatCurrency(r.amount),
      ]);
      generateReportPDF(
        `Monthly Cash Fee Collection Report - ${formatMonthName(selectedMonth)}`,
        headers,
        rows,
        settings,
        `Total Cash Collections: ${formatCurrency(totalCashCollectionsMonth)} across ${collectionReportData.length} cash vouchers`
      );
    } else if (activeReport === 'outstanding') {
      const headers = ['Roll #', 'Student Name', 'Class / Batch', 'Parent Contact', 'Tuition Fee', 'Paid', 'Due Amount'];
      const rows = outstandingReportData.map((r) => [
        r.rollNo,
        r.name,
        r.batchName,
        r.parentContact,
        formatCurrency(r.monthlyFee),
        formatCurrency(r.paid),
        formatCurrency(r.due),
      ]);
      generateReportPDF(
        `Outstanding Fees Report - ${formatMonthName(selectedMonth)}`,
        headers,
        rows,
        settings,
        `Total Outstanding Cash Dues: ${formatCurrency(totalOutstanding)} across ${outstandingReportData.length} students`
      );
    } else {
      if (!currentTest) return;
      const headers = ['Roll #', 'Student Name', 'Parent Contact', 'Marks Obtained', 'Max Marks', 'Percentage %'];
      const rows = testBatchStudents.map((s) => {
        const marks = marksMap[s.id] ?? 0;
        const pct = Math.round((marks / currentTest.totalMarks) * 100);
        return [s.rollNo, s.name, s.parentContact, marks, currentTest.totalMarks, `${pct}%`];
      });
      generateReportPDF(
        `Test Result - ${currentTest.title}`,
        headers,
        rows,
        settings,
        `Subject: ${currentTest.subject} | Date: ${formatDate(currentTest.date)} | Total Marks: ${currentTest.totalMarks}`
      );
    }
  };

  return (
    <div className="space-y-5 pb-20 lg:pb-8">
      {/* Header & Export CTAs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Institute Reports & Analytics</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Attendance summaries, cash collection ledger & student test performance
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 py-2.5 px-3.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handleExportPDF}
            className="flex items-center gap-1.5 py-2.5 px-4 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-blue-400" />
            <span>Download PDF</span>
          </button>
        </div>
      </div>

      {/* Report Selection Tabs & Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
        {/* Report Types: 4 modules */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            onClick={() => setActiveReport('attendance')}
            className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
              activeReport === 'attendance'
                ? 'bg-blue-50 border-blue-300 text-blue-900 shadow-xs'
                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <div className={`p-1.5 rounded-lg ${activeReport === 'attendance' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
                <CalendarCheck className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-slate-900">Attendance</span>
            </div>
            <p className="text-[11px] text-slate-500">Student session %</p>
          </button>

          <button
            onClick={() => setActiveReport('collection')}
            className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
              activeReport === 'collection'
                ? 'bg-emerald-50 border-emerald-300 text-emerald-900 shadow-xs'
                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <div className={`p-1.5 rounded-lg ${activeReport === 'collection' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
                <Banknote className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-slate-900">Cash Collections</span>
            </div>
            <p className="text-[11px] text-slate-500">Official cash receipts</p>
          </button>

          <button
            onClick={() => setActiveReport('outstanding')}
            className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
              activeReport === 'outstanding'
                ? 'bg-rose-50 border-rose-300 text-rose-900 shadow-xs'
                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <div className={`p-1.5 rounded-lg ${activeReport === 'outstanding' ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
                <AlertTriangle className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-slate-900">Pending Dues</span>
            </div>
            <p className="text-[11px] text-slate-500">Overdue balances</p>
          </button>

          <button
            onClick={() => setActiveReport('tests')}
            className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
              activeReport === 'tests'
                ? 'bg-purple-50 border-purple-300 text-purple-900 shadow-xs'
                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <div className={`p-1.5 rounded-lg ${activeReport === 'tests' ? 'bg-purple-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
                <Award className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-slate-900">Tests & Marks</span>
            </div>
            <p className="text-[11px] text-slate-500">Academic marks card</p>
          </button>
        </div>

        {/* Filters Row */}
        {activeReport !== 'tests' && (
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
            <div className="flex items-center gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Report Month:
                </label>
                <input
                  type="month"
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="px-3 py-1.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 font-medium bg-white"
                />
              </div>

              {activeReport !== 'collection' && (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                    Filter by Batch:
                  </label>
                  <select
                    value={selectedBatchId}
                    onChange={(e) => setSelectedBatchId(e.target.value)}
                    className="px-3 py-1.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 bg-white"
                  >
                    <option value="all">All Batches</option>
                    {batches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            <div className="text-right">
              <span className="text-[11px] text-slate-400">Total Entries:</span>
              <p className="font-bold text-slate-900 font-mono text-sm">
                {activeReport === 'attendance'
                  ? `${attendanceReportData.length} Students`
                  : activeReport === 'collection'
                  ? `${collectionReportData.length} Cash Receipts`
                  : `${outstandingReportData.length} Defaulters`}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Report Tables */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {activeReport === 'attendance' && (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 font-semibold">
                  <th className="p-3">Roll #</th>
                  <th className="p-3">Student Name</th>
                  <th className="p-3">Class / Batch</th>
                  <th className="p-3 text-center">Sessions Held</th>
                  <th className="p-3 text-center">Present</th>
                  <th className="p-3 text-center">Absent</th>
                  <th className="p-3 text-center">Late</th>
                  <th className="p-3 text-right">Attendance %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {attendanceReportData.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-slate-400">
                      No attendance data found for this month.
                    </td>
                  </tr>
                ) : (
                  attendanceReportData.map((row) => (
                    <tr key={row.rollNo} className="hover:bg-slate-50/70 transition-colors">
                      <td className="p-3 font-mono font-medium text-slate-600">#{row.rollNo}</td>
                      <td className="p-3 font-bold text-slate-900">{row.name}</td>
                      <td className="p-3 text-slate-600">{row.batchName}</td>
                      <td className="p-3 text-center font-mono">{row.totalDays}</td>
                      <td className="p-3 text-center font-mono text-emerald-700 font-semibold">
                        {row.presentDays}
                      </td>
                      <td className="p-3 text-center font-mono text-rose-600 font-semibold">
                        {row.absentDays}
                      </td>
                      <td className="p-3 text-center font-mono text-amber-600">{row.lateDays}</td>
                      <td className="p-3 text-right font-mono font-bold text-sm">
                        <span className={row.percentage >= 75 ? 'text-emerald-700' : 'text-amber-600'}>
                          {row.percentage}%
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {activeReport === 'collection' && (
          <div>
            <div className="p-4 bg-emerald-50/60 border-b border-emerald-100 flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-emerald-800">Total Cash Fees Received</span>
                <p className="text-xl font-bold font-mono text-emerald-900 mt-0.5">
                  {formatCurrency(totalCashCollectionsMonth)}
                </p>
              </div>
              <span className="text-xs text-emerald-700 font-semibold">
                {collectionReportData.length} Cash Receipts
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 font-semibold">
                    <th className="p-3">Receipt #</th>
                    <th className="p-3">Date</th>
                    <th className="p-3">Student Name</th>
                    <th className="p-3">Batch</th>
                    <th className="p-3">Payment Method</th>
                    <th className="p-3 text-right">Cash Received</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {collectionReportData.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-8 text-slate-400">
                        No cash fee payments recorded for this month.
                      </td>
                    </tr>
                  ) : (
                    collectionReportData.map((row) => (
                      <tr key={row.receiptNo} className="hover:bg-slate-50/70 transition-colors">
                        <td className="p-3 font-mono font-bold text-slate-900">{row.receiptNo}</td>
                        <td className="p-3 font-mono text-slate-500">{formatDate(row.date)}</td>
                        <td className="p-3 font-semibold text-slate-800">{row.studentName}</td>
                        <td className="p-3 text-slate-600">{row.batchName}</td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 font-semibold border border-emerald-200">
                            Cash
                          </span>
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-emerald-700 text-sm">
                          {formatCurrency(row.amount)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeReport === 'outstanding' && (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 font-semibold">
                  <th className="p-3">Roll #</th>
                  <th className="p-3">Student Name</th>
                  <th className="p-3">Class / Batch</th>
                  <th className="p-3">Parent Phone</th>
                  <th className="p-3 text-right">Tuition Fee</th>
                  <th className="p-3 text-right">Cash Paid</th>
                  <th className="p-3 text-right">Balance Due</th>
                  <th className="p-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {outstandingReportData.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-emerald-600">
                      Great job! No outstanding fee balances for the selected criteria.
                    </td>
                  </tr>
                ) : (
                  outstandingReportData.map((row) => (
                    <tr key={row.rollNo} className="hover:bg-slate-50/70 transition-colors">
                      <td className="p-3 font-mono font-medium text-slate-600">#{row.rollNo}</td>
                      <td className="p-3 font-bold text-slate-900">{row.name}</td>
                      <td className="p-3 text-slate-600">{row.batchName}</td>
                      <td className="p-3 font-mono text-slate-600">+91 {row.parentContact}</td>
                      <td className="p-3 text-right font-mono text-slate-700">
                        {formatCurrency(row.monthlyFee)}
                      </td>
                      <td className="p-3 text-right font-mono text-emerald-700">
                        {formatCurrency(row.paid)}
                      </td>
                      <td className="p-3 text-right font-mono font-bold text-rose-600 text-sm">
                        {formatCurrency(row.due)}
                      </td>
                      <td className="p-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            row.isOverdue
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}
                        >
                          {row.isOverdue ? 'Overdue' : 'Due Soon'}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* 4. Tests and Marks Management */}
        {activeReport === 'tests' && (
          <div className="p-5 space-y-5">
            {/* Top row: Select Test, Add Test button */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2 overflow-x-auto">
                <span className="text-xs font-semibold text-slate-500 whitespace-nowrap">
                  Select Test:
                </span>
                {tests.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setSelectedTestId(t.id)}
                    className={`py-1.5 px-3 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                      selectedTestId === t.id
                        ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {t.title}
                  </button>
                ))}
              </div>

              <button
                onClick={() => setIsTestModalOpen(true)}
                className="flex items-center justify-center gap-1.5 py-2 px-3.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors shrink-0 shadow-xs cursor-pointer"
              >
                <Plus className="w-4 h-4 text-purple-400" />
                <span>Create New Test</span>
              </button>
            </div>

            {currentTest ? (
              <div className="space-y-4">
                {/* Test details strip */}
                <div className="p-3.5 bg-purple-50/60 rounded-xl border border-purple-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div>
                    <h3 className="font-bold text-slate-900">{currentTest.title}</h3>
                    <p className="text-slate-500 mt-0.5">
                      Subject: <strong className="text-slate-800">{currentTest.subject}</strong> · Date:{' '}
                      <strong className="text-slate-800">{formatDate(currentTest.date)}</strong> · Max
                      Marks: <strong className="font-mono text-purple-800">{currentTest.totalMarks}</strong>
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleSaveMarks}
                      className="py-1.5 px-4 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
                    >
                      Save Marks
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`Delete test "${currentTest.title}"?`)) {
                          deleteTest(currentTest.id);
                        }
                      }}
                      className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="Delete test"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Marks entry list */}
                <div className="divide-y divide-slate-100">
                  {testBatchStudents.map((student) => {
                    const marks = marksMap[student.id] ?? 0;
                    const pct = Math.round((marks / currentTest.totalMarks) * 100);
                    const batch = batches.find((b) => b.id === student.batchId);

                    return (
                      <div
                        key={student.id}
                        className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3">
                          <span className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center font-mono font-bold text-xs">
                            #{student.rollNo}
                          </span>
                          <div>
                            <p className="text-xs font-bold text-slate-900">{student.name}</p>
                            <p className="text-[11px] text-slate-400">
                              Ph: +91 {student.parentContact}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs text-slate-500">Marks:</span>
                            <input
                              type="number"
                              min="0"
                              max={currentTest.totalMarks}
                              value={marks}
                              onChange={(e) =>
                                setMarksMap({
                                  ...marksMap,
                                  [student.id]: parseFloat(e.target.value) || 0,
                                })
                              }
                              className="w-16 px-2.5 py-1 text-xs font-mono font-bold text-slate-900 rounded-lg border border-slate-300 text-center"
                            />
                            <span className="text-xs text-slate-400 font-mono">
                              / {currentTest.totalMarks}
                            </span>
                          </div>

                          <span
                            className={`text-xs font-bold font-mono px-2 py-0.5 rounded-md ${
                              pct >= 75
                                ? 'bg-emerald-50 text-emerald-700'
                                : pct >= 40
                                ? 'bg-blue-50 text-blue-700'
                                : 'bg-rose-50 text-rose-700'
                            }`}
                          >
                            {pct}%
                          </span>

                          <button
                            onClick={() =>
                              setWhatsAppModalData({
                                student,
                                type: 'test',
                                test: currentTest,
                                testResult: {
                                  id: `tr-${currentTest.id}-${student.id}`,
                                  testId: currentTest.id,
                                  studentId: student.id,
                                  marksObtained: marks,
                                },
                              })
                            }
                            className="p-1.5 rounded-lg text-emerald-700 hover:bg-emerald-50 border border-emerald-200 transition-colors cursor-pointer"
                            title="Share Test Marks via WhatsApp"
                          >
                            <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="text-center py-10 text-slate-400 text-xs">
                No tests created yet. Tap "Create New Test" above.
              </div>
            )}
          </div>
        )}
      </div>

      {/* Create Test Modal */}
      {isTestModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs"
            onClick={() => setIsTestModalOpen(false)}
          />
          <div className="relative bg-white rounded-2xl shadow-2xl max-w-md w-full p-5 z-10 border border-slate-200 animate-in zoom-in-95 duration-150">
            <h3 className="text-base font-bold text-slate-900 mb-1">Create Class Test</h3>
            <p className="text-xs text-slate-500 mb-4">Set test title, max marks, and target batch</p>

            <form onSubmit={handleCreateTest} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Target Batch <span className="text-rose-500">*</span>
                </label>
                <select
                  value={testBatchId}
                  onChange={(e) => setTestBatchId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-purple-500/20 bg-white"
                >
                  {batches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Test Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={testTitle}
                  onChange={(e) => setTestTitle(e.target.value)}
                  placeholder="e.g. Electricity & Magnetism Unit Test"
                  required
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-purple-500/20"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Subject</label>
                <input
                  type="text"
                  value={testSubject}
                  onChange={(e) => setTestSubject(e.target.value)}
                  placeholder="e.g. Physics"
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-purple-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Max Marks <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="5"
                    max="500"
                    value={testTotalMarks}
                    onChange={(e) => setTestTotalMarks(e.target.value)}
                    required
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-purple-500/20 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Test Date <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={testDate}
                    onChange={(e) => setTestDate(e.target.value)}
                    required
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-purple-500/20 bg-white"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsTestModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-purple-600 hover:bg-purple-700 rounded-xl shadow-xs cursor-pointer"
                >
                  Create Test
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
