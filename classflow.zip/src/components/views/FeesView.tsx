import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  CreditCard,
  IndianRupee,
  Search,
  Plus,
  MessageSquare,
  FileSpreadsheet,
  FileText,
  Trash2,
  Banknote,
} from 'lucide-react';
import { formatCurrency, formatDate, formatMonthName, exportToCSV } from '../../utils/formatters';

export const FeesView: React.FC = () => {
  const {
    students,
    batches,
    payments,
    settings,
    currentMonth,
    setIsRecordPaymentModalOpen,
    setPreselectedPaymentStudentId,
    setReceiptModalPayment,
    setWhatsAppModalData,
    deletePayment,
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'dues' | 'history'>('dues');
  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonth);
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'partial' | 'paid'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Summaries based on selectedMonth
  const monthlySummaries = useMemo(() => {
    const todayDay = new Date().getDate();
    const isDuePassed = todayDay > (settings.defaultFeeDueDay || 5);

    return students
      .filter((s) => s.isActive)
      .map((student) => {
        const batch = batches.find((b) => b.id === student.batchId);
        const studentPayments = payments.filter((p) => p.studentId === student.id);
        const paidThisMonth = studentPayments
          .filter((p) => p.monthFor === selectedMonth)
          .reduce((sum, p) => sum + p.amount, 0);

        const totalDueThisMonth = student.monthlyFee;
        const balanceThisMonth = Math.max(0, totalDueThisMonth - paidThisMonth);

        let status: 'paid' | 'partial' | 'pending' = 'pending';
        if (balanceThisMonth <= 0) {
          status = 'paid';
        } else if (paidThisMonth > 0) {
          status = 'partial';
        } else {
          status = 'pending';
        }

        return {
          student,
          batch,
          totalDueThisMonth,
          paidThisMonth,
          balanceThisMonth,
          isOverdue: isDuePassed && balanceThisMonth > 0,
          status,
        };
      });
  }, [students, batches, payments, selectedMonth, settings.defaultFeeDueDay]);

  // Filtered dues list
  const filteredSummaries = useMemo(() => {
    return monthlySummaries.filter((item) => {
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchName = item.student.name.toLowerCase().includes(q);
        const matchRoll = item.student.rollNo.toLowerCase().includes(q);
        const matchBatch = item.batch?.name.toLowerCase().includes(q);
        if (!matchName && !matchRoll && !matchBatch) return false;
      }

      if (statusFilter === 'all') return true;
      if (statusFilter === 'paid') return item.status === 'paid';
      if (statusFilter === 'partial') return item.status === 'partial';
      if (statusFilter === 'pending') return item.balanceThisMonth > 0;
      return true;
    });
  }, [monthlySummaries, searchTerm, statusFilter]);

  // Financial totals for this month (Cash Only)
  const totalExpected = monthlySummaries.reduce((sum, s) => sum + s.totalDueThisMonth, 0);
  const totalCollected = monthlySummaries.reduce((sum, s) => sum + s.paidThisMonth, 0);
  const totalPending = monthlySummaries.reduce((sum, s) => sum + s.balanceThisMonth, 0);
  const collectionRate = totalExpected > 0 ? Math.round((totalCollected / totalExpected) * 100) : 0;

  // Filtered payment history log (All Cash)
  const filteredPayments = useMemo(() => {
    return [...payments]
      .filter((p) => {
        if (searchTerm.trim()) {
          const q = searchTerm.toLowerCase();
          const student = students.find((s) => s.id === p.studentId);
          const matchReceipt = p.receiptNo.toLowerCase().includes(q);
          const matchStudent = student?.name.toLowerCase().includes(q);
          if (!matchReceipt && !matchStudent) return false;
        }
        return true;
      })
      .sort((a, b) => new Date(b.recordedAt).getTime() - new Date(a.recordedAt).getTime());
  }, [payments, searchTerm, students]);

  const handleExportFeeDuesCSV = () => {
    const rows = monthlySummaries.map((m) => ({
      'Roll No': m.student.rollNo,
      'Student Name': m.student.name,
      Class: m.batch?.name || '',
      'Parent Contact': m.student.parentContact,
      'Tuition Fee': m.totalDueThisMonth,
      'Cash Paid This Month': m.paidThisMonth,
      'Balance Due': m.balanceThisMonth,
      Status: m.status.toUpperCase(),
      'Is Overdue': m.isOverdue ? 'YES' : 'NO',
      Month: formatMonthName(selectedMonth),
    }));

    exportToCSV(`Cash_Fee_Status_${selectedMonth}_ClassFlow`, rows);
  };

  const handleExportPaymentHistoryCSV = () => {
    const rows = payments.map((p) => {
      const student = students.find((s) => s.id === p.studentId);
      const batch = student ? batches.find((b) => b.id === student.batchId) : undefined;
      return {
        'Receipt No': p.receiptNo,
        Date: p.date,
        'Student Name': student?.name || '',
        'Roll No': student?.rollNo || '',
        Class: batch?.name || '',
        'Cash Amount Paid': p.amount,
        'Payment Mode': 'Cash',
        'For Month': formatMonthName(p.monthFor),
        Remarks: p.remarks || '',
      };
    });

    exportToCSV(`Cash_Receipts_ClassFlow`, rows);
  };

  return (
    <div className="space-y-5 pb-20 lg:pb-8">
      {/* Top Bar with Title & Master Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Fees & Cash Collection</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Track tuition cash fees, issue receipts & send 1-tap WhatsApp reminders
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeSubTab === 'dues' ? (
            <button
              onClick={handleExportFeeDuesCSV}
              className="flex items-center gap-1.5 py-2.5 px-3.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>Export Ledger</span>
            </button>
          ) : (
            <button
              onClick={handleExportPaymentHistoryCSV}
              className="flex items-center gap-1.5 py-2.5 px-3.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>Export Receipts</span>
            </button>
          )}

          <button
            onClick={() => {
              setPreselectedPaymentStudentId(null);
              setIsRecordPaymentModalOpen(true);
            }}
            className="flex items-center gap-1.5 py-2.5 px-4 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            <span>Record Cash Fee</span>
          </button>
        </div>
      </div>

      {/* KPI Financial Overview Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500">Expected Total</span>
          <p className="text-2xl font-extrabold text-slate-900 font-mono mt-1">
            {formatCurrency(totalExpected)}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">For {formatMonthName(selectedMonth)}</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-emerald-600 flex items-center gap-1">
            <Banknote className="w-3.5 h-3.5" /> Cash Collected
          </span>
          <p className="text-2xl font-extrabold text-emerald-700 font-mono mt-1">
            {formatCurrency(totalCollected)}
          </p>
          <p className="text-[11px] text-emerald-600 font-semibold mt-0.5">
            {collectionRate}% collection rate
          </p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-rose-500">Outstanding Balance</span>
          <p className="text-2xl font-extrabold text-rose-600 font-mono mt-1">
            {formatCurrency(totalPending)}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">
            {monthlySummaries.filter((s) => s.balanceThisMonth > 0).length} students pending
          </p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500">Cash Due Date Rule</span>
          <p className="text-lg font-bold text-slate-800 mt-1">
            {settings.defaultFeeDueDay || 5}th of Month
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Cash due at front counter</p>
        </div>
      </div>

      {/* Sub Tabs: Student Fee Status vs Chronological Receipts History */}
      <div className="flex items-center justify-between border-b border-slate-200 bg-white px-4 rounded-t-2xl pt-2">
        <div className="flex gap-2">
          <button
            onClick={() => setActiveSubTab('dues')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'dues'
                ? 'border-blue-600 text-blue-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Monthly Dues & Collection</span>
          </button>

          <button
            onClick={() => setActiveSubTab('history')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'history'
                ? 'border-blue-600 text-blue-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Cash Receipts History ({payments.length})</span>
          </button>
        </div>

        {/* Month Selector for Dues Tab */}
        {activeSubTab === 'dues' && (
          <div className="py-2">
            <input
              type="month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="px-2.5 py-1 text-xs font-semibold rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 bg-white"
            />
          </div>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-b-2xl border-x border-b border-slate-200/80 shadow-xs space-y-3 -mt-5">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={
                activeSubTab === 'dues'
                  ? 'Search by student name, roll number, or class...'
                  : 'Search by receipt # or student name...'
              }
              className="w-full pl-10 pr-3.5 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          {activeSubTab === 'dues' && (
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs pb-1 sm:pb-0">
              <button
                onClick={() => setStatusFilter('all')}
                className={`py-1.5 px-3 rounded-xl font-medium transition-colors cursor-pointer ${
                  statusFilter === 'all'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                All ({monthlySummaries.length})
              </button>
              <button
                onClick={() => setStatusFilter('pending')}
                className={`py-1.5 px-3 rounded-xl font-medium transition-colors cursor-pointer ${
                  statusFilter === 'pending'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
                }`}
              >
                Pending Dues ({monthlySummaries.filter((s) => s.balanceThisMonth > 0).length})
              </button>
              <button
                onClick={() => setStatusFilter('partial')}
                className={`py-1.5 px-3 rounded-xl font-medium transition-colors cursor-pointer ${
                  statusFilter === 'partial'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-amber-50 text-amber-700 hover:bg-amber-100'
                }`}
              >
                Partial Paid ({monthlySummaries.filter((s) => s.status === 'partial').length})
              </button>
              <button
                onClick={() => setStatusFilter('paid')}
                className={`py-1.5 px-3 rounded-xl font-medium transition-colors cursor-pointer ${
                  statusFilter === 'paid'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                }`}
              >
                Fully Paid ({monthlySummaries.filter((s) => s.status === 'paid').length})
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      {activeSubTab === 'dues' ? (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          {filteredSummaries.length === 0 ? (
            <div className="text-center py-12 px-4 text-xs text-slate-400">
              No students match the selected fee filter.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filteredSummaries.map((item) => (
                <div
                  key={item.student.id}
                  className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 transition-colors"
                >
                  {/* Student details */}
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 font-bold flex items-center justify-center font-mono text-xs shrink-0">
                      #{item.student.rollNo}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm truncate">
                          {item.student.name}
                        </span>
                        {item.isOverdue && (
                          <span className="text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-200 px-1.5 py-0.5 rounded-full">
                            Overdue
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5 truncate">
                        {item.batch?.name || 'Class'} · Ph: +91 {item.student.parentContact}
                      </p>
                    </div>
                  </div>

                  {/* Financial Breakdown & Actions */}
                  <div className="flex items-center justify-between sm:justify-end gap-5 shrink-0 text-xs pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                    <div className="text-left sm:text-right">
                      <p className="text-[11px] text-slate-400">Total Fee</p>
                      <p className="font-semibold text-slate-800 font-mono">
                        {formatCurrency(item.totalDueThisMonth)}
                      </p>
                    </div>

                    <div className="text-left sm:text-right">
                      <p className="text-[11px] text-slate-400">Cash Paid</p>
                      <p className="font-semibold text-emerald-600 font-mono">
                        {formatCurrency(item.paidThisMonth)}
                      </p>
                    </div>

                    <div className="text-left sm:text-right min-w-[70px]">
                      <p className="text-[11px] text-slate-400">Balance</p>
                      <p
                        className={`font-bold font-mono text-sm ${
                          item.balanceThisMonth > 0 ? 'text-rose-600' : 'text-emerald-700'
                        }`}
                      >
                        {formatCurrency(item.balanceThisMonth)}
                      </p>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-1.5">
                      {item.balanceThisMonth > 0 && (
                        <button
                          onClick={() =>
                            setWhatsAppModalData({
                              student: item.student,
                              type: 'fee_reminder',
                            })
                          }
                          className="flex items-center gap-1 py-1.5 px-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-semibold border border-emerald-200 transition-colors cursor-pointer"
                          title="Send WhatsApp Cash Fee Reminder"
                        >
                          <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="hidden md:inline">Reminder</span>
                        </button>
                      )}

                      <button
                        onClick={() => {
                          setPreselectedPaymentStudentId(item.student.id);
                          setIsRecordPaymentModalOpen(true);
                        }}
                        className="py-1.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold transition-colors cursor-pointer"
                      >
                        {item.balanceThisMonth <= 0 ? 'Add Advance' : 'Collect Cash'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* Receipts & Transaction Ledger: All Cash */
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 font-semibold">
                  <th className="p-3">Receipt #</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Student</th>
                  <th className="p-3">Month For</th>
                  <th className="p-3">Payment Method</th>
                  <th className="p-3 text-right">Cash Received</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredPayments.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-slate-400">
                      No cash payment receipts found matching your search.
                    </td>
                  </tr>
                ) : (
                  filteredPayments.map((pay) => {
                    const student = students.find((s) => s.id === pay.studentId);
                    const batch = student ? batches.find((b) => b.id === student.batchId) : undefined;

                    return (
                      <tr key={pay.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="p-3 font-mono font-bold text-slate-900">
                          {pay.receiptNo}
                        </td>
                        <td className="p-3 font-mono text-slate-500">
                          {formatDate(pay.date)}
                        </td>
                        <td className="p-3">
                          <p className="font-semibold text-slate-800">{student?.name || 'Student'}</p>
                          <p className="text-[11px] text-slate-400 font-mono">
                            Roll #{student?.rollNo || 'N/A'} · {batch?.name || ''}
                          </p>
                        </td>
                        <td className="p-3 text-slate-700">
                          {formatMonthName(pay.monthFor)}
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 font-semibold border border-emerald-200">
                            Cash
                          </span>
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-emerald-700 text-sm">
                          {formatCurrency(pay.amount)}
                        </td>
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-2">
                            {student && (
                              <>
                                <button
                                  onClick={() =>
                                    setReceiptModalPayment({ payment: pay, student })
                                  }
                                  className="text-blue-600 hover:text-blue-800 font-semibold cursor-pointer"
                                  title="View & Download PDF Receipt"
                                >
                                  Receipt
                                </button>

                                <button
                                  onClick={() =>
                                    setWhatsAppModalData({
                                      student,
                                      type: 'receipt',
                                      payment: pay,
                                    })
                                  }
                                  className="p-1.5 rounded-lg text-emerald-700 hover:bg-emerald-50 cursor-pointer"
                                  title="Share Receipt on WhatsApp"
                                >
                                  <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                                </button>
                              </>
                            )}

                            <button
                              onClick={() => {
                                if (window.confirm(`Delete receipt #${pay.receiptNo}?`)) {
                                  deletePayment(pay.id);
                                }
                              }}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                              title="Delete record"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
