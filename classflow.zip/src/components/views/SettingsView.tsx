import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Settings as SettingsIcon,
  Building2,
  Calendar,
  CreditCard,
  Download,
  Upload,
  RotateCcw,
  Plus,
  Trash2,
  Edit2,
  Save,
  Cloud,
  CloudOff,
  RefreshCw,
  LogOut,
  User,
  ShieldCheck,
  Banknote,
} from 'lucide-react';
import { Batch } from '../../types';

export const SettingsView: React.FC = () => {
  const {
    settings,
    updateSettings,
    batches,
    addBatch,
    updateBatch,
    deleteBatch,
    students,
    attendance,
    payments,
    tests,
    testResults,
    resetAllData,
    importAllData,
    authUser,
    logout,
    syncStatus,
    syncMessage,
    manualSyncNow,
    addToast,
  } = useApp();

  // Institute profile state
  const [name, setName] = useState(settings.name);
  const [tagline, setTagline] = useState(settings.tagline);
  const [ownerName, setOwnerName] = useState(settings.ownerName);
  const [contactNumber, setContactNumber] = useState(settings.contactNumber);
  const [email, setEmail] = useState(settings.email);
  const [address, setAddress] = useState(settings.address);
  const [defaultFeeDueDay, setDefaultFeeDueDay] = useState(settings.defaultFeeDueDay.toString());
  const [receiptPrefix, setReceiptPrefix] = useState(settings.receiptPrefix || 'CF');
  const [isSyncingManual, setIsSyncingManual] = useState(false);

  // Batch modal/editing state
  const [isBatchModalOpen, setIsBatchModalOpen] = useState(false);
  const [editingBatch, setEditingBatch] = useState<Batch | null>(null);
  const [batchName, setBatchName] = useState('');
  const [batchSubject, setBatchSubject] = useState('');
  const [batchTiming, setBatchTiming] = useState('');
  const [batchDays, setBatchDays] = useState<string[]>(['Mon', 'Wed', 'Fri']);

  const allDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      name: name.trim(),
      tagline: tagline.trim(),
      ownerName: ownerName.trim(),
      contactNumber: contactNumber.trim(),
      email: email.trim(),
      address: address.trim(),
      defaultFeeDueDay: parseInt(defaultFeeDueDay, 10) || 5,
      receiptPrefix: receiptPrefix.trim().toUpperCase() || 'CF',
    });
  };

  const handleTriggerManualSync = async () => {
    setIsSyncingManual(true);
    await manualSyncNow();
    setIsSyncingManual(false);
  };

  const handleOpenAddBatch = () => {
    setEditingBatch(null);
    setBatchName('');
    setBatchSubject('');
    setBatchTiming('4:00 PM - 5:30 PM');
    setBatchDays(['Mon', 'Tue', 'Wed', 'Thu', 'Fri']);
    setIsBatchModalOpen(true);
  };

  const handleOpenEditBatch = (batch: Batch) => {
    setEditingBatch(batch);
    setBatchName(batch.name);
    setBatchSubject(batch.subject || '');
    setBatchTiming(batch.timing);
    setBatchDays(batch.days || ['Mon', 'Wed', 'Fri']);
    setIsBatchModalOpen(true);
  };

  const handleSaveBatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!batchName.trim()) return;

    if (editingBatch) {
      updateBatch(editingBatch.id, {
        name: batchName.trim(),
        subject: batchSubject.trim(),
        timing: batchTiming.trim(),
        days: batchDays,
      });
    } else {
      addBatch({
        name: batchName.trim(),
        subject: batchSubject.trim(),
        timing: batchTiming.trim() || '4:00 PM - 5:30 PM',
        days: batchDays,
      });
    }
    setIsBatchModalOpen(false);
  };

  const handleToggleDay = (day: string) => {
    if (batchDays.includes(day)) {
      setBatchDays(batchDays.filter((d) => d !== day));
    } else {
      setBatchDays([...batchDays, day]);
    }
  };

  // Backup and Restore
  const handleExportBackup = () => {
    const fullBackup = {
      version: '2.0',
      exportedAt: new Date().toISOString(),
      ownerId: authUser?.uid || 'offline-owner',
      settings,
      batches,
      students,
      attendance,
      payments,
      tests,
      testResults,
    };

    const blob = new Blob([JSON.stringify(fullBackup, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ClassFlow_Backup_${settings.name.replace(/\s+/g, '_')}_${
      new Date().toISOString().split('T')[0]
    }.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    addToast({
      type: 'success',
      title: 'Backup Downloaded',
      message: 'All students, attendance records, and receipts have been saved safely.',
    });
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        importAllData(parsed);
      } catch (err) {
        addToast({
          type: 'error',
          title: 'Invalid File',
          message: 'The selected file is not a valid ClassFlow JSON backup.',
        });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-6 pb-20 lg:pb-8">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Institute Settings</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Customise branding, batches, cash billing rules, and manage cloud synchronization
          </p>
        </div>

        {/* Sync status badge in settings */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleTriggerManualSync}
            disabled={isSyncingManual}
            className="flex items-center gap-1.5 py-2 px-3.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl border border-slate-200 transition-colors cursor-pointer disabled:opacity-60"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncingManual ? 'animate-spin' : ''}`} />
            <span>Sync Now</span>
          </button>
        </div>
      </div>

      {/* Cloud Sync & Account Status Card */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2.5">
            <Cloud className="w-5 h-5 text-blue-600" />
            <div>
              <h2 className="text-base font-bold text-slate-900">Cloud Account & Real-Time Sync</h2>
              <p className="text-xs text-slate-500">
                Automatic synchronization across Android phone and laptop browser
              </p>
            </div>
          </div>

          <button
            onClick={logout}
            className="flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-slate-400">Authenticated Owner:</span>
            <p className="font-bold text-slate-900 mt-0.5 text-sm">
              {authUser?.displayName || settings.ownerName}
            </p>
            <p className="text-[11px] text-slate-500 font-mono mt-0.5">{authUser?.email}</p>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-slate-400">Sync Status:</span>
            <div className="flex items-center gap-1.5 mt-1 font-bold">
              {syncStatus === 'synced' && (
                <span className="text-emerald-700 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  Synced to Firebase Cloud
                </span>
              )}
              {syncStatus === 'syncing' && (
                <span className="text-blue-700 flex items-center gap-1.5">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  Synchronizing...
                </span>
              )}
              {syncStatus === 'offline' && (
                <span className="text-slate-600 flex items-center gap-1.5">
                  <CloudOff className="w-3.5 h-3.5 text-slate-400" />
                  Offline Mode Active
                </span>
              )}
              {syncStatus === 'error' && (
                <span className="text-amber-700 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500" />
                  Sync Retrying
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">{syncMessage}</p>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
            <span className="text-slate-400">Data Security:</span>
            <p className="font-semibold text-slate-800 mt-0.5 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              Isolated Firestore Rules
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Only your authenticated account can read or modify your students and fees.
            </p>
          </div>
        </div>
      </div>

      {/* Grid: Institute Details & Cash Billing Configuration */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Institute Profile Form */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6">
          <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 mb-5">
            <Building2 className="w-5 h-5 text-blue-600" />
            <h2 className="text-base font-bold text-slate-900">Institute Profile & Branding</h2>
          </div>

          <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">
                  Institute / Coaching Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  placeholder="e.g. Lakshya Classes & Tutorials"
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 font-semibold text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Tagline / Motto
                </label>
                <input
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  placeholder="e.g. Nurturing Academic Excellence"
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-slate-700"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Director / Owner Name
                </label>
                <input
                  type="text"
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  placeholder="e.g. Er. Rajesh Tiwari"
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-slate-700"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Contact Phone / WhatsApp <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  value={contactNumber}
                  onChange={(e) => setContactNumber(e.target.value)}
                  required
                  placeholder="9876543210"
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="institute@gmail.com"
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">
                  Physical Address (Printed on Cash Receipts)
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Shop 14, 2nd Floor, Station Road, Kota, Rajasthan"
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                type="submit"
                className="flex items-center gap-2 py-2.5 px-5 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                <Save className="w-4 h-4 text-emerald-400" />
                <span>Save Profile Settings</span>
              </button>
            </div>
          </form>
        </div>

        {/* Right Column: Billing & Due Date Settings (CASH ONLY) */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6 space-y-5">
          <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100">
            <Banknote className="w-5 h-5 text-emerald-600" />
            <h2 className="text-base font-bold text-slate-900">Cash Billing Rules</h2>
          </div>

          <div className="space-y-4 text-xs">
            <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl">
              <span className="font-bold text-emerald-900">Payment Policy</span>
              <p className="text-[11px] text-emerald-700 mt-0.5 leading-relaxed">
                ClassFlow operates in <strong>Cash-Only</strong> mode. All student fee collections,
                vouchers, and payment ledgers are recorded in cash.
              </p>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Default Monthly Fee Due Day
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  max="28"
                  value={defaultFeeDueDay}
                  onChange={(e) => setDefaultFeeDueDay(e.target.value)}
                  className="w-20 px-3 py-2 text-xs rounded-xl border border-slate-300 font-mono font-bold text-slate-900"
                />
                <span className="text-slate-500 font-medium">th of every month</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Unpaid student fees are automatically flagged as overdue after this day.
              </p>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Receipt Number Prefix
              </label>
              <input
                type="text"
                value={receiptPrefix}
                onChange={(e) => setReceiptPrefix(e.target.value)}
                placeholder="CF"
                className="w-28 px-3 py-2 text-xs rounded-xl border border-slate-300 font-mono font-bold uppercase"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                e.g. {receiptPrefix || 'CF'}-2026-0001
              </p>
            </div>

            <button
              type="button"
              onClick={handleSaveProfile}
              className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs shadow-xs transition-colors cursor-pointer"
            >
              Update Billing Rules
            </button>
          </div>
        </div>
      </div>

      {/* Batches / Classes Configuration */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2.5">
            <Calendar className="w-5 h-5 text-purple-600" />
            <div>
              <h2 className="text-base font-bold text-slate-900">Manage Classes & Batches</h2>
              <p className="text-xs text-slate-500">Configure batches, class timings and schedules</p>
            </div>
          </div>

          <button
            onClick={handleOpenAddBatch}
            className="flex items-center gap-1.5 py-2 px-3 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors shadow-xs cursor-pointer"
          >
            <Plus className="w-4 h-4 text-blue-400" />
            <span>Add Batch</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {batches.map((batch) => {
            const enrolledStudents = students.filter((s) => s.batchId === batch.id);

            return (
              <div
                key={batch.id}
                className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 transition-colors flex items-start justify-between gap-3 bg-slate-50/50"
              >
                <div>
                  <h3 className="text-sm font-bold text-slate-900">{batch.name}</h3>
                  {batch.subject && (
                    <p className="text-xs text-blue-700 font-medium mt-0.5">{batch.subject}</p>
                  )}
                  <p className="text-xs text-slate-500 mt-1">
                    Timing: <span className="font-semibold text-slate-700">{batch.timing}</span>
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Days: {batch.days?.join(', ') || 'Regular'} · {enrolledStudents.length} students enrolled
                  </p>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => handleOpenEditBatch(batch)}
                    className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-200/70 rounded-lg transition-colors cursor-pointer"
                    title="Edit batch"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      if (window.confirm(`Delete batch "${batch.name}"?`)) {
                        deleteBatch(batch.id);
                      }
                    }}
                    className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                    title="Delete batch"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Data Backup, Export & Offline Storage Management */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 sm:p-6">
        <div className="flex items-center gap-2.5 pb-4 border-b border-slate-100 mb-4">
          <Download className="w-5 h-5 text-emerald-600" />
          <div>
            <h2 className="text-base font-bold text-slate-900">Database Backup & Recovery</h2>
            <p className="text-xs text-slate-500">
              Offline local backup with manual JSON export and restore
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Download JSON */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Download Full Backup</h3>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                Exports all students, attendance registers, tests, and cash receipts to an offline JSON file.
              </p>
            </div>
            <button
              onClick={handleExportBackup}
              className="mt-4 flex items-center justify-center gap-1.5 py-2 px-3 bg-white hover:bg-slate-100 text-slate-800 font-semibold text-xs rounded-xl border border-slate-300 transition-colors shadow-xs cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-600" />
              <span>Export JSON File</span>
            </button>
          </div>

          {/* Restore JSON */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Restore Backup File</h3>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                Upload a previous ClassFlow JSON file to restore all institute records.
              </p>
            </div>
            <label className="mt-4 flex items-center justify-center gap-1.5 py-2 px-3 bg-white hover:bg-slate-100 text-slate-800 font-semibold text-xs rounded-xl border border-slate-300 transition-colors shadow-xs cursor-pointer">
              <Upload className="w-4 h-4 text-blue-600" />
              <span>Select Backup File</span>
              <input
                type="file"
                accept=".json"
                onChange={handleImportFile}
                className="hidden"
              />
            </label>
          </div>

          {/* Reset Demo Data */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-bold text-slate-900">Reset Sample Data</h3>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                Reloads initial sample batches, students, attendance, and cash receipts for demonstration.
              </p>
            </div>
            <button
              onClick={() => {
                if (window.confirm('Reset all data to default demo sample data?')) {
                  resetAllData();
                }
              }}
              className="mt-4 flex items-center justify-center gap-1.5 py-2 px-3 bg-white hover:bg-rose-50 text-rose-700 font-semibold text-xs rounded-xl border border-rose-200 transition-colors shadow-xs cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-rose-600" />
              <span>Reset to Sample Data</span>
            </button>
          </div>
        </div>
      </div>

      {/* Add / Edit Batch Modal */}
      {isBatchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs"
            onClick={() => setIsBatchModalOpen(false)}
          />
          <div className="relative bg-white rounded-2xl shadow-2xl max-w-md w-full p-5 z-10 border border-slate-200 animate-in zoom-in-95 duration-150">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              {editingBatch ? 'Edit Class / Batch' : 'Create New Batch'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">Set batch title and class timetable</p>

            <form onSubmit={handleSaveBatch} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Batch Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={batchName}
                  onChange={(e) => setBatchName(e.target.value)}
                  placeholder="e.g. Class 10th - Science & Math"
                  required
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Subject / Description
                </label>
                <input
                  type="text"
                  value={batchSubject}
                  onChange={(e) => setBatchSubject(e.target.value)}
                  placeholder="e.g. CBSE & State Board Syllabus"
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Class Timing
                </label>
                <input
                  type="text"
                  value={batchTiming}
                  onChange={(e) => setBatchTiming(e.target.value)}
                  placeholder="e.g. 4:00 PM - 5:30 PM"
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1.5">
                  Scheduled Days
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {allDays.map((day) => {
                    const isSelected = batchDays.includes(day);
                    return (
                      <button
                        key={day}
                        type="button"
                        onClick={() => handleToggleDay(day)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
                          isSelected
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                        }`}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsBatchModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs cursor-pointer"
                >
                  {editingBatch ? 'Save Batch' : 'Create Batch'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
