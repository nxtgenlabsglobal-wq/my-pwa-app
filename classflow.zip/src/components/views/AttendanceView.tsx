import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  CalendarCheck,
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  Save,
  MessageSquare,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  History,
} from 'lucide-react';
import { AttendanceStatus } from '../../types';
import { formatDate, formatMonthName } from '../../utils/formatters';

export const AttendanceView: React.FC = () => {
  const {
    students,
    batches,
    attendance,
    todayDate,
    saveAttendance,
    setWhatsAppModalData,
    addToast,
  } = useApp();

  const [selectedBatchId, setSelectedBatchId] = useState<string>(batches[0]?.id || '');
  const [selectedDate, setSelectedDate] = useState<string>(todayDate);
  const [viewMode, setViewMode] = useState<'register' | 'history'>('register');

  // Temporary in-memory state for student attendance markings on the selected date
  const [markedStatusMap, setMarkedStatusMap] = useState<Record<string, AttendanceStatus>>({});
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState<boolean>(false);

  // Active students in the selected batch
  const batchStudents = useMemo(() => {
    return students
      .filter((s) => s.batchId === selectedBatchId && s.isActive)
      .sort((a, b) => (parseInt(a.rollNo, 10) || 0) - (parseInt(b.rollNo, 10) || 0));
  }, [students, selectedBatchId]);

  const selectedBatch = batches.find((b) => b.id === selectedBatchId);

  // Check if attendance already exists in storage for this batch & date
  const existingRecords = useMemo(() => {
    return attendance.filter((a) => a.batchId === selectedBatchId && a.date === selectedDate);
  }, [attendance, selectedBatchId, selectedDate]);

  const isAlreadyRecorded = existingRecords.length > 0;

  // Sync markedStatusMap when selectedBatchId or selectedDate changes
  useEffect(() => {
    const newMap: Record<string, AttendanceStatus> = {};
    batchStudents.forEach((student) => {
      const found = existingRecords.find((r) => r.studentId === student.id);
      if (found) {
        newMap[student.id] = found.status;
      } else {
        // Default to 'present' for fast marking
        newMap[student.id] = 'present';
      }
    });
    setMarkedStatusMap(newMap);
    setHasUnsavedChanges(false);
  }, [selectedBatchId, selectedDate, batchStudents, existingRecords]);

  const handleToggleStatus = (studentId: string, status: AttendanceStatus) => {
    setMarkedStatusMap((prev) => ({
      ...prev,
      [studentId]: status,
    }));
    setHasUnsavedChanges(true);
  };

  const handleMarkAll = (status: AttendanceStatus) => {
    const updated: Record<string, AttendanceStatus> = {};
    batchStudents.forEach((s) => {
      updated[s.id] = status;
    });
    setMarkedStatusMap(updated);
    setHasUnsavedChanges(true);
  };

  const handleSave = () => {
    if (batchStudents.length === 0) {
      addToast({
        type: 'warning',
        title: 'No Students in Batch',
        message: 'Add students to this batch before saving attendance.',
      });
      return;
    }

    const payload = batchStudents.map((s) => ({
      studentId: s.id,
      status: markedStatusMap[s.id] || 'present',
    }));

    saveAttendance(selectedBatchId, selectedDate, payload);
    setHasUnsavedChanges(false);
  };

  // Date navigation helpers
  const handleShiftDate = (days: number) => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + days);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  // Counters for the currently marked state
  const presentCount = Object.values(markedStatusMap).filter((s) => s === 'present').length;
  const absentCount = Object.values(markedStatusMap).filter((s) => s === 'absent').length;
  const lateCount = Object.values(markedStatusMap).filter((s) => s === 'late').length;

  // Monthly history grid calculation
  const currentMonthKey = selectedDate.substring(0, 7);
  const monthlyDates = useMemo(() => {
    const datesSet = new Set<string>();
    attendance
      .filter((a) => a.batchId === selectedBatchId && a.date.startsWith(currentMonthKey))
      .forEach((a) => datesSet.add(a.date));
    return Array.from(datesSet).sort();
  }, [attendance, selectedBatchId, currentMonthKey]);

  return (
    <div className="space-y-5 pb-20 lg:pb-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Class Attendance</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Daily roll call & monthly attendance history
          </p>
        </div>

        {/* View mode toggle */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
          <button
            onClick={() => setViewMode('register')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              viewMode === 'register'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <CalendarCheck className="w-4 h-4 text-blue-600" />
            <span>Daily Register</span>
          </button>

          <button
            onClick={() => setViewMode('history')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              viewMode === 'history'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-4 h-4 text-purple-600" />
            <span>Monthly Grid</span>
          </button>
        </div>
      </div>

      {/* Control Bar: Batch Selector & Date Selector */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
        {/* Batches horizontal pill bar */}
        <div>
          <label className="block text-xs font-semibold text-slate-500 mb-2">
            Select Class / Batch:
          </label>
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {batches.map((batch) => {
              const isSelected = batch.id === selectedBatchId;
              const count = students.filter((s) => s.batchId === batch.id && s.isActive).length;
              return (
                <button
                  key={batch.id}
                  onClick={() => setSelectedBatchId(batch.id)}
                  className={`flex items-center gap-2 py-2 px-3.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
                    isSelected
                      ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span>{batch.name}</span>
                  <span
                    className={`text-[11px] px-1.5 py-0.2 rounded-full font-mono ${
                      isSelected ? 'bg-blue-700 text-white' : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Date Selector Row */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100">
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleShiftDate(-1)}
              className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 border border-slate-200"
              title="Previous Day"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="relative">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="pl-3 pr-3 py-2 text-xs sm:text-sm font-semibold rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 bg-white"
              />
            </div>

            <button
              onClick={() => handleShiftDate(1)}
              className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 border border-slate-200"
              title="Next Day"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {selectedDate !== todayDate && (
              <button
                onClick={() => setSelectedDate(todayDate)}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800 px-2 py-1"
              >
                Go to Today
              </button>
            )}
          </div>

          {/* Quick Mark Presets */}
          {viewMode === 'register' && (
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-slate-400 font-medium">Bulk:</span>
              <button
                type="button"
                onClick={() => handleMarkAll('present')}
                className="py-1.5 px-3 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 transition-colors"
              >
                All Present
              </button>
              <button
                type="button"
                onClick={() => handleMarkAll('absent')}
                className="py-1.5 px-3 rounded-lg text-xs font-semibold bg-rose-50 text-rose-800 hover:bg-rose-100 border border-rose-200 transition-colors"
              >
                All Absent
              </button>
            </div>
          )}
        </div>
      </div>

      {viewMode === 'register' ? (
        <>
          {/* Safeguard Alert Banner */}
          {isAlreadyRecorded ? (
            <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-2xl flex items-center justify-between text-xs text-blue-900">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                <span>
                  Attendance already saved for <strong>{formatDate(selectedDate)}</strong>. You can safely edit and click Save below.
                </span>
              </div>
              <span className="text-[11px] font-mono text-blue-700 font-semibold shrink-0">
                Safeguard Active
              </span>
            </div>
          ) : (
            <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl flex items-center gap-2 text-xs text-amber-900">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                Not recorded yet for <strong>{formatDate(selectedDate)}</strong>. Mark below and tap <strong>Save Attendance</strong>.
              </span>
            </div>
          )}

          {/* Attendance Stats Bar */}
          <div className="grid grid-cols-3 gap-3 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs text-center">
            <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-100">
              <span className="text-[11px] font-semibold text-emerald-700">Present</span>
              <p className="text-xl font-bold font-mono text-emerald-800 mt-0.5">{presentCount}</p>
            </div>
            <div className="p-2 rounded-xl bg-rose-50 border border-rose-100">
              <span className="text-[11px] font-semibold text-rose-700">Absent</span>
              <p className="text-xl font-bold font-mono text-rose-800 mt-0.5">{absentCount}</p>
            </div>
            <div className="p-2 rounded-xl bg-amber-50 border border-amber-100">
              <span className="text-[11px] font-semibold text-amber-700">Late</span>
              <p className="text-xl font-bold font-mono text-amber-800 mt-0.5">{lateCount}</p>
            </div>
          </div>

          {/* Student Roll Call List */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            {batchStudents.length === 0 ? (
              <div className="text-center py-12 px-4 text-slate-400 text-xs">
                No active students enrolled in this batch yet.
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {batchStudents.map((student) => {
                  const currentStatus = markedStatusMap[student.id] || 'present';

                  return (
                    <div
                      key={student.id}
                      className="p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 transition-colors"
                    >
                      {/* Student info */}
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center font-bold text-xs shrink-0 font-mono">
                          {student.rollNo}
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                            {student.name}
                          </p>
                          <p className="text-[11px] text-slate-400 truncate">
                            Parent: {student.parentName || 'Guardian'} · +91 {student.parentContact}
                          </p>
                        </div>
                      </div>

                      {/* Touch-first Attendance status buttons (min-h-[44px] for easy tapping) */}
                      <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0">
                        <div className="grid grid-cols-3 gap-1.5 w-full sm:w-auto">
                          <button
                            type="button"
                            onClick={() => handleToggleStatus(student.id, 'present')}
                            className={`min-h-[44px] px-3.5 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                              currentStatus === 'present'
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Present</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleToggleStatus(student.id, 'absent')}
                            className={`min-h-[44px] px-3.5 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                              currentStatus === 'absent'
                                ? 'bg-rose-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Absent</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleToggleStatus(student.id, 'late')}
                            className={`min-h-[44px] px-3.5 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                              currentStatus === 'late'
                                ? 'bg-amber-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                            }`}
                          >
                            <Clock className="w-3.5 h-3.5" />
                            <span>Late</span>
                          </button>
                        </div>

                        {/* WhatsApp Parent Notification */}
                        {currentStatus === 'absent' && (
                          <button
                            type="button"
                            onClick={() =>
                              setWhatsAppModalData({
                                student,
                                type: 'attendance',
                                attendanceStatus: 'absent',
                                attendanceDate: selectedDate,
                              })
                            }
                            className="p-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 transition-colors shrink-0"
                            title="Send Absent Alert via WhatsApp"
                          >
                            <MessageSquare className="w-4 h-4 text-emerald-600" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Sticky Bottom Save Bar */}
          <div className="sticky bottom-16 lg:bottom-4 z-20 bg-white/95 backdrop-blur-md p-4 rounded-2xl border border-slate-200 shadow-xl flex items-center justify-between gap-4">
            <div className="text-xs text-slate-600">
              <span className="font-bold text-slate-900">{batchStudents.length} Students</span> in {selectedBatch?.name}
              {hasUnsavedChanges && (
                <span className="ml-2 text-rose-600 font-semibold">• Unsaved Changes</span>
              )}
            </div>

            <button
              onClick={handleSave}
              className="flex items-center gap-2 py-3 px-6 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-bold shadow-md shadow-slate-900/10 active:scale-[0.99] transition-all"
            >
              <Save className="w-4 h-4 text-emerald-400" />
              <span>Save Attendance</span>
            </button>
          </div>
        </>
      ) : (
        /* Monthly History Grid Matrix */
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 overflow-hidden">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Attendance Matrix — {formatMonthName(currentMonthKey)}
              </h3>
              <p className="text-xs text-slate-500">
                Historical record of sessions for {selectedBatch?.name}
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1 text-emerald-700 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> P: Present
              </span>
              <span className="flex items-center gap-1 text-rose-700 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> A: Absent
              </span>
              <span className="flex items-center gap-1 text-amber-700 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> L: Late
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold bg-slate-50">
                  <th className="p-3 sticky left-0 bg-slate-50 z-10">Student</th>
                  {monthlyDates.map((d) => (
                    <th key={d} className="p-2 text-center font-mono whitespace-nowrap">
                      {d.slice(8)}
                    </th>
                  ))}
                  <th className="p-3 text-right">Summary</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {batchStudents.map((student) => {
                  const studentRecords = attendance.filter(
                    (a) => a.studentId === student.id && a.date.startsWith(currentMonthKey)
                  );
                  const presentTotal = studentRecords.filter((a) => a.status === 'present').length;
                  const lateTotal = studentRecords.filter((a) => a.status === 'late').length;
                  const absentTotal = studentRecords.filter((a) => a.status === 'absent').length;
                  const total = studentRecords.length;
                  const pct = total > 0 ? Math.round(((presentTotal + lateTotal) / total) * 100) : 0;

                  return (
                    <tr key={student.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="p-3 font-semibold text-slate-900 sticky left-0 bg-white z-10 border-r border-slate-100">
                        {student.name}
                        <span className="text-[10px] text-slate-400 font-mono ml-1.5">
                          #{student.rollNo}
                        </span>
                      </td>

                      {monthlyDates.map((d) => {
                        const rec = studentRecords.find((r) => r.date === d);
                        const status = rec?.status;
                        return (
                          <td key={d} className="p-1.5 text-center font-mono">
                            {status === 'present' && (
                              <span className="w-6 h-6 inline-flex items-center justify-center rounded-md bg-emerald-100 text-emerald-800 font-bold text-[11px]">
                                P
                              </span>
                            )}
                            {status === 'absent' && (
                              <span className="w-6 h-6 inline-flex items-center justify-center rounded-md bg-rose-100 text-rose-800 font-bold text-[11px]">
                                A
                              </span>
                            )}
                            {status === 'late' && (
                              <span className="w-6 h-6 inline-flex items-center justify-center rounded-md bg-amber-100 text-amber-800 font-bold text-[11px]">
                                L
                              </span>
                            )}
                            {!status && <span className="text-slate-300">-</span>}
                          </td>
                        );
                      })}

                      <td className="p-3 text-right font-mono font-bold text-slate-800">
                        <span className={pct >= 75 ? 'text-emerald-700' : 'text-amber-600'}>
                          {pct}%
                        </span>
                        <span className="text-slate-400 text-[10px] ml-1">
                          ({presentTotal}/{total})
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
