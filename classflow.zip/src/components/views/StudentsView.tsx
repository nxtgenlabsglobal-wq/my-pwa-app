import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  Search,
  Plus,
  Filter,
  Phone,
  MessageSquare,
  CreditCard,
  Edit2,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  MoreVertical,
} from 'lucide-react';
import { formatCurrency, formatDate, exportToCSV } from '../../utils/formatters';

export const StudentsView: React.FC = () => {
  const {
    students,
    batches,
    studentFeeSummaries,
    getStudentAttendanceSummary,
    setSelectedStudentId,
    setEditingStudent,
    setIsAddStudentModalOpen,
    setPreselectedPaymentStudentId,
    setIsRecordPaymentModalOpen,
    setWhatsAppModalData,
    toggleStudentStatus,
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBatchId, setSelectedBatchId] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('active');
  const [feeStatusFilter, setFeeStatusFilter] = useState<'all' | 'overdue' | 'paid'>('all');

  const filteredStudents = useMemo(() => {
    return students.filter((student) => {
      // Search term
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const matchesName = student.name.toLowerCase().includes(query);
        const matchesRoll = student.rollNo.toLowerCase().includes(query);
        const matchesPhone = student.parentContact.includes(query);
        if (!matchesName && !matchesRoll && !matchesPhone) return false;
      }

      // Batch filter
      if (selectedBatchId !== 'all' && student.batchId !== selectedBatchId) {
        return false;
      }

      // Active / Inactive
      if (statusFilter === 'active' && !student.isActive) return false;
      if (statusFilter === 'inactive' && student.isActive) return false;

      // Fee status filter
      if (feeStatusFilter !== 'all') {
        const feeSummary = studentFeeSummaries.find((s) => s.student.id === student.id);
        if (feeStatusFilter === 'overdue' && !feeSummary?.isOverdue) return false;
        if (feeStatusFilter === 'paid' && feeSummary?.status !== 'paid') return false;
      }

      return true;
    });
  }, [students, searchTerm, selectedBatchId, statusFilter, feeStatusFilter, studentFeeSummaries]);

  const handleExportCSV = () => {
    const rows = filteredStudents.map((s) => {
      const batch = batches.find((b) => b.id === s.batchId);
      const fee = studentFeeSummaries.find((fs) => fs.student.id === s.id);
      const att = getStudentAttendanceSummary(s.id);

      return {
        'Roll No': s.rollNo,
        'Student Name': s.name,
        'Class / Batch': batch?.name || '',
        'Parent Name': s.parentName || '',
        'Parent Contact': s.parentContact,
        'Monthly Fee (INR)': s.monthlyFee,
        'Fee Status (This Month)': fee?.status || 'pending',
        'Current Due (INR)': fee?.balanceThisMonth || 0,
        'Attendance %': `${att.percentage}%`,
        'Admission Date': s.admissionDate,
        'Active Status': s.isActive ? 'Active' : 'Inactive',
        Notes: s.notes || '',
      };
    });

    exportToCSV(`ClassFlow_Students_${new Date().toISOString().split('T')[0]}`, rows);
  };

  return (
    <div className="space-y-5 pb-20 lg:pb-8">
      {/* Top Bar with Title, Count & Primary CTAs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Student Directory</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {filteredStudents.length} of {students.length} students matching criteria
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 py-2.5 px-3.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
            title="Download CSV"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          <button
            onClick={() => {
              setEditingStudent(null);
              setIsAddStudentModalOpen(true);
            }}
            className="flex items-center gap-1.5 py-2.5 px-4 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4 text-blue-400" />
            <span>Enroll Student</span>
          </button>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          {/* Search box */}
          <div className="sm:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by student name, roll # or mobile number..."
              className="w-full pl-10 pr-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all placeholder:text-slate-400"
            />
          </div>

          {/* Batch Selector */}
          <div>
            <select
              value={selectedBatchId}
              onChange={(e) => setSelectedBatchId(e.target.value)}
              className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 bg-white"
            >
              <option value="all">All Batches ({batches.length})</option>
              {batches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
          </div>

          {/* Active / Inactive filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 bg-white"
            >
              <option value="active">Active Enrolled</option>
              <option value="inactive">Inactive / Past</option>
              <option value="all">All Students</option>
            </select>
          </div>
        </div>

        {/* Quick status tabs */}
        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100 text-xs">
          <span className="text-slate-400 font-medium">Fee Filter:</span>
          <button
            onClick={() => setFeeStatusFilter('all')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              feeStatusFilter === 'all'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFeeStatusFilter('overdue')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              feeStatusFilter === 'overdue'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-rose-50 text-rose-700 hover:bg-rose-100'
            }`}
          >
            Overdue Fees
          </button>
          <button
            onClick={() => setFeeStatusFilter('paid')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              feeStatusFilter === 'paid'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
            }`}
          >
            Fully Paid This Month
          </button>
        </div>
      </div>

      {/* Student List View (Mobile touch cards + Desktop clean table) */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {filteredStudents.length === 0 ? (
          <div className="text-center py-16 px-4">
            <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-slate-700">No students found</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              No students match the selected filter criteria. Try resetting filters or adding a new student.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredStudents.map((student) => {
              const batch = batches.find((b) => b.id === student.batchId);
              const feeSummary = studentFeeSummaries.find((fs) => fs.student.id === student.id);
              const attSummary = getStudentAttendanceSummary(student.id);

              return (
                <div
                  key={student.id}
                  className="p-4 sm:p-4.5 hover:bg-slate-50/70 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  {/* Left: Avatar & Student details */}
                  <div
                    onClick={() => setSelectedStudentId(student.id)}
                    className="flex items-center gap-3.5 cursor-pointer min-w-0 flex-1"
                  >
                    <div className="w-11 h-11 rounded-2xl bg-slate-900 text-white flex items-center justify-center font-bold text-sm shrink-0 shadow-xs">
                      {student.name.charAt(0)}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm hover:text-blue-600 transition-colors truncate">
                          {student.name}
                        </span>
                        <span className="text-xs font-mono text-slate-400">#{student.rollNo}</span>
                        {!student.isActive && (
                          <span className="text-[10px] font-semibold bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full">
                            Inactive
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500 mt-1">
                        <span className="font-medium text-slate-700">{batch?.name || 'Class'}</span>
                        <span className="text-slate-300">·</span>
                        <span>Ph: +91 {student.parentContact}</span>
                        {student.parentName && (
                          <>
                            <span className="text-slate-300">·</span>
                            <span>({student.parentName})</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Middle: Attendance & Fee Indicators */}
                  <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0 text-xs pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                    {/* Attendance percentage */}
                    <div className="text-left sm:text-right">
                      <p className="text-[11px] text-slate-400">Attendance</p>
                      <p
                        className={`font-bold font-mono text-xs ${
                          attSummary.percentage >= 75 ? 'text-emerald-700' : 'text-amber-600'
                        }`}
                      >
                        {attSummary.percentage}% ({attSummary.presentDays}d)
                      </p>
                    </div>

                    {/* Fee Status */}
                    <div className="text-left sm:text-right min-w-[90px]">
                      <p className="text-[11px] text-slate-400">Monthly Fee</p>
                      <div className="flex items-center sm:justify-end gap-1">
                        <span className="font-bold font-mono text-slate-900">
                          {formatCurrency(student.monthlyFee)}
                        </span>
                      </div>
                      <p
                        className={`text-[10px] font-semibold mt-0.5 ${
                          feeSummary?.status === 'paid'
                            ? 'text-emerald-600'
                            : feeSummary?.isOverdue
                            ? 'text-rose-600'
                            : 'text-amber-600'
                        }`}
                      >
                        {feeSummary?.status === 'paid'
                          ? 'Paid'
                          : `Due: ${formatCurrency(feeSummary?.balanceThisMonth || 0)}`}
                      </p>
                    </div>

                    {/* Quick action buttons */}
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() =>
                          setWhatsAppModalData({
                            student,
                            type: 'fee_reminder',
                          })
                        }
                        className="p-2 rounded-xl text-emerald-700 hover:bg-emerald-50 border border-emerald-200 transition-colors"
                        title="Send WhatsApp Reminder"
                      >
                        <MessageSquare className="w-4 h-4 text-emerald-600" />
                      </button>

                      <button
                        onClick={() => {
                          setPreselectedPaymentStudentId(student.id);
                          setIsRecordPaymentModalOpen(true);
                        }}
                        className="p-2 rounded-xl text-slate-700 hover:bg-slate-100 border border-slate-200 transition-colors"
                        title="Record Payment"
                      >
                        <CreditCard className="w-4 h-4 text-blue-600" />
                      </button>

                      <button
                        onClick={() => {
                          setEditingStudent(student);
                          setIsAddStudentModalOpen(true);
                        }}
                        className="p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
                        title="Edit details"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
