import React from 'react';
import { useApp } from '../../context/AppContext';
import { TabType } from '../../types';
import {
  LayoutDashboard,
  Users,
  CalendarCheck,
  CreditCard,
  BarChart3,
  Settings,
  PlusCircle,
  IndianRupee,
  GraduationCap,
  Cloud,
  CloudOff,
  RefreshCw,
  LogOut,
  User,
  Award,
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    settings,
    students,
    studentFeeSummaries,
    authUser,
    logout,
    syncStatus,
    syncMessage,
    manualSyncNow,
    setIsAddStudentModalOpen,
    setEditingStudent,
    setIsRecordPaymentModalOpen,
    setPreselectedPaymentStudentId,
  } = useApp();

  const activeStudentsCount = students.filter((s) => s.isActive).length;
  const overdueCount = studentFeeSummaries.filter((s) => s.isOverdue).length;

  const navItems: { id: TabType; label: string; icon: React.ReactNode; badge?: string | number; badgeColor?: string }[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: <LayoutDashboard className="w-5 h-5 shrink-0" />,
    },
    {
      id: 'students',
      label: 'Students',
      icon: <Users className="w-5 h-5 shrink-0" />,
      badge: activeStudentsCount,
    },
    {
      id: 'attendance',
      label: 'Attendance',
      icon: <CalendarCheck className="w-5 h-5 shrink-0" />,
    },
    {
      id: 'fees',
      label: 'Fees & Cash Ledger',
      icon: <CreditCard className="w-5 h-5 shrink-0" />,
      badge: overdueCount > 0 ? `${overdueCount} due` : undefined,
      badgeColor: 'text-rose-600 bg-rose-50 border-rose-200',
    },
    {
      id: 'reports',
      label: 'Reports & Tests',
      icon: <BarChart3 className="w-5 h-5 shrink-0" />,
    },
    {
      id: 'settings',
      label: 'Institute Settings',
      icon: <Settings className="w-5 h-5 shrink-0" />,
    },
  ];

  const handleOpenAddStudent = () => {
    setEditingStudent(null);
    setIsAddStudentModalOpen(true);
  };

  const handleOpenRecordPayment = () => {
    setPreselectedPaymentStudentId(null);
    setIsRecordPaymentModalOpen(true);
  };

  return (
    <aside className="hidden lg:flex flex-col w-64 bg-white border-r border-slate-200 h-screen sticky top-0 shrink-0 select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-white shadow-md shadow-slate-900/10 shrink-0">
            <GraduationCap className="w-6 h-6 text-blue-400" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="font-bold text-slate-900 text-base leading-tight truncate">
              {settings.name || 'ClassFlow'}
            </h1>
            <p className="text-xs text-slate-500 truncate mt-0.5 font-medium">
              {settings.tagline || 'Institute Management'}
            </p>
          </div>
        </div>
      </div>

      {/* Cloud Sync Status Strip */}
      <div className="px-4 py-2.5 bg-slate-50/80 border-b border-slate-100 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 min-w-0">
          {syncStatus === 'synced' && (
            <span className="flex items-center gap-1.5 text-emerald-700 font-semibold truncate">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Cloud Synced</span>
            </span>
          )}
          {syncStatus === 'syncing' && (
            <span className="flex items-center gap-1.5 text-blue-700 font-semibold truncate">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>Syncing...</span>
            </span>
          )}
          {syncStatus === 'offline' && (
            <span className="flex items-center gap-1.5 text-slate-500 font-semibold truncate">
              <CloudOff className="w-3.5 h-3.5 text-slate-400" />
              <span>Offline Mode</span>
            </span>
          )}
          {syncStatus === 'error' && (
            <span className="flex items-center gap-1.5 text-amber-700 font-semibold truncate">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              <span>Sync Retry</span>
            </span>
          )}
        </div>

        <button
          onClick={manualSyncNow}
          title="Force Sync with Cloud"
          className="p-1 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-200 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Quick Action Buttons */}
      <div className="p-4 space-y-2 border-b border-slate-100">
        <button
          onClick={handleOpenAddStudent}
          className="w-full flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-200 shadow-xs cursor-pointer"
        >
          <PlusCircle className="w-4 h-4 text-blue-600" />
          <span>Add New Student</span>
        </button>

        <button
          onClick={handleOpenRecordPayment}
          className="w-full flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-xs cursor-pointer"
        >
          <IndianRupee className="w-4 h-4 text-emerald-400" />
          <span>Record Cash Fee</span>
        </button>
      </div>

      {/* Navigation Items */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
          Main Menu
        </div>
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer ${
                isActive
                  ? 'bg-blue-50 text-blue-900 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <span className={isActive ? 'text-blue-600' : 'text-slate-400'}>
                  {item.icon}
                </span>
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge !== undefined && (
                <span
                  className={`text-xs px-2 py-0.5 rounded-full font-semibold border ${
                    item.badgeColor ||
                    (isActive
                      ? 'bg-blue-100 text-blue-800 border-blue-200'
                      : 'bg-slate-100 text-slate-600 border-slate-200')
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* User Account & Logout Footer */}
      <div className="p-3.5 border-t border-slate-100 bg-slate-50/70">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs shrink-0 overflow-hidden">
              {authUser?.photoURL ? (
                <img
                  src={authUser.photoURL}
                  alt={authUser.displayName || 'Owner'}
                  className="w-full h-full object-cover"
                />
              ) : (
                authUser?.displayName?.charAt(0) || <User className="w-4 h-4" />
              )}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-slate-800 truncate">
                {authUser?.displayName || settings.ownerName || 'Director'}
              </p>
              <p className="text-[10px] text-slate-500 truncate font-mono">
                {authUser?.email || 'Local Owner'}
              </p>
            </div>
          </div>

          <button
            onClick={logout}
            title="Sign Out"
            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
