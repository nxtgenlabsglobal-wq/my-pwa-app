import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TabType } from '../../types';
import {
  LayoutDashboard,
  Users,
  CalendarCheck,
  CreditCard,
  BarChart3,
  Settings,
  Plus,
  GraduationCap,
  IndianRupee,
  Share2,
  X,
  RefreshCw,
  LogOut,
} from 'lucide-react';
import { formatDate } from '../../utils/formatters';

export const MobileNav: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    settings,
    todayDate,
    syncStatus,
    manualSyncNow,
    logout,
    authUser,
    setIsAddStudentModalOpen,
    setEditingStudent,
    setIsRecordPaymentModalOpen,
    setPreselectedPaymentStudentId,
  } = useApp();

  const [isQuickMenuOpen, setIsQuickMenuOpen] = useState(false);

  const mainTabs: { id: TabType; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'Home', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'attendance', label: 'Attendance', icon: <CalendarCheck className="w-5 h-5" /> },
    { id: 'fees', label: 'Fees', icon: <CreditCard className="w-5 h-5" /> },
    { id: 'students', label: 'Students', icon: <Users className="w-5 h-5" /> },
    { id: 'reports', label: 'Reports', icon: <BarChart3 className="w-5 h-5" /> },
  ];

  return (
    <>
      {/* Mobile Top App Bar */}
      <header className="lg:hidden sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 h-14 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center text-white shrink-0">
            <GraduationCap className="w-4 h-4 text-blue-400" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm font-bold text-slate-900 truncate leading-tight">
                {settings.name || 'ClassFlow'}
              </h1>
              {syncStatus === 'synced' && (
                <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" title="Synced" />
              )}
              {syncStatus === 'syncing' && (
                <RefreshCw className="w-3 h-3 text-blue-600 animate-spin shrink-0" />
              )}
            </div>
            <p className="text-[11px] text-slate-500 font-medium truncate">
              {formatDate(todayDate)}
            </p>
          </div>
        </div>

        {/* Right side actions */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={manualSyncNow}
            className="p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100"
            title="Sync Now"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`p-2 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors ${
              activeTab === 'settings' ? 'bg-blue-50 text-blue-700' : ''
            }`}
            aria-label="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>

          <button
            onClick={() => setIsQuickMenuOpen(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-white bg-slate-900 active:bg-slate-800 rounded-lg shadow-xs"
            aria-label="Quick Actions"
          >
            <Plus className="w-4 h-4" />
            <span>New</span>
          </button>
        </div>
      </header>

      {/* Mobile Bottom Tab Bar */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 pb-[env(safe-area-inset-bottom,0px)] shadow-lg">
        <div className="grid grid-cols-5 h-16 items-center">
          {mainTabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors relative cursor-pointer ${
                  isActive ? 'text-blue-600 font-semibold' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <div className="relative">
                  {tab.icon}
                  {isActive && (
                    <span className="absolute -top-1 -right-1 w-1.5 h-1.5 rounded-full bg-blue-600" />
                  )}
                </div>
                <span className="text-[10px] mt-1 tracking-tight truncate max-w-[60px]">
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Quick Action Bottom Sheet Modal */}
      {isQuickMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex flex-col justify-end">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
            onClick={() => setIsQuickMenuOpen(false)}
          />

          <div className="relative bg-white rounded-t-3xl p-5 shadow-2xl border-t border-slate-200 z-10 animate-in slide-in-from-bottom-6 duration-200">
            {/* Grab handle */}
            <div className="w-12 h-1 bg-slate-300 rounded-full mx-auto mb-4" />

            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-base font-bold text-slate-900">Quick Actions</h2>
                <p className="text-xs text-slate-400">
                  {authUser?.email ? `Signed in as ${authUser.email}` : 'Local Offline Mode'}
                </p>
              </div>
              <button
                onClick={() => setIsQuickMenuOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-4">
              <button
                onClick={() => {
                  setIsQuickMenuOpen(false);
                  setEditingStudent(null);
                  setIsAddStudentModalOpen(true);
                }}
                className="flex flex-col items-start p-3.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-left transition-colors"
              >
                <div className="w-9 h-9 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center mb-2">
                  <Users className="w-5 h-5" />
                </div>
                <span className="text-xs font-bold text-slate-900">Add Student</span>
                <span className="text-[11px] text-slate-500 mt-0.5">Enroll new admission</span>
              </button>

              <button
                onClick={() => {
                  setIsQuickMenuOpen(false);
                  setPreselectedPaymentStudentId(null);
                  setIsRecordPaymentModalOpen(true);
                }}
                className="flex flex-col items-start p-3.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-left transition-colors"
              >
                <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center mb-2">
                  <IndianRupee className="w-5 h-5" />
                </div>
                <span className="text-xs font-bold text-slate-900">Record Cash Fee</span>
                <span className="text-[11px] text-slate-500 mt-0.5">Cash receipt voucher</span>
              </button>

              <button
                onClick={() => {
                  setIsQuickMenuOpen(false);
                  setActiveTab('attendance');
                }}
                className="flex flex-col items-start p-3.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-left transition-colors"
              >
                <div className="w-9 h-9 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center mb-2">
                  <CalendarCheck className="w-5 h-5" />
                </div>
                <span className="text-xs font-bold text-slate-900">Mark Attendance</span>
                <span className="text-[11px] text-slate-500 mt-0.5">Daily roll call</span>
              </button>

              <button
                onClick={() => {
                  setIsQuickMenuOpen(false);
                  setActiveTab('fees');
                }}
                className="flex flex-col items-start p-3.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-left transition-colors"
              >
                <div className="w-9 h-9 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center mb-2">
                  <Share2 className="w-5 h-5" />
                </div>
                <span className="text-xs font-bold text-slate-900">WhatsApp Reminder</span>
                <span className="text-[11px] text-slate-500 mt-0.5">Send pending fee alerts</span>
              </button>
            </div>

            {/* Logout button on mobile */}
            <button
              onClick={() => {
                setIsQuickMenuOpen(false);
                logout();
              }}
              className="w-full py-2.5 px-4 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-xl border border-rose-200 flex items-center justify-center gap-1.5 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out of Account</span>
            </button>
          </div>
        </div>
      )}
    </>
  );
};
