import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  GraduationCap,
  ShieldCheck,
  Smartphone,
  Laptop,
  WifiOff,
  Cloud,
  ArrowRight,
  AlertCircle,
  IndianRupee,
  Lock,
} from 'lucide-react';

export const LoginView: React.FC = () => {
  const { loginWithGoogle, continueAsOfflineDemo } = useApp();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    try {
      setLoading(true);
      setError(null);
      await loginWithGoogle();
    } catch (err: any) {
      console.error('Sign-in error:', err);
      setError(
        err?.message ||
          'Unable to sign in with Google. Please check your popup permissions or try offline mode.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Brand Banner */}
        <div className="bg-slate-900 p-7 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl" />
          <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md text-white flex items-center justify-center mx-auto mb-3.5 border border-white/15 shadow-md">
            <GraduationCap className="w-8 h-8 text-blue-400" />
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">ClassFlow</h1>
          <p className="text-xs text-slate-300 mt-1 max-w-xs mx-auto">
            Attendance & Cash Fees Management System for Indian Coaching Institutes
          </p>

          <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-[11px] font-semibold text-emerald-300 border border-white/10">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Private & Encrypted Multi-Device Cloud Sync</span>
          </div>
        </div>

        {/* Card Body */}
        <div className="p-6 sm:p-7 space-y-5">
          {error && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-xs text-rose-800">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Value Props */}
          <div className="space-y-3 py-1">
            <div className="flex items-start gap-3">
              <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0 mt-0.5">
                <Laptop className="w-4 h-4" />
              </div>
              <div className="text-xs">
                <p className="font-bold text-slate-800">Real-Time Phone & Laptop Sync</p>
                <p className="text-slate-500 mt-0.5">
                  Access your tuition center data seamlessly from both Android mobile and computer.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                <IndianRupee className="w-4 h-4" />
              </div>
              <div className="text-xs">
                <p className="font-bold text-slate-800">Cash-Only Tuition Tracking</p>
                <p className="text-slate-500 mt-0.5">
                  Simplified cash vouchers, receipts, pending dues, and 1-tap WhatsApp reminders.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-7 h-7 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center shrink-0 mt-0.5">
                <WifiOff className="w-4 h-4" />
              </div>
              <div className="text-xs">
                <p className="font-bold text-slate-800">100% Offline Capable</p>
                <p className="text-slate-500 mt-0.5">
                  Mark attendance and record cash fees without internet; syncs automatically when online.
                </p>
              </div>
            </div>
          </div>

          {/* Sign In Button */}
          <div className="pt-2 space-y-3">
            <button
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 active:scale-[0.99] text-white text-xs sm:text-sm font-bold shadow-md shadow-slate-900/10 transition-all cursor-pointer disabled:opacity-60"
            >
              {/* Google icon */}
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{loading ? 'Signing in...' : 'Sign In with Google'}</span>
            </button>

            {/* Offline Demo fallback button */}
            <button
              onClick={continueAsOfflineDemo}
              className="w-full py-2.5 px-4 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl border border-slate-200 transition-colors"
            >
              Continue Offline in Local Mode
            </button>
          </div>

          {/* Privacy Note */}
          <div className="pt-2 text-center text-[11px] text-slate-400">
            <Lock className="w-3 h-3 inline mr-1 text-slate-400" />
            Protected by Cloud Firestore Security Rules. Only you can view or edit your students.
          </div>
        </div>
      </div>
    </div>
  );
};
