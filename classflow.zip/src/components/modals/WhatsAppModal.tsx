import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Send, Copy, Check, MessageSquare, Phone } from 'lucide-react';
import {
  generateWhatsAppFeeReminder,
  generateWhatsAppReceiptMessage,
  generateWhatsAppAttendanceMessage,
  generateWhatsAppTestReport,
  getWhatsAppUrl,
  formatMonthName,
} from '../../utils/formatters';

export const WhatsAppModal: React.FC = () => {
  const {
    whatsAppModalData,
    setWhatsAppModalData,
    settings,
    batches,
    payments,
    currentMonth,
    addToast,
  } = useApp();

  const [messageText, setMessageText] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [copied, setCopied] = useState(false);
  const [activeTemplate, setActiveTemplate] = useState<'fee_reminder' | 'receipt' | 'attendance' | 'test'>('fee_reminder');

  useEffect(() => {
    if (!whatsAppModalData) return;

    const { student, type, payment, attendanceStatus, attendanceDate, test, testResult } = whatsAppModalData;
    setActiveTemplate(type);
    setPhoneNumber(student.parentContact || '');

    const batch = batches.find((b) => b.id === student.batchId);

    if (type === 'receipt' && payment) {
      const totalPaidForMonth = payments
        .filter((p) => p.studentId === student.id && p.monthFor === payment.monthFor)
        .reduce((sum, p) => sum + p.amount, 0);
      const remaining = Math.max(0, student.monthlyFee - totalPaidForMonth);
      setMessageText(generateWhatsAppReceiptMessage(payment, student, batch, remaining, settings));
    } else if (type === 'attendance') {
      const status = attendanceStatus || 'present';
      const date = attendanceDate || new Date().toISOString().split('T')[0];
      setMessageText(generateWhatsAppAttendanceMessage(student, batch, status, date, settings));
    } else if (type === 'test' && test) {
      setMessageText(generateWhatsAppTestReport(student, batch, test, testResult, settings));
    } else {
      // Fee Reminder: Cash Only
      const paidThisMonth = payments
        .filter((p) => p.studentId === student.id && p.monthFor === currentMonth)
        .reduce((sum, p) => sum + p.amount, 0);
      const pending = Math.max(0, student.monthlyFee - paidThisMonth);
      const dueDate = `${settings.defaultFeeDueDay || 5}th of ${formatMonthName(currentMonth)}`;
      setMessageText(
        generateWhatsAppFeeReminder(
          student,
          batch,
          pending > 0 ? pending : student.monthlyFee,
          settings,
          formatMonthName(currentMonth),
          dueDate
        )
      );
    }
  }, [whatsAppModalData, batches, payments, currentMonth, settings]);

  if (!whatsAppModalData) return null;

  const { student } = whatsAppModalData;
  const batch = batches.find((b) => b.id === student.batchId);

  const handleCopy = () => {
    navigator.clipboard.writeText(messageText);
    setCopied(true);
    addToast({
      type: 'info',
      title: 'Message Copied',
      message: 'WhatsApp text copied to clipboard.',
    });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenWhatsApp = () => {
    const url = getWhatsAppUrl(phoneNumber, messageText);
    window.open(url, '_blank', 'noopener,noreferrer');
    setWhatsAppModalData(null);
  };

  const handleSwitchTemplate = (type: 'fee_reminder' | 'receipt' | 'attendance' | 'test') => {
    setActiveTemplate(type);
    if (type === 'fee_reminder') {
      const paidThisMonth = payments
        .filter((p) => p.studentId === student.id && p.monthFor === currentMonth)
        .reduce((sum, p) => sum + p.amount, 0);
      const pending = Math.max(0, student.monthlyFee - paidThisMonth);
      const dueDate = `${settings.defaultFeeDueDay || 5}th of ${formatMonthName(currentMonth)}`;
      setMessageText(
        generateWhatsAppFeeReminder(
          student,
          batch,
          pending > 0 ? pending : student.monthlyFee,
          settings,
          formatMonthName(currentMonth),
          dueDate
        )
      );
    } else if (type === 'receipt') {
      const latestPayment = payments.find((p) => p.studentId === student.id);
      if (latestPayment) {
        const totalPaidForMonth = payments
          .filter((p) => p.studentId === student.id && p.monthFor === latestPayment.monthFor)
          .reduce((sum, p) => sum + p.amount, 0);
        const remaining = Math.max(0, student.monthlyFee - totalPaidForMonth);
        setMessageText(generateWhatsAppReceiptMessage(latestPayment, student, batch, remaining, settings));
      } else {
        setMessageText(`*Cash Fee Receipt - ${settings.name}*\n\nCash fee acknowledgment for ${student.name}.`);
      }
    } else if (type === 'test') {
      setMessageText(
        `*Test Report - ${settings.name}*\n\nStudent: ${student.name}\nClass: ${batch?.name || ''}\nRecent academic test performance report.`
      );
    } else {
      setMessageText(
        generateWhatsAppAttendanceMessage(
          student,
          batch,
          'present',
          new Date().toISOString().split('T')[0],
          settings
        )
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
        onClick={() => setWhatsAppModalData(null)}
      />

      {/* Modal Dialog */}
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[92vh] flex flex-col overflow-hidden z-10 border border-slate-200 animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-emerald-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Share via WhatsApp</h2>
              <p className="text-xs text-slate-500">
                To: {student.name} ({student.parentName || 'Parent'})
              </p>
            </div>
          </div>
          <button
            onClick={() => setWhatsAppModalData(null)}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Template Switcher */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1.5">
              Select Message Template:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => handleSwitchTemplate('fee_reminder')}
                className={`py-2 px-2 text-xs font-semibold rounded-xl border text-center transition-all ${
                  activeTemplate === 'fee_reminder'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Cash Reminder
              </button>
              <button
                type="button"
                onClick={() => handleSwitchTemplate('receipt')}
                className={`py-2 px-2 text-xs font-semibold rounded-xl border text-center transition-all ${
                  activeTemplate === 'receipt'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Cash Receipt
              </button>
              <button
                type="button"
                onClick={() => handleSwitchTemplate('attendance')}
                className={`py-2 px-2 text-xs font-semibold rounded-xl border text-center transition-all ${
                  activeTemplate === 'attendance'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Attendance
              </button>
              <button
                type="button"
                onClick={() => handleSwitchTemplate('test')}
                className={`py-2 px-2 text-xs font-semibold rounded-xl border text-center transition-all ${
                  activeTemplate === 'test'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Test Report
              </button>
            </div>
          </div>

          {/* Recipient Phone */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              WhatsApp Recipient Number
            </label>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400">
                  +91
                </span>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                  className="w-full pl-12 pr-3.5 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 font-mono"
                  placeholder="9876543210"
                />
              </div>
              <a
                href={`tel:${phoneNumber}`}
                className="p-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50"
                title="Call phone"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Editable Message Text Box */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-slate-700">
                Message Preview (Editable Before Sending)
              </label>
              <button
                type="button"
                onClick={handleCopy}
                className="text-xs text-slate-600 hover:text-slate-900 font-medium flex items-center gap-1"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-600">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Text</span>
                  </>
                )}
              </button>
            </div>
            <textarea
              rows={8}
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              className="w-full p-3.5 text-xs text-slate-800 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 font-sans leading-relaxed whitespace-pre-wrap"
            />
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-100 bg-white flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setWhatsAppModalData(null)}
            className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleOpenWhatsApp}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 active:scale-[0.99] transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Open in WhatsApp</span>
          </button>
        </div>
      </div>
    </div>
  );
};
