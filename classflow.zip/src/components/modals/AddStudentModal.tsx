import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { X, UserPlus, Save, AlertCircle } from 'lucide-react';

export const AddStudentModal: React.FC = () => {
  const {
    isAddStudentModalOpen,
    setIsAddStudentModalOpen,
    editingStudent,
    setEditingStudent,
    batches,
    students,
    addStudent,
    updateStudent,
    addToast,
  } = useApp();

  const [name, setName] = useState('');
  const [rollNo, setRollNo] = useState('');
  const [batchId, setBatchId] = useState('');
  const [parentName, setParentName] = useState('');
  const [parentContact, setParentContact] = useState('');
  const [monthlyFee, setMonthlyFee] = useState('2000');
  const [admissionDate, setAdmissionDate] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (editingStudent) {
      setName(editingStudent.name);
      setRollNo(editingStudent.rollNo);
      setBatchId(editingStudent.batchId);
      setParentName(editingStudent.parentName || '');
      setParentContact(editingStudent.parentContact || '');
      setMonthlyFee(editingStudent.monthlyFee.toString());
      setAdmissionDate(editingStudent.admissionDate);
      setIsActive(editingStudent.isActive);
      setNotes(editingStudent.notes || '');
    } else {
      setName('');
      // Suggest next roll number
      const nextRoll = (students.length + 101).toString();
      setRollNo(nextRoll);
      setBatchId(batches[0]?.id || '');
      setParentName('');
      setParentContact('');
      setMonthlyFee('2000');
      setAdmissionDate(new Date().toISOString().split('T')[0]);
      setIsActive(true);
      setNotes('');
    }
    setError(null);
  }, [editingStudent, isAddStudentModalOpen, batches, students.length]);

  if (!isAddStudentModalOpen) return null;

  const handleClose = () => {
    setIsAddStudentModalOpen(false);
    setEditingStudent(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('Please enter student full name.');
      return;
    }

    if (!batchId) {
      setError('Please select a class / batch.');
      return;
    }

    const cleanContact = parentContact.replace(/\D/g, '');
    if (cleanContact.length !== 10) {
      setError('Please enter a valid 10-digit Indian mobile number for WhatsApp & calls.');
      return;
    }

    const parsedFee = parseFloat(monthlyFee);
    if (isNaN(parsedFee) || parsedFee <= 0) {
      setError('Please enter a valid monthly fee amount.');
      return;
    }

    if (editingStudent) {
      updateStudent(editingStudent.id, {
        name: name.trim(),
        rollNo: rollNo.trim(),
        batchId,
        parentName: parentName.trim(),
        parentContact: cleanContact,
        monthlyFee: parsedFee,
        admissionDate,
        isActive,
        notes: notes.trim(),
      });
    } else {
      addStudent({
        name: name.trim(),
        rollNo: rollNo.trim() || `${Date.now().toString().slice(-4)}`,
        batchId,
        parentName: parentName.trim(),
        parentContact: cleanContact,
        monthlyFee: parsedFee,
        admissionDate: admissionDate || new Date().toISOString().split('T')[0],
        isActive,
        notes: notes.trim(),
      });
    }

    handleClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
        onClick={handleClose}
      />

      {/* Modal Dialog */}
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[92vh] flex flex-col overflow-hidden z-10 border border-slate-200 animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {editingStudent ? 'Edit Student Details' : 'New Student Admission'}
              </h2>
              <p className="text-xs text-slate-500">
                {editingStudent ? 'Update academic & fee records' : 'Enroll a student in your coaching batch'}
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-xs text-rose-800">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Student Full Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Aarav Sharma"
                required
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all placeholder:text-slate-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Roll No / Student ID
              </label>
              <input
                type="text"
                value={rollNo}
                onChange={(e) => setRollNo(e.target.value)}
                placeholder="e.g. 101"
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Class / Batch <span className="text-rose-500">*</span>
              </label>
              <select
                value={batchId}
                onChange={(e) => setBatchId(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 bg-white"
              >
                {batches.map((batch) => (
                  <option key={batch.id} value={batch.id}>
                    {batch.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Parent / Guardian Name
              </label>
              <input
                type="text"
                value={parentName}
                onChange={(e) => setParentName(e.target.value)}
                placeholder="e.g. Sanjay Sharma"
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Parent WhatsApp / Mobile <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400">
                  +91
                </span>
                <input
                  type="tel"
                  maxLength={10}
                  value={parentContact}
                  onChange={(e) => setParentContact(e.target.value.replace(/\D/g, ''))}
                  placeholder="9876543210"
                  required
                  className="w-full pl-12 pr-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Monthly Tuition Fee (₹) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                step="50"
                min="0"
                value={monthlyFee}
                onChange={(e) => setMonthlyFee(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all font-mono font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Admission Date
              </label>
              <input
                type="date"
                value={admissionDate}
                onChange={(e) => setAdmissionDate(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Academic Notes & Comments
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                placeholder="e.g. Target board exam score, special attention topics, payment notes"
                className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 transition-all resize-none"
              />
            </div>

            <div className="sm:col-span-2 flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
              <div>
                <span className="text-xs font-semibold text-slate-800">Enrollment Status</span>
                <p className="text-[11px] text-slate-500">
                  {isActive ? 'Active student (attends classes)' : 'Deactivated / Past student'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsActive(!isActive)}
                className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                  isActive ? 'bg-emerald-600 justify-end' : 'bg-slate-300 justify-start'
                }`}
              >
                <span className="bg-white w-4 h-4 rounded-full shadow-md" />
              </button>
            </div>
          </div>

          {/* Modal Footer Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={handleClose}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-md shadow-slate-900/10 transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>{editingStudent ? 'Save Changes' : 'Enroll Student'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
