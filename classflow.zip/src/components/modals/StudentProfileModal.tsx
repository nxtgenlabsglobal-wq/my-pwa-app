import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Phone,
  MessageSquare,
  Edit2,
  CalendarCheck,
  CreditCard,
  FileText,
  Plus,
  Trash2,
  CheckCircle,
  AlertCircle,
  Clock,
  UserX,
  UserCheck,
} from 'lucide-react';
import { formatCurrency, formatDate, formatMonthName } from '../../utils/formatters';
import { AttendanceStatus } from '../../types';

export const StudentProfileModal: React.FC = () => {
  const {
    selectedStudentId,
    setSelectedStudentId,
    students,
    batches,
    attendance,
    payments,
    studentFeeSummaries,
    getStudentAttendanceSummary,
    setEditingStudent,
    setIsAddStudentModalOpen,
    setPreselectedPaymentStudentId,
    setIsRecordPaymentModalOpen,
    setReceiptModalPayment,
    setWhatsAppModalData,
    toggleStudentStatus,
    deleteStudent,
    saveAttendance,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'attendance' | 'payments' | 'info'>('attendance');

  if (!selectedStudentId) return null;

  const student = students.find((s) => s.id === selectedStudentId);
  if (!student) return null;

  const batch = batches.find((b) => b.id === student.batchId);
  const feeSummary = studentFeeSummaries.find((s) => s.student.id === student.id);
  const attSummary = getStudentAttendanceSummary(student.id);

  // Student specific records sorted descending
  const studentAttendance = attendance
    .filter((a) => a.studentId === student.id)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const studentPayments = payments
    .filter((p) => p.studentId === student.id)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleEdit = () => {
    setEditingStudent(student);
    setIsAddStudentModalOpen(true);
  };

  const handleRecordPayment = () => {
    setPreselectedPaymentStudentId(student.id);
    setIsRecordPaymentModalOpen(true);
  };

  const handleQuickStatusChange = (date: string, newStatus: AttendanceStatus) => {
    saveAttendance(student.batchId, date, [
      {
        studentId: student.id,
        status: newStatus,
      },
    ]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
        onClick={() => setSelectedStudentId(null)}
      />

      {/* Modal Dialog */}
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden z-10 border border-slate-200 animate-in zoom-in-95 duration-150">
        {/* Header Profile Card */}
        <div className="p-5 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center text-lg font-bold shadow-md shadow-slate-900/10">
                {student.name.charAt(0)}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-slate-900 leading-tight">
                    {student.name}
                  </h2>
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                      student.isActive
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-slate-100 text-slate-500 border-slate-200'
                    }`}
                  >
                    {student.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                  <span>Roll #{student.rollNo}</span>
                  <span>·</span>
                  <span className="font-medium text-blue-700">{batch?.name || 'Batch'}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={handleEdit}
                className="p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 transition-colors"
                title="Edit Student"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setSelectedStudentId(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Contact Bar */}
          <div className="mt-4 pt-3 border-t border-slate-200/70 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="text-slate-600">
              <span className="text-slate-400">Parent: </span>
              <strong className="text-slate-800">{student.parentName || 'Guardian'}</strong>
              <span className="ml-2 font-mono text-slate-700 font-medium">
                +91 {student.parentContact}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() =>
                  setWhatsAppModalData({
                    student,
                    type: 'fee_reminder',
                  })
                }
                className="flex items-center gap-1 py-1.5 px-3 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold border border-emerald-200 transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                <span>WhatsApp</span>
              </button>

              <a
                href={`tel:${student.parentContact}`}
                className="flex items-center gap-1 py-1.5 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call</span>
              </a>
            </div>
          </div>
        </div>

        {/* Quick KPI Strip */}
        <div className="grid grid-cols-3 border-b border-slate-100 bg-white divide-x divide-slate-100 text-center py-2.5">
          <div className="px-2">
            <p className="text-[11px] text-slate-400 font-medium">Attendance</p>
            <p
              className={`text-base font-bold font-mono mt-0.5 ${
                attSummary.percentage >= 75 ? 'text-emerald-600' : 'text-amber-600'
              }`}
            >
              {attSummary.percentage}%
            </p>
            <p className="text-[10px] text-slate-400">
              {attSummary.presentDays}/{attSummary.totalDays} sessions
            </p>
          </div>

          <div className="px-2">
            <p className="text-[11px] text-slate-400 font-medium">Monthly Fee</p>
            <p className="text-base font-bold font-mono text-slate-900 mt-0.5">
              {formatCurrency(student.monthlyFee)}
            </p>
            <p className="text-[10px] text-slate-400">Rate per month</p>
          </div>

          <div className="px-2">
            <p className="text-[11px] text-slate-400 font-medium">Current Due</p>
            <p
              className={`text-base font-bold font-mono mt-0.5 ${
                (feeSummary?.balanceThisMonth || 0) > 0 ? 'text-rose-600' : 'text-emerald-600'
              }`}
            >
              {formatCurrency(feeSummary?.balanceThisMonth || 0)}
            </p>
            <p className="text-[10px] text-slate-400">
              {(feeSummary?.balanceThisMonth || 0) > 0 ? 'Pending' : 'Fully Paid'}
            </p>
          </div>
        </div>

        {/* Profile Internal Tabs */}
        <div className="flex border-b border-slate-200 px-5 bg-slate-50/50">
          <button
            onClick={() => setActiveTab('attendance')}
            className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'attendance'
                ? 'border-blue-600 text-blue-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <CalendarCheck className="w-4 h-4" />
            <span>Attendance Log ({studentAttendance.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('payments')}
            className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'payments'
                ? 'border-blue-600 text-blue-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Fee Receipts ({studentPayments.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('info')}
            className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'info'
                ? 'border-blue-600 text-blue-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Admission & Notes</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-5">
          {activeTab === 'attendance' && (
            <div className="space-y-2">
              {studentAttendance.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  No attendance marked yet.
                </div>
              ) : (
                studentAttendance.map((rec) => (
                  <div
                    key={rec.id}
                    className="flex items-center justify-between p-3 rounded-xl border border-slate-200 hover:bg-slate-50 transition-colors"
                  >
                    <div>
                      <p className="text-xs font-semibold text-slate-800">{formatDate(rec.date)}</p>
                      {rec.remarks && (
                        <p className="text-[11px] text-slate-400 mt-0.5">{rec.remarks}</p>
                      )}
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleQuickStatusChange(rec.date, 'present')}
                        className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                          rec.status === 'present'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        Present
                      </button>
                      <button
                        onClick={() => handleQuickStatusChange(rec.date, 'absent')}
                        className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                          rec.status === 'absent'
                            ? 'bg-rose-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        Absent
                      </button>
                      <button
                        onClick={() => handleQuickStatusChange(rec.date, 'late')}
                        className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                          rec.status === 'late'
                            ? 'bg-amber-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        Late
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'payments' && (
            <div className="space-y-2.5">
              {studentPayments.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-400 text-xs mb-3">No payments recorded yet.</p>
                  <button
                    onClick={handleRecordPayment}
                    className="px-4 py-2 bg-slate-900 text-white text-xs font-semibold rounded-xl"
                  >
                    Record First Payment
                  </button>
                </div>
              ) : (
                studentPayments.map((pay) => (
                  <div
                    key={pay.id}
                    className="p-3.5 rounded-xl border border-slate-200 hover:border-slate-300 transition-colors flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{pay.receiptNo}</span>
                        <span className="text-[11px] text-slate-500 font-mono">
                          {formatDate(pay.date)}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Month: {formatMonthName(pay.monthFor)} · Cash Payment
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-sm font-extrabold text-emerald-700 font-mono">
                        {formatCurrency(pay.amount)}
                      </span>

                      <button
                        onClick={() => setReceiptModalPayment({ payment: pay, student })}
                        className="py-1 px-2.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors"
                      >
                        Receipt
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'info' && (
            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-400">Admission Date</span>
                  <p className="font-semibold text-slate-800 mt-0.5">
                    {formatDate(student.admissionDate)}
                  </p>
                </div>
                <div>
                  <span className="text-slate-400">Batch Timing</span>
                  <p className="font-semibold text-slate-800 mt-0.5">
                    {batch?.timing || 'Not specified'}
                  </p>
                </div>
                <div>
                  <span className="text-slate-400">Scheduled Days</span>
                  <p className="font-semibold text-slate-800 mt-0.5">
                    {batch?.days.join(', ') || 'All weekdays'}
                  </p>
                </div>
                <div>
                  <span className="text-slate-400">Total Lifetime Fees Paid</span>
                  <p className="font-semibold font-mono text-emerald-700 mt-0.5">
                    {formatCurrency(feeSummary?.totalAllTimePaid || 0)}
                  </p>
                </div>
              </div>

              <div>
                <span className="font-semibold text-slate-700">Notes & Comments:</span>
                <p className="mt-1 p-3 bg-white border border-slate-200 rounded-xl text-slate-600 leading-relaxed">
                  {student.notes || 'No academic notes added yet.'}
                </p>
              </div>

              {/* Status toggles */}
              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => toggleStudentStatus(student.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl border transition-colors ${
                    student.isActive
                      ? 'border-amber-200 bg-amber-50 text-amber-800 hover:bg-amber-100'
                      : 'border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                  }`}
                >
                  {student.isActive ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                  <span>{student.isActive ? 'Deactivate Student' : 'Reactivate Student'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm(`Delete ${student.name} permanently?`)) {
                      deleteStudent(student.id);
                    }
                  }}
                  className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl text-rose-600 hover:bg-rose-50 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Remove Student</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Action Bar */}
        <div className="p-4 border-t border-slate-100 bg-white flex items-center justify-between gap-3">
          <button
            onClick={() =>
              setWhatsAppModalData({
                student,
                type: 'fee_reminder',
              })
            }
            className="flex items-center gap-1.5 py-2 px-3 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-xl border border-emerald-200 transition-colors"
          >
            <MessageSquare className="w-4 h-4 text-emerald-600" />
            <span>Fee Reminder</span>
          </button>

          <button
            onClick={handleRecordPayment}
            className="flex items-center gap-1.5 py-2 px-4 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs transition-colors"
          >
            <CreditCard className="w-4 h-4 text-emerald-400" />
            <span>Record Payment</span>
          </button>
        </div>
      </div>
    </div>
  );
};
