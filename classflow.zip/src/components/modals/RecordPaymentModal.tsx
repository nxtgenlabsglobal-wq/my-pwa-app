import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { X, IndianRupee, Check, AlertCircle, Banknote } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

export const RecordPaymentModal: React.FC = () => {
  const {
    isRecordPaymentModalOpen,
    setIsRecordPaymentModalOpen,
    preselectedPaymentStudentId,
    setPreselectedPaymentStudentId,
    students,
    batches,
    currentMonth,
    todayDate,
    payments,
    recordPayment,
    setReceiptModalPayment,
  } = useApp();

  const [studentId, setStudentId] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(todayDate);
  const [monthFor, setMonthFor] = useState(currentMonth);
  const [remarks, setRemarks] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (preselectedPaymentStudentId) {
      setStudentId(preselectedPaymentStudentId);
    } else if (students.length > 0 && !studentId) {
      setStudentId(students[0].id);
    }
    setDate(todayDate);
    setMonthFor(currentMonth);
    setError(null);
  }, [preselectedPaymentStudentId, isRecordPaymentModalOpen, students]);

  const selectedStudent = students.find((s) => s.id === studentId);

  // Calculate current paid and pending for this student in selected month
  const paidForMonth = payments
    .filter((p) => p.studentId === studentId && p.monthFor === monthFor)
    .reduce((sum, p) => sum + p.amount, 0);

  const monthlyFee = selectedStudent?.monthlyFee || 0;
  const balanceRemaining = Math.max(0, monthlyFee - paidForMonth);

  // Auto-set amount to balance on student/month change
  useEffect(() => {
    if (balanceRemaining > 0) {
      setAmount(balanceRemaining.toString());
    } else {
      setAmount(monthlyFee.toString());
    }
  }, [studentId, monthFor, balanceRemaining, monthlyFee]);

  if (!isRecordPaymentModalOpen) return null;

  const handleClose = () => {
    setIsRecordPaymentModalOpen(false);
    setPreselectedPaymentStudentId(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!selectedStudent) {
      setError('Please select a student.');
      return;
    }

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('Please enter a valid cash payment amount.');
      return;
    }

    // MANDATORY REQUIREMENT 2: Cash only
    const newPayment = recordPayment({
      studentId: selectedStudent.id,
      amount: parsedAmount,
      date,
      monthFor,
      remarks: remarks.trim() || undefined,
    });

    handleClose();
    setReceiptModalPayment({ payment: newPayment, student: selectedStudent });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
        onClick={handleClose}
      />

      {/* Modal Card */}
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[92vh] flex flex-col overflow-hidden z-10 border border-slate-200 animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-emerald-50/40">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
              <Banknote className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Record Cash Fee Payment</h2>
              <p className="text-xs text-slate-500">Collect tuition cash fees & issue receipt</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-xs text-rose-800">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Student Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Select Student <span className="text-rose-500">*</span>
            </label>
            <select
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 bg-white font-medium"
            >
              {students
                .filter((s) => s.isActive)
                .map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} (#{s.rollNo}) — {batches.find((b) => b.id === s.batchId)?.name || 'Class'}
                  </option>
                ))}
            </select>
          </div>

          {/* Fee Balance Snapshot Card */}
          {selectedStudent && (
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-500">Class Fee: </span>
                <span className="font-semibold text-slate-800 font-mono">
                  {formatCurrency(monthlyFee)}
                </span>
                <span className="mx-2 text-slate-300">|</span>
                <span className="text-slate-500">Already Paid: </span>
                <span className="font-semibold text-emerald-600 font-mono">
                  {formatCurrency(paidForMonth)}
                </span>
              </div>
              <div>
                <span className="text-slate-500">Pending: </span>
                <span
                  className={`font-bold font-mono ${
                    balanceRemaining > 0 ? 'text-rose-600' : 'text-emerald-600'
                  }`}
                >
                  {formatCurrency(balanceRemaining)}
                </span>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Fee For Month <span className="text-rose-500">*</span>
              </label>
              <input
                type="month"
                value={monthFor}
                onChange={(e) => setMonthFor(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 font-medium bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Date of Cash Collection <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 bg-white"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Cash Amount Received (₹) <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400">
                  ₹
                </span>
                <input
                  type="number"
                  min="1"
                  step="50"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  required
                  placeholder="2000"
                  className="w-full pl-9 pr-3.5 py-2.5 text-base font-bold text-slate-900 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 font-mono"
                />
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex items-center gap-2 mt-2">
                <span className="text-[11px] text-slate-400">Quick:</span>
                {balanceRemaining > 0 && (
                  <button
                    type="button"
                    onClick={() => setAmount(balanceRemaining.toString())}
                    className="px-2.5 py-1 text-[11px] font-semibold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg border border-emerald-200 transition-colors"
                  >
                    Full Balance ({formatCurrency(balanceRemaining)})
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setAmount('1000')}
                  className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                >
                  ₹1,000
                </button>
                <button
                  type="button"
                  onClick={() => setAmount('2000')}
                  className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                >
                  ₹2,000
                </button>
                <button
                  type="button"
                  onClick={() => setAmount('3000')}
                  className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                >
                  ₹3,000
                </button>
              </div>
            </div>

            {/* Cash Only Informational Badge */}
            <div className="sm:col-span-2 p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-900">
              <span className="font-semibold flex items-center gap-1.5">
                <Banknote className="w-4 h-4 text-emerald-700" />
                Payment Method:
              </span>
              <span className="font-bold text-emerald-800 bg-white px-2.5 py-0.5 rounded-lg border border-emerald-200">
                Cash at Counter
              </span>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Receipt Remarks / Notes (Optional)
              </label>
              <input
                type="text"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                placeholder="e.g. Paid in cash by father; handed to Mr. Rajesh"
                className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 transition-all"
              />
            </div>
          </div>

          {/* Modal Footer Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={handleClose}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md shadow-emerald-600/20 transition-colors cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Record Cash Payment & Receipt</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
