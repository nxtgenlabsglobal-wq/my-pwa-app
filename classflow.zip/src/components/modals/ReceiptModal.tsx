import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, Download, Share2, Printer, CheckCircle, Banknote } from 'lucide-react';
import { formatCurrency, formatDate, formatMonthName } from '../../utils/formatters';
import { generateReceiptPDF } from '../../utils/pdfGenerator';

export const ReceiptModal: React.FC = () => {
  const {
    receiptModalPayment,
    setReceiptModalPayment,
    settings,
    batches,
    payments,
    setWhatsAppModalData,
  } = useApp();

  if (!receiptModalPayment) return null;

  const { payment, student } = receiptModalPayment;
  const batch = batches.find((b) => b.id === student.batchId);

  // Compute remaining balance for this month
  const totalPaidForMonth = payments
    .filter((p) => p.studentId === student.id && p.monthFor === payment.monthFor)
    .reduce((sum, p) => sum + p.amount, 0);

  const remainingBalance = Math.max(0, student.monthlyFee - totalPaidForMonth);

  const handleDownloadPDF = () => {
    generateReceiptPDF(payment, student, batch, remainingBalance, settings);
  };

  const handleShareWhatsApp = () => {
    setWhatsAppModalData({
      student,
      type: 'receipt',
      payment,
    });
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
        onClick={() => setReceiptModalPayment(null)}
      />

      {/* Modal Container */}
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[94vh] flex flex-col overflow-hidden z-10 border border-slate-200 animate-in zoom-in-95 duration-150">
        {/* Actions Bar */}
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">
              Official Cash Receipt
            </span>
            <span className="text-xs font-mono text-slate-500">#{payment.receiptNo}</span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={handlePrint}
              title="Print Receipt"
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 transition-colors"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={() => setReceiptModalPayment(null)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Receipt Content Area (Printable Voucher) */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50">
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 relative overflow-hidden">
            {/* Top decorative badge */}
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-blue-600 via-emerald-500 to-indigo-600" />

            {/* Institute Header */}
            <div className="text-center pb-4 border-b border-slate-100">
              <h3 className="font-extrabold text-slate-900 text-base leading-tight">
                {settings.name}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">{settings.tagline}</p>
              <p className="text-[11px] text-slate-400 mt-1">
                {settings.address} · Ph: {settings.contactNumber}
              </p>
            </div>

            {/* Receipt Ribbon */}
            <div className="my-3 py-1.5 px-3 bg-emerald-50 border border-emerald-100 rounded-lg flex items-center justify-between text-xs">
              <span className="font-bold text-emerald-900 flex items-center gap-1">
                <Banknote className="w-3.5 h-3.5" /> CASH VOUCHER
              </span>
              <span className="font-mono text-emerald-800 font-bold">{payment.receiptNo}</span>
            </div>

            {/* Date and Month */}
            <div className="flex justify-between items-center text-xs text-slate-500 pb-3 border-b border-slate-100">
              <span>Date: <strong className="text-slate-800">{formatDate(payment.date)}</strong></span>
              <span>Month: <strong className="text-slate-800">{formatMonthName(payment.monthFor)}</strong></span>
            </div>

            {/* Student Info */}
            <div className="py-3 text-xs space-y-1.5 border-b border-slate-100">
              <div className="flex justify-between">
                <span className="text-slate-500">Student Name:</span>
                <span className="font-bold text-slate-900">{student.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Roll / ID:</span>
                <span className="font-mono text-slate-700">{student.rollNo}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Class / Batch:</span>
                <span className="font-medium text-slate-800">{batch?.name || 'Class'}</span>
              </div>
              {student.parentName && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Parent Name:</span>
                  <span className="text-slate-700">{student.parentName}</span>
                </div>
              )}
            </div>

            {/* Financials Table */}
            <div className="py-3 text-xs space-y-2 border-b border-slate-100">
              <div className="flex justify-between text-slate-500">
                <span>Tuition Fee Rate:</span>
                <span className="font-mono">{formatCurrency(student.monthlyFee)}</span>
              </div>

              <div className="flex justify-between items-center py-2 px-2.5 bg-emerald-50 rounded-lg border border-emerald-100">
                <span className="font-bold text-emerald-900 flex items-center gap-1">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                  Cash Received:
                </span>
                <span className="font-extrabold text-sm text-emerald-700 font-mono">
                  {formatCurrency(payment.amount)}
                </span>
              </div>

              <div className="flex justify-between text-slate-600 text-xs pt-1">
                <span>Remaining Balance Due:</span>
                <span
                  className={`font-bold font-mono ${
                    remainingBalance > 0 ? 'text-rose-600' : 'text-slate-700'
                  }`}
                >
                  {formatCurrency(remainingBalance)}
                </span>
              </div>
            </div>

            {/* Payment Method Details: Strictly Cash */}
            <div className="py-2.5 text-xs text-slate-500 space-y-1 border-b border-slate-100">
              <div className="flex justify-between">
                <span>Payment Mode:</span>
                <span className="font-semibold text-slate-800">Cash at Institute Counter</span>
              </div>
              {payment.remarks && (
                <div className="text-[11px] text-slate-400 italic">
                  Note: {payment.remarks}
                </div>
              )}
            </div>

            {/* Signatory Footer */}
            <div className="pt-4 flex items-end justify-between text-[10px] text-slate-400">
              <div>
                <p>Cashier / Front Office</p>
                <p>{settings.name}</p>
              </div>
              <div className="text-right">
                <div className="w-24 border-b border-slate-300 pb-1 mb-1" />
                <p className="font-semibold text-slate-700">Authorized Stamp</p>
                <p>Fee Collected</p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer with Actions */}
        <div className="p-4 border-t border-slate-100 bg-white grid grid-cols-2 gap-2.5">
          <button
            onClick={handleDownloadPDF}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Download PDF</span>
          </button>

          <button
            onClick={handleShareWhatsApp}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs transition-colors"
          >
            <Share2 className="w-4 h-4" />
            <span>WhatsApp Receipt</span>
          </button>
        </div>
      </div>
    </div>
  );
};
