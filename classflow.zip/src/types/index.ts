export type TabType = 'dashboard' | 'students' | 'attendance' | 'fees' | 'tests' | 'reports' | 'settings';

export type AttendanceStatus = 'present' | 'absent' | 'late';

// Mandatory: Cash ONLY payment mode
export type PaymentMode = 'Cash';

export type SyncStatus = 'synced' | 'syncing' | 'offline' | 'error';

export interface AuthUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL?: string | null;
}

export interface Batch {
  id: string;
  name: string;
  subject?: string;
  timing: string;
  days: string[];
  updatedAt?: string;
}

export interface Student {
  id: string;
  rollNo: string;
  name: string;
  batchId: string;
  parentContact: string; // 10-digit Indian mobile
  parentName?: string;
  monthlyFee: number; // in INR
  admissionDate: string; // YYYY-MM-DD
  isActive: boolean;
  notes?: string;
  updatedAt?: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  batchId: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  timestamp: string;
  remarks?: string;
  updatedAt?: string;
}

export interface FeePayment {
  id: string;
  receiptNo: string;
  studentId: string;
  amount: number;
  date: string; // YYYY-MM-DD
  monthFor: string; // e.g. "2026-10" or "October 2026"
  paymentMode: PaymentMode; // Always 'Cash'
  remarks?: string;
  recordedAt: string;
  updatedAt?: string;
}

export interface ClassTest {
  id: string;
  batchId: string;
  title: string;
  subject: string;
  date: string; // YYYY-MM-DD
  totalMarks: number;
  updatedAt?: string;
}

export interface TestResult {
  id: string;
  testId: string;
  studentId: string;
  marksObtained: number;
  remarks?: string;
  updatedAt?: string;
}

export interface InstituteSettings {
  name: string;
  tagline: string;
  ownerName: string;
  contactNumber: string;
  email: string;
  address: string;
  currencySymbol: string;
  defaultFeeDueDay: number; // 1-28 (e.g. 5th or 10th of the month)
  receiptPrefix: string;
  updatedAt?: string;
}

export interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message?: string;
  duration?: number;
}

export interface StudentFeeSummary {
  student: Student;
  batch?: Batch;
  totalDueThisMonth: number;
  paidThisMonth: number;
  balanceThisMonth: number;
  totalAllTimePaid: number;
  isOverdue: boolean;
  status: 'paid' | 'partial' | 'pending';
}

export interface StudentAttendanceSummary {
  student: Student;
  batch?: Batch;
  totalDays: number;
  presentDays: number;
  absentDays: number;
  lateDays: number;
  percentage: number;
}
