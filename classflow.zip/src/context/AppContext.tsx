import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  TabType,
  Student,
  Batch,
  AttendanceRecord,
  FeePayment,
  InstituteSettings,
  ToastNotification,
  AttendanceStatus,
  StudentFeeSummary,
  StudentAttendanceSummary,
  ClassTest,
  TestResult,
  SyncStatus,
  AuthUser,
} from '../types';
import { getStoredData, saveStoredData, resetToSampleData } from '../utils/storage';
import { auth, googleProvider } from '../firebase/config';
import { signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { syncService } from '../services/syncService';

interface WhatsAppModalPayload {
  student: Student;
  type: 'fee_reminder' | 'receipt' | 'attendance' | 'test';
  payment?: FeePayment;
  attendanceStatus?: AttendanceStatus;
  attendanceDate?: string;
  test?: ClassTest;
  testResult?: TestResult;
}

interface AppContextType {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  students: Student[];
  batches: Batch[];
  attendance: AttendanceRecord[];
  payments: FeePayment[];
  settings: InstituteSettings;
  tests: ClassTest[];
  testResults: TestResult[];
  toasts: ToastNotification[];
  currentMonth: string;
  todayDate: string;

  // Authentication & Cloud Sync
  authUser: AuthUser | null;
  authLoading: boolean;
  syncStatus: SyncStatus;
  syncMessage: string;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  continueAsOfflineDemo: () => void;
  manualSyncNow: () => Promise<void>;

  // Modals & Drawers
  selectedStudentId: string | null;
  setSelectedStudentId: (id: string | null) => void;
  isAddStudentModalOpen: boolean;
  setIsAddStudentModalOpen: (open: boolean) => void;
  editingStudent: Student | null;
  setEditingStudent: (student: Student | null) => void;
  isRecordPaymentModalOpen: boolean;
  setIsRecordPaymentModalOpen: (open: boolean) => void;
  preselectedPaymentStudentId: string | null;
  setPreselectedPaymentStudentId: (id: string | null) => void;
  receiptModalPayment: { payment: FeePayment; student: Student } | null;
  setReceiptModalPayment: (data: { payment: FeePayment; student: Student } | null) => void;
  whatsAppModalData: WhatsAppModalPayload | null;
  setWhatsAppModalData: (data: WhatsAppModalPayload | null) => void;

  // Actions
  addToast: (toast: Omit<ToastNotification, 'id'>) => void;
  removeToast: (id: string) => void;
  addStudent: (studentData: Omit<Student, 'id'>) => void;
  updateStudent: (id: string, updates: Partial<Student>) => void;
  toggleStudentStatus: (id: string) => void;
  deleteStudent: (id: string) => void;
  addBatch: (batchData: Omit<Batch, 'id'>) => void;
  updateBatch: (id: string, updates: Partial<Batch>) => void;
  deleteBatch: (id: string) => void;
  saveAttendance: (batchId: string, date: string, records: { studentId: string; status: AttendanceStatus; remarks?: string }[]) => void;
  recordPayment: (paymentData: Omit<FeePayment, 'id' | 'receiptNo' | 'recordedAt' | 'paymentMode'>) => FeePayment;
  deletePayment: (paymentId: string) => void;
  addTest: (testData: Omit<ClassTest, 'id'>) => void;
  updateTest: (id: string, updates: Partial<ClassTest>) => void;
  deleteTest: (testId: string) => void;
  saveTestResults: (testId: string, results: { studentId: string; marksObtained: number; remarks?: string }[]) => void;
  updateSettings: (newSettings: Partial<InstituteSettings>) => void;
  resetAllData: () => void;
  importAllData: (jsonData: any) => boolean;

  // Computed Summaries
  studentFeeSummaries: StudentFeeSummary[];
  getStudentAttendanceSummary: (studentId: string, monthKey?: string) => StudentAttendanceSummary;
  getBatchById: (batchId: string) => Batch | undefined;
  getStudentById: (studentId: string) => Student | undefined;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const initial = useMemo(() => getStoredData(), []);

  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [students, setStudents] = useState<Student[]>(initial.students);
  const [batches, setBatches] = useState<Batch[]>(initial.batches);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(initial.attendance);
  const [payments, setPayments] = useState<FeePayment[]>(initial.payments);
  const [settings, setSettings] = useState<InstituteSettings>(initial.settings);
  const [tests, setTests] = useState<ClassTest[]>(initial.tests || []);
  const [testResults, setTestResults] = useState<TestResult[]>(initial.testResults || []);
  const [toasts, setToasts] = useState<ToastNotification[]>([]);

  // Auth & Sync State
  const [authUser, setAuthUser] = useState<AuthUser | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('offline');
  const [syncMessage, setSyncMessage] = useState<string>('Local offline mode');

  // Modals state
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [isAddStudentModalOpen, setIsAddStudentModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [isRecordPaymentModalOpen, setIsRecordPaymentModalOpen] = useState(false);
  const [preselectedPaymentStudentId, setPreselectedPaymentStudentId] = useState<string | null>(null);
  const [receiptModalPayment, setReceiptModalPayment] = useState<{ payment: FeePayment; student: Student } | null>(null);
  const [whatsAppModalData, setWhatsAppModalData] = useState<WhatsAppModalPayload | null>(null);

  const today = new Date();
  const todayDate = today.toISOString().split('T')[0];
  const currentMonth = today.toISOString().substring(0, 7);

  // Setup SyncService callbacks
  useEffect(() => {
    syncService.setCallbacks(
      (cloudData) => {
        setStudents(cloudData.students);
        setBatches(cloudData.batches);
        setAttendance(cloudData.attendance);
        setPayments(cloudData.payments);
        setSettings(cloudData.settings);
        setTests(cloudData.tests);
        setTestResults(cloudData.testResults);
      },
      (newStatus, msg) => {
        setSyncStatus(newStatus);
        if (msg) setSyncMessage(msg);
      }
    );
  }, []);

  // Firebase Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser: User | null) => {
      if (firebaseUser) {
        const userObj: AuthUser = {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          displayName: firebaseUser.displayName,
          photoURL: firebaseUser.photoURL,
        };
        setAuthUser(userObj);
        // Initialize Cloud Sync for this user
        await syncService.initUserSync(firebaseUser.uid);
      } else {
        // Check if user was in offline demo session
        const isOfflineSession = localStorage.getItem('classflow_offline_session') === 'true';
        if (isOfflineSession) {
          setAuthUser({
            uid: 'offline-owner',
            email: 'offline.owner@classflow.local',
            displayName: settings.ownerName || 'Tuition Owner (Local)',
          });
          setSyncStatus('offline');
          setSyncMessage('Offline local storage');
        } else {
          setAuthUser(null);
          syncService.cleanup();
          setSyncStatus('offline');
        }
      }
      setAuthLoading(false);
    });

    return () => {
      unsubscribe();
      syncService.cleanup();
    };
  }, [settings.ownerName]);

  // Auth handlers
  const loginWithGoogle = async () => {
    try {
      localStorage.removeItem('classflow_offline_session');
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user) {
        addToast({
          type: 'success',
          title: 'Signed In Successfully',
          message: `Welcome, ${result.user.displayName || result.user.email}! Cloud sync enabled.`,
        });
      }
    } catch (err: any) {
      console.error('Google Sign In Failed:', err);
      throw err;
    }
  };

  const logout = async () => {
    localStorage.removeItem('classflow_offline_session');
    await signOut(auth);
    setAuthUser(null);
    syncService.cleanup();
    setSyncStatus('offline');
    addToast({
      type: 'info',
      title: 'Signed Out',
      message: 'You have been signed out safely.',
    });
  };

  const continueAsOfflineDemo = () => {
    localStorage.setItem('classflow_offline_session', 'true');
    setAuthUser({
      uid: 'offline-owner',
      email: 'offline.owner@classflow.local',
      displayName: settings.ownerName || 'Tuition Owner (Local)',
    });
    setSyncStatus('offline');
    setSyncMessage('Operating in offline mode');
    addToast({
      type: 'info',
      title: 'Offline Mode Active',
      message: 'All records are saved locally on this device.',
    });
  };

  const manualSyncNow = async () => {
    const result = await syncService.manualSyncNow();
    addToast({
      type: result.success ? 'success' : 'warning',
      title: result.success ? 'Sync Complete' : 'Sync Incomplete',
      message: result.message,
    });
  };

  // Toast Helpers
  const addToast = (toast: Omit<ToastNotification, 'id'>) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const newToast: ToastNotification = { ...toast, id };
    setToasts((prev) => [...prev, newToast]);
    const duration = toast.duration || 4000;
    setTimeout(() => removeToast(id), duration);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Student Actions
  const addStudent = (studentData: Omit<Student, 'id'>) => {
    const id = `std-${Date.now()}`;
    const newStudent: Student = {
      ...studentData,
      id,
      updatedAt: new Date().toISOString(),
    };

    setStudents((prev) => {
      const updated = [newStudent, ...prev];
      saveStoredData({ students: updated });
      return updated;
    });

    syncService.syncDocument('students', id, newStudent);

    addToast({
      type: 'success',
      title: 'Student Enrolled',
      message: `${newStudent.name} saved locally and queued for cloud sync.`,
    });
  };

  const updateStudent = (id: string, updates: Partial<Student>) => {
    const updatedAt = new Date().toISOString();
    let updatedStudent: Student | undefined;

    setStudents((prev) => {
      const updated = prev.map((s) => {
        if (s.id === id) {
          updatedStudent = { ...s, ...updates, updatedAt };
          return updatedStudent;
        }
        return s;
      });
      saveStoredData({ students: updated });
      return updated;
    });

    if (updatedStudent) {
      syncService.syncDocument('students', id, updatedStudent);
    }

    addToast({
      type: 'info',
      title: 'Student Updated',
      message: 'Student details saved and synchronized.',
    });
  };

  const toggleStudentStatus = (id: string) => {
    const student = students.find((s) => s.id === id);
    if (!student) return;

    const newActive = !student.isActive;
    updateStudent(id, { isActive: newActive });
  };

  const deleteStudent = (id: string) => {
    const target = students.find((s) => s.id === id);
    setStudents((prev) => {
      const updated = prev.filter((s) => s.id !== id);
      saveStoredData({ students: updated });
      return updated;
    });

    syncService.syncDocument('students', id, null, true);

    if (selectedStudentId === id) setSelectedStudentId(null);
    addToast({
      type: 'info',
      title: 'Student Removed',
      message: `${target?.name || 'Student'} deleted and removed from cloud.`,
    });
  };

  // Batch Actions
  const addBatch = (batchData: Omit<Batch, 'id'>) => {
    const id = `batch-${Date.now()}`;
    const newBatch: Batch = {
      ...batchData,
      id,
      updatedAt: new Date().toISOString(),
    };

    setBatches((prev) => {
      const updated = [...prev, newBatch];
      saveStoredData({ batches: updated });
      return updated;
    });

    syncService.syncDocument('batches', id, newBatch);

    addToast({
      type: 'success',
      title: 'Batch Created',
      message: `Batch "${newBatch.name}" created and backed up.`,
    });
  };

  const updateBatch = (id: string, updates: Partial<Batch>) => {
    const updatedAt = new Date().toISOString();
    let updatedBatch: Batch | undefined;

    setBatches((prev) => {
      const updated = prev.map((b) => {
        if (b.id === id) {
          updatedBatch = { ...b, ...updates, updatedAt };
          return updatedBatch;
        }
        return b;
      });
      saveStoredData({ batches: updated });
      return updated;
    });

    if (updatedBatch) {
      syncService.syncDocument('batches', id, updatedBatch);
    }

    addToast({
      type: 'info',
      title: 'Batch Updated',
      message: 'Batch schedule updated and synced.',
    });
  };

  const deleteBatch = (id: string) => {
    const hasStudents = students.some((s) => s.batchId === id);
    if (hasStudents) {
      addToast({
        type: 'error',
        title: 'Cannot Delete Batch',
        message: 'This batch has enrolled students. Reassign students first.',
      });
      return;
    }
    setBatches((prev) => {
      const updated = prev.filter((b) => b.id !== id);
      saveStoredData({ batches: updated });
      return updated;
    });

    syncService.syncDocument('batches', id, null, true);

    addToast({
      type: 'info',
      title: 'Batch Deleted',
      message: 'Batch removed successfully.',
    });
  };

  // Attendance Actions with duplicate protection
  const saveAttendance = (
    batchId: string,
    date: string,
    records: { studentId: string; status: AttendanceStatus; remarks?: string }[]
  ) => {
    const timestamp = new Date().toISOString();

    setAttendance((prev) => {
      const studentIdsInUpdate = new Set(records.map((r) => r.studentId));
      const filtered = prev.filter(
        (rec) => !(rec.batchId === batchId && rec.date === date && studentIdsInUpdate.has(rec.studentId))
      );

      const newRecords: AttendanceRecord[] = records.map((r) => ({
        id: `att-${r.studentId}-${date}`,
        studentId: r.studentId,
        batchId: batchId,
        date: date,
        status: r.status,
        timestamp: timestamp,
        remarks: r.remarks,
        updatedAt: timestamp,
      }));

      const consolidated = [...filtered, ...newRecords];
      saveStoredData({ attendance: consolidated });

      // Sync each record to cloud
      newRecords.forEach((rec) => {
        syncService.syncDocument('attendance', rec.id, rec);
      });

      return consolidated;
    });

    addToast({
      type: 'success',
      title: 'Attendance Saved',
      message: `Saved attendance for ${records.length} students on ${date}.`,
    });
  };

  // Payment Actions: MANDATORY CASH ONLY
  const recordPayment = (
    paymentData: Omit<FeePayment, 'id' | 'receiptNo' | 'recordedAt' | 'paymentMode'>
  ): FeePayment => {
    const count = payments.length + 1;
    const year = new Date().getFullYear();
    const receiptNo = `${settings.receiptPrefix || 'CF'}-${year}-${String(count).padStart(4, '0')}`;
    const id = `pay-${Date.now()}`;
    const recordedAt = new Date().toISOString();

    const newPayment: FeePayment = {
      ...paymentData,
      id,
      receiptNo,
      paymentMode: 'Cash' as const, // Strict Cash Only
      recordedAt,
      updatedAt: recordedAt,
    };

    setPayments((prev) => {
      const updated = [newPayment, ...prev];
      saveStoredData({ payments: updated });
      return updated;
    });

    syncService.syncDocument('payments', id, newPayment);

    const student = students.find((s) => s.id === paymentData.studentId);
    addToast({
      type: 'success',
      title: 'Cash Payment Recorded',
      message: `Received ₹${paymentData.amount.toLocaleString()} in cash for ${student?.name || 'Student'}. Receipt #${receiptNo} generated.`,
    });

    return newPayment;
  };

  const deletePayment = (paymentId: string) => {
    setPayments((prev) => {
      const updated = prev.filter((p) => p.id !== paymentId);
      saveStoredData({ payments: updated });
      return updated;
    });

    syncService.syncDocument('payments', paymentId, null, true);

    addToast({
      type: 'info',
      title: 'Payment Deleted',
      message: 'Receipt and payment record removed.',
    });
  };

  // Test Actions
  const addTest = (testData: Omit<ClassTest, 'id'>) => {
    const id = `test-${Date.now()}`;
    const newTest: ClassTest = {
      ...testData,
      id,
      updatedAt: new Date().toISOString(),
    };

    setTests((prev) => {
      const updated = [newTest, ...prev];
      saveStoredData({ tests: updated });
      return updated;
    });

    syncService.syncDocument('tests', id, newTest);

    addToast({
      type: 'success',
      title: 'Test Scheduled',
      message: `Test "${newTest.title}" created.`,
    });
  };

  const updateTest = (id: string, updates: Partial<ClassTest>) => {
    const updatedAt = new Date().toISOString();
    let updatedTest: ClassTest | undefined;

    setTests((prev) => {
      const updated = prev.map((t) => {
        if (t.id === id) {
          updatedTest = { ...t, ...updates, updatedAt };
          return updatedTest;
        }
        return t;
      });
      saveStoredData({ tests: updated });
      return updated;
    });

    if (updatedTest) {
      syncService.syncDocument('tests', id, updatedTest);
    }
  };

  const deleteTest = (testId: string) => {
    setTests((prev) => {
      const updated = prev.filter((t) => t.id !== testId);
      saveStoredData({ tests: updated });
      return updated;
    });

    syncService.syncDocument('tests', testId, null, true);

    // Also delete associated results
    setTestResults((prev) => {
      const filtered = prev.filter((r) => r.testId !== testId);
      saveStoredData({ testResults: filtered });
      return filtered;
    });

    addToast({
      type: 'info',
      title: 'Test Deleted',
      message: 'Test and associated marks removed.',
    });
  };

  const saveTestResults = (
    testId: string,
    results: { studentId: string; marksObtained: number; remarks?: string }[]
  ) => {
    const timestamp = new Date().toISOString();

    setTestResults((prev) => {
      const studentIdsInUpdate = new Set(results.map((r) => r.studentId));
      const filtered = prev.filter(
        (r) => !(r.testId === testId && studentIdsInUpdate.has(r.studentId))
      );

      const newResults: TestResult[] = results.map((r) => ({
        id: `tr-${testId}-${r.studentId}`,
        testId,
        studentId: r.studentId,
        marksObtained: r.marksObtained,
        remarks: r.remarks,
        updatedAt: timestamp,
      }));

      const consolidated = [...filtered, ...newResults];
      saveStoredData({ testResults: consolidated });

      newResults.forEach((tr) => {
        syncService.syncDocument('testResults', tr.id, tr);
      });

      return consolidated;
    });

    addToast({
      type: 'success',
      title: 'Marks Saved',
      message: `Saved test marks for ${results.length} students.`,
    });
  };

  // Settings Actions
  const updateSettings = (newSettings: Partial<InstituteSettings>) => {
    const updatedAt = new Date().toISOString();
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings, updatedAt };
      saveStoredData({ settings: updated });
      syncService.syncDocument('settings', 'main', updated);
      return updated;
    });

    addToast({
      type: 'success',
      title: 'Settings Saved',
      message: 'Institute profile updated and backed up.',
    });
  };

  const resetAllData = () => {
    const sample = resetToSampleData();
    setStudents(sample.students);
    setBatches(sample.batches);
    setAttendance(sample.attendance);
    setPayments(sample.payments);
    setSettings(sample.settings);
    setTests(sample.tests);
    setTestResults(sample.testResults);

    addToast({
      type: 'info',
      title: 'Data Reset',
      message: 'Sample institute records loaded successfully.',
    });
  };

  const importAllData = (jsonData: any): boolean => {
    try {
      if (!jsonData || !Array.isArray(jsonData.students) || !Array.isArray(jsonData.batches)) {
        throw new Error('Invalid ClassFlow backup JSON file.');
      }
      setStudents(jsonData.students);
      setBatches(jsonData.batches);
      if (Array.isArray(jsonData.attendance)) setAttendance(jsonData.attendance);
      if (Array.isArray(jsonData.payments)) {
        // Enforce Cash Only on import
        const cashOnlyPayments = jsonData.payments.map((p: any) => ({
          ...p,
          paymentMode: 'Cash' as const,
        }));
        setPayments(cashOnlyPayments);
      }
      if (jsonData.settings) setSettings(jsonData.settings);
      if (Array.isArray(jsonData.tests)) setTests(jsonData.tests);
      if (Array.isArray(jsonData.testResults)) setTestResults(jsonData.testResults);

      saveStoredData(jsonData);

      addToast({
        type: 'success',
        title: 'Backup Restored',
        message: 'Successfully imported institute database.',
      });
      return true;
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Import Failed',
        message: err?.message || 'Failed to parse JSON file.',
      });
      return false;
    }
  };

  // Helpers
  const getBatchById = (batchId: string) => batches.find((b) => b.id === batchId);
  const getStudentById = (studentId: string) => students.find((s) => s.id === studentId);

  // Student Fee Summaries for the current month
  const studentFeeSummaries = useMemo<StudentFeeSummary[]>(() => {
    const todayDay = new Date().getDate();
    const isDuePassed = todayDay > (settings.defaultFeeDueDay || 5);

    return students.map((student) => {
      const batch = batches.find((b) => b.id === student.batchId);
      const studentPayments = payments.filter((p) => p.studentId === student.id);

      const paidThisMonth = studentPayments
        .filter((p) => p.monthFor === currentMonth)
        .reduce((sum, p) => sum + p.amount, 0);

      const totalAllTimePaid = studentPayments.reduce((sum, p) => sum + p.amount, 0);
      const totalDueThisMonth = student.monthlyFee;
      const balanceThisMonth = Math.max(0, totalDueThisMonth - paidThisMonth);

      let status: 'paid' | 'partial' | 'pending' = 'pending';
      if (balanceThisMonth <= 0) {
        status = 'paid';
      } else if (paidThisMonth > 0) {
        status = 'partial';
      } else {
        status = 'pending';
      }

      return {
        student,
        batch,
        totalDueThisMonth,
        paidThisMonth,
        balanceThisMonth,
        totalAllTimePaid,
        isOverdue: isDuePassed && balanceThisMonth > 0 && student.isActive,
        status,
      };
    });
  }, [students, batches, payments, currentMonth, settings.defaultFeeDueDay]);

  // Attendance summary per student
  const getStudentAttendanceSummary = (studentId: string, monthKey?: string): StudentAttendanceSummary => {
    const student = students.find((s) => s.id === studentId);
    const batch = student ? batches.find((b) => b.id === student.batchId) : undefined;

    let records = attendance.filter((r) => r.studentId === studentId);
    if (monthKey) {
      records = records.filter((r) => r.date.startsWith(monthKey));
    }

    const totalDays = records.length;
    const presentDays = records.filter((r) => r.status === 'present').length;
    const absentDays = records.filter((r) => r.status === 'absent').length;
    const lateDays = records.filter((r) => r.status === 'late').length;
    const percentage = totalDays > 0 ? Math.round(((presentDays + lateDays) / totalDays) * 100) : 0;

    return {
      student: student || ({ id: studentId, name: 'Unknown' } as Student),
      batch,
      totalDays,
      presentDays,
      absentDays,
      lateDays,
      percentage,
    };
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        students,
        batches,
        attendance,
        payments,
        settings,
        tests,
        testResults,
        toasts,
        currentMonth,
        todayDate,
        authUser,
        authLoading,
        syncStatus,
        syncMessage,
        loginWithGoogle,
        logout,
        continueAsOfflineDemo,
        manualSyncNow,
        selectedStudentId,
        setSelectedStudentId,
        isAddStudentModalOpen,
        setIsAddStudentModalOpen,
        editingStudent,
        setEditingStudent,
        isRecordPaymentModalOpen,
        setIsRecordPaymentModalOpen,
        preselectedPaymentStudentId,
        setPreselectedPaymentStudentId,
        receiptModalPayment,
        setReceiptModalPayment,
        whatsAppModalData,
        setWhatsAppModalData,
        addToast,
        removeToast,
        addStudent,
        updateStudent,
        toggleStudentStatus,
        deleteStudent,
        addBatch,
        updateBatch,
        deleteBatch,
        saveAttendance,
        recordPayment,
        deletePayment,
        addTest,
        updateTest,
        deleteTest,
        saveTestResults,
        updateSettings,
        resetAllData,
        importAllData,
        studentFeeSummaries,
        getStudentAttendanceSummary,
        getBatchById,
        getStudentById,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
