import {
  Student,
  Batch,
  AttendanceRecord,
  FeePayment,
  InstituteSettings,
  ClassTest,
  TestResult,
} from '../types';

const STORAGE_KEYS = {
  STUDENTS: 'classflow_students_v1',
  BATCHES: 'classflow_batches_v1',
  ATTENDANCE: 'classflow_attendance_v1',
  PAYMENTS: 'classflow_payments_v1',
  SETTINGS: 'classflow_settings_v1',
  TESTS: 'classflow_tests_v1',
  TEST_RESULTS: 'classflow_test_results_v1',
  OFFLINE_QUEUE: 'classflow_offline_queue_v1',
};

export const DEFAULT_SETTINGS: InstituteSettings = {
  name: 'Lakshya Classes & Tutorials',
  tagline: 'Nurturing Academic Excellence',
  ownerName: 'Er. Rajesh Tiwari',
  contactNumber: '9876543210',
  email: 'lakshya.classes@gmail.com',
  address: 'Shop 14, 2nd Floor, Sai Complex, Station Road, Kota, Rajasthan',
  currencySymbol: '₹',
  defaultFeeDueDay: 5,
  receiptPrefix: 'CF',
};

export const DEFAULT_BATCHES: Batch[] = [
  {
    id: 'batch-10-sci-math',
    name: 'Class 10th - Science & Maths',
    subject: 'Science & Maths (CBSE/State)',
    timing: '4:00 PM - 5:30 PM',
    days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'batch-12-phys-chem',
    name: 'Class 12th - Physics & Chemistry',
    subject: 'Senior Board Prep',
    timing: '5:45 PM - 7:15 PM',
    days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'batch-9-math',
    name: 'Class 9th - Mathematics Foundation',
    subject: 'Mathematics',
    timing: '3:00 PM - 4:00 PM',
    days: ['Tue', 'Thu', 'Sat'],
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'batch-jee-prep',
    name: 'JEE / NEET Fast-Track Morning',
    subject: 'Physics, Chem & Math Problems',
    timing: '6:30 AM - 8:00 AM',
    days: ['Mon', 'Wed', 'Fri', 'Sat'],
    updatedAt: new Date().toISOString(),
  },
];

export const DEFAULT_STUDENTS: Student[] = [
  {
    id: 'std-1',
    rollNo: '101',
    name: 'Aarav Sharma',
    batchId: 'batch-10-sci-math',
    parentName: 'Sanjay Sharma',
    parentContact: '9823456781',
    monthlyFee: 2000,
    admissionDate: '2026-06-15',
    isActive: true,
    notes: 'Excels in Algebra. Needs focus in Physics numericals.',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'std-2',
    rollNo: '102',
    name: 'Ananya Patel',
    batchId: 'batch-10-sci-math',
    parentName: 'Bhavesh Patel',
    parentContact: '9876512340',
    monthlyFee: 2000,
    admissionDate: '2026-06-18',
    isActive: true,
    notes: 'Very punctual and consistent test scorer.',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'std-3',
    rollNo: '103',
    name: 'Rohan Gupta',
    batchId: 'batch-10-sci-math',
    parentName: 'Manoj Gupta',
    parentContact: '9711223344',
    monthlyFee: 2000,
    admissionDate: '2026-07-01',
    isActive: true,
    notes: 'Cash receipt collected by parent at counter.',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'std-4',
    rollNo: '104',
    name: 'Priya Verma',
    batchId: 'batch-10-sci-math',
    parentName: 'Sunil Verma',
    parentContact: '9988776655',
    monthlyFee: 2000,
    admissionDate: '2026-07-05',
    isActive: true,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'std-5',
    rollNo: '105',
    name: 'Aditya Singh',
    batchId: 'batch-10-sci-math',
    parentName: 'Dharmendra Singh',
    parentContact: '9822334455',
    monthlyFee: 2000,
    admissionDate: '2026-07-10',
    isActive: true,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'std-6',
    rollNo: '201',
    name: 'Tanvi Deshmukh',
    batchId: 'batch-12-phys-chem',
    parentName: 'Anil Deshmukh',
    parentContact: '9922114433',
    monthlyFee: 3200,
    admissionDate: '2026-05-10',
    isActive: true,
    notes: 'Aiming for 95%+ in Board Exams.',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'std-7',
    rollNo: '202',
    name: 'Ayush Tiwari',
    batchId: 'batch-12-phys-chem',
    parentName: 'Vinod Tiwari',
    parentContact: '9833445566',
    monthlyFee: 3200,
    admissionDate: '2026-05-15',
    isActive: true,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'std-8',
    rollNo: '203',
    name: 'Sneha Kulkarni',
    batchId: 'batch-12-phys-chem',
    parentName: 'Milind Kulkarni',
    parentContact: '9766554433',
    monthlyFee: 3200,
    admissionDate: '2026-06-01',
    isActive: true,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'std-9',
    rollNo: '204',
    name: 'Vikram Malhotra',
    batchId: 'batch-12-phys-chem',
    parentName: 'Ashok Malhotra',
    parentContact: '9811002233',
    monthlyFee: 3200,
    admissionDate: '2026-06-05',
    isActive: true,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'std-10',
    rollNo: '301',
    name: 'Diya Nair',
    batchId: 'batch-9-math',
    parentName: 'Pradeep Nair',
    parentContact: '9845012345',
    monthlyFee: 1500,
    admissionDate: '2026-08-01',
    isActive: true,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'std-11',
    rollNo: '302',
    name: 'Devansh Joshi',
    batchId: 'batch-9-math',
    parentName: 'Hemant Joshi',
    parentContact: '9890123456',
    monthlyFee: 1500,
    admissionDate: '2026-08-10',
    isActive: true,
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'std-12',
    rollNo: '401',
    name: 'Ritu Sharma',
    batchId: 'batch-jee-prep',
    parentName: 'Devraj Sharma',
    parentContact: '9819988776',
    monthlyFee: 4000,
    admissionDate: '2026-04-12',
    isActive: true,
    updatedAt: new Date().toISOString(),
  },
];

const today = new Date();
const formatDateKey = (d: Date) => d.toISOString().split('T')[0];
const todayStr = formatDateKey(today);

export const generateSampleAttendance = (): AttendanceRecord[] => {
  const records: AttendanceRecord[] = [];
  const dates: string[] = [];

  for (let i = 0; i <= 6; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    if (d.getDay() !== 0) {
      dates.push(formatDateKey(d));
    }
  }

  DEFAULT_STUDENTS.forEach((student, sIdx) => {
    dates.forEach((date, dIdx) => {
      const isToday = date === todayStr;
      let status: 'present' | 'absent' | 'late' = 'present';

      if (isToday) {
        if (sIdx === 2 || sIdx === 7) {
          status = 'absent';
        } else if (sIdx === 4) {
          status = 'late';
        } else {
          status = 'present';
        }
      } else {
        const hash = (sIdx * 7 + dIdx * 13) % 10;
        if (hash === 1) status = 'absent';
        else if (hash === 2) status = 'late';
        else status = 'present';
      }

      records.push({
        id: `att-${student.id}-${date}`,
        studentId: student.id,
        batchId: student.batchId,
        date: date,
        status: status,
        timestamp: new Date().toISOString(),
        remarks: status === 'absent' ? 'Parent informed via call' : undefined,
        updatedAt: new Date().toISOString(),
      });
    });
  });

  return records;
};

// All payments are strictly Cash Only
export const generateSamplePayments = (): FeePayment[] => {
  const currentMonth = today.toISOString().substring(0, 7);

  return [
    {
      id: 'pay-1',
      receiptNo: 'CF-2026-0081',
      studentId: 'std-1',
      amount: 2000,
      date: `${currentMonth}-05`,
      monthFor: currentMonth,
      paymentMode: 'Cash',
      remarks: 'Cash received at front desk',
      recordedAt: `${currentMonth}-05T17:30:00Z`,
      updatedAt: `${currentMonth}-05T17:30:00Z`,
    },
    {
      id: 'pay-2',
      receiptNo: 'CF-2026-0082',
      studentId: 'std-2',
      amount: 2000,
      date: `${currentMonth}-04`,
      monthFor: currentMonth,
      paymentMode: 'Cash',
      remarks: 'Full cash fees paid by student',
      recordedAt: `${currentMonth}-04T16:15:00Z`,
      updatedAt: `${currentMonth}-04T16:15:00Z`,
    },
    {
      id: 'pay-3',
      receiptNo: 'CF-2026-0083',
      studentId: 'std-4',
      amount: 2000,
      date: `${currentMonth}-07`,
      monthFor: currentMonth,
      paymentMode: 'Cash',
      remarks: 'Cash handed by father',
      recordedAt: `${currentMonth}-07T11:00:00Z`,
      updatedAt: `${currentMonth}-07T11:00:00Z`,
    },
    {
      id: 'pay-4',
      receiptNo: 'CF-2026-0084',
      studentId: 'std-6',
      amount: 3200,
      date: `${currentMonth}-03`,
      monthFor: currentMonth,
      paymentMode: 'Cash',
      remarks: 'Cash deposited at counter',
      recordedAt: `${currentMonth}-03T19:20:00Z`,
      updatedAt: `${currentMonth}-03T19:20:00Z`,
    },
    {
      id: 'pay-5',
      receiptNo: 'CF-2026-0085',
      studentId: 'std-7',
      amount: 1500, // Part payment
      date: `${currentMonth}-08`,
      monthFor: currentMonth,
      paymentMode: 'Cash',
      remarks: 'Part payment in cash. Promised remaining balance soon.',
      recordedAt: `${currentMonth}-08T18:00:00Z`,
      updatedAt: `${currentMonth}-08T18:00:00Z`,
    },
    {
      id: 'pay-6',
      receiptNo: 'CF-2026-0086',
      studentId: 'std-10',
      amount: 1500,
      date: `${currentMonth}-05`,
      monthFor: currentMonth,
      paymentMode: 'Cash',
      remarks: 'Cash paid in full',
      recordedAt: `${currentMonth}-05T14:40:00Z`,
      updatedAt: `${currentMonth}-05T14:40:00Z`,
    },
    {
      id: 'pay-7',
      receiptNo: 'CF-2026-0087',
      studentId: 'std-12',
      amount: 4000,
      date: `${currentMonth}-02`,
      monthFor: currentMonth,
      paymentMode: 'Cash',
      remarks: 'Cash received by director',
      recordedAt: `${currentMonth}-02T10:15:00Z`,
      updatedAt: `${currentMonth}-02T10:15:00Z`,
    },
  ];
};

export const generateSampleTests = (): { tests: ClassTest[]; testResults: TestResult[] } => {
  const currentMonth = today.toISOString().substring(0, 7);
  const tests: ClassTest[] = [
    {
      id: 'test-1',
      batchId: 'batch-10-sci-math',
      title: 'Quadratic Equations & Electricity Unit Test',
      subject: 'Maths & Physics',
      date: `${currentMonth}-10`,
      totalMarks: 50,
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'test-2',
      batchId: 'batch-12-phys-chem',
      title: 'Electrostatics & Solutions Chapter Test',
      subject: 'Physics & Chemistry',
      date: `${currentMonth}-12`,
      totalMarks: 100,
      updatedAt: new Date().toISOString(),
    },
  ];

  const testResults: TestResult[] = [
    { id: 'tr-1', testId: 'test-1', studentId: 'std-1', marksObtained: 46, remarks: 'Excellent score', updatedAt: new Date().toISOString() },
    { id: 'tr-2', testId: 'test-1', studentId: 'std-2', marksObtained: 48, remarks: 'Class topper', updatedAt: new Date().toISOString() },
    { id: 'tr-3', testId: 'test-1', studentId: 'std-3', marksObtained: 38, remarks: 'Good work', updatedAt: new Date().toISOString() },
    { id: 'tr-4', testId: 'test-1', studentId: 'std-4', marksObtained: 42, remarks: 'Very good', updatedAt: new Date().toISOString() },
    { id: 'tr-5', testId: 'test-1', studentId: 'std-5', marksObtained: 35, remarks: 'Needs more practice in word problems', updatedAt: new Date().toISOString() },
    { id: 'tr-6', testId: 'test-2', studentId: 'std-6', marksObtained: 92, remarks: 'Outstanding preparation', updatedAt: new Date().toISOString() },
    { id: 'tr-7', testId: 'test-2', studentId: 'std-7', marksObtained: 74, remarks: 'Consistent effort', updatedAt: new Date().toISOString() },
    { id: 'tr-8', testId: 'test-2', studentId: 'std-8', marksObtained: 88, remarks: 'High accuracy', updatedAt: new Date().toISOString() },
  ];

  return { tests, testResults };
};

// Safe load and migration to Cash Only
export const getStoredData = () => {
  try {
    const rawStudents = localStorage.getItem(STORAGE_KEYS.STUDENTS);
    const rawBatches = localStorage.getItem(STORAGE_KEYS.BATCHES);
    const rawAttendance = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
    const rawPayments = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
    const rawSettings = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    const rawTests = localStorage.getItem(STORAGE_KEYS.TESTS);
    const rawTestResults = localStorage.getItem(STORAGE_KEYS.TEST_RESULTS);

    const students: Student[] = rawStudents ? JSON.parse(rawStudents) : DEFAULT_STUDENTS;
    const batches: Batch[] = rawBatches ? JSON.parse(rawBatches) : DEFAULT_BATCHES;
    const attendance: AttendanceRecord[] = rawAttendance
      ? JSON.parse(rawAttendance)
      : generateSampleAttendance();

    // CRITICAL REQUIREMENT 2: Cash Only migration
    // Safely migrate any existing payment records so paymentMode is strictly 'Cash'
    let payments: FeePayment[] = rawPayments
      ? JSON.parse(rawPayments)
      : generateSamplePayments();

    let migrated = false;
    payments = payments.map((p) => {
      if (p.paymentMode !== 'Cash') {
        migrated = true;
        return {
          ...p,
          paymentMode: 'Cash' as const,
          remarks: p.remarks ? p.remarks.replace(/UPI|Bank Transfer|Cheque/gi, 'Cash') : undefined,
        };
      }
      return p;
    });

    if (migrated) {
      localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
    }

    let settings: InstituteSettings = rawSettings ? JSON.parse(rawSettings) : DEFAULT_SETTINGS;
    // Remove upiId if previously stored
    if ((settings as any).upiId !== undefined) {
      delete (settings as any).upiId;
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    }

    const sampleTests = generateSampleTests();
    const tests: ClassTest[] = rawTests ? JSON.parse(rawTests) : sampleTests.tests;
    const testResults: TestResult[] = rawTestResults
      ? JSON.parse(rawTestResults)
      : sampleTests.testResults;

    return { students, batches, attendance, payments, settings, tests, testResults };
  } catch (err) {
    console.error('Error loading ClassFlow data:', err);
    const sampleTests = generateSampleTests();
    return {
      students: DEFAULT_STUDENTS,
      batches: DEFAULT_BATCHES,
      attendance: generateSampleAttendance(),
      payments: generateSamplePayments(),
      settings: DEFAULT_SETTINGS,
      tests: sampleTests.tests,
      testResults: sampleTests.testResults,
    };
  }
};

export const saveStoredData = (data: {
  students?: Student[];
  batches?: Batch[];
  attendance?: AttendanceRecord[];
  payments?: FeePayment[];
  settings?: InstituteSettings;
  tests?: ClassTest[];
  testResults?: TestResult[];
}) => {
  try {
    if (data.students) localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(data.students));
    if (data.batches) localStorage.setItem(STORAGE_KEYS.BATCHES, JSON.stringify(data.batches));
    if (data.attendance) localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(data.attendance));
    if (data.payments) {
      // Ensure all saved payments are Cash
      const cashPayments = data.payments.map((p) => ({
        ...p,
        paymentMode: 'Cash' as const,
      }));
      localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(cashPayments));
    }
    if (data.settings) localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(data.settings));
    if (data.tests) localStorage.setItem(STORAGE_KEYS.TESTS, JSON.stringify(data.tests));
    if (data.testResults)
      localStorage.setItem(STORAGE_KEYS.TEST_RESULTS, JSON.stringify(data.testResults));
  } catch (err) {
    console.error('Error saving ClassFlow data:', err);
  }
};

export const resetToSampleData = () => {
  const sampleTests = generateSampleTests();
  const sample = {
    students: DEFAULT_STUDENTS,
    batches: DEFAULT_BATCHES,
    attendance: generateSampleAttendance(),
    payments: generateSamplePayments(),
    settings: DEFAULT_SETTINGS,
    tests: sampleTests.tests,
    testResults: sampleTests.testResults,
  };
  saveStoredData(sample);
  return sample;
};

// Offline Queue helpers
export interface OfflineMutation {
  id: string;
  type: 'upsert' | 'delete';
  collectionName: 'settings' | 'batches' | 'students' | 'attendance' | 'payments' | 'tests' | 'testResults';
  documentId: string;
  data?: any;
  timestamp: string;
}

export const getOfflineQueue = (): OfflineMutation[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.OFFLINE_QUEUE);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

export const saveOfflineQueue = (queue: OfflineMutation[]) => {
  try {
    localStorage.setItem(STORAGE_KEYS.OFFLINE_QUEUE, JSON.stringify(queue));
  } catch (err) {
    console.error('Failed to save offline queue:', err);
  }
};
