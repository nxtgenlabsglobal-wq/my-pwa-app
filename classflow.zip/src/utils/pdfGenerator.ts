import jsPDF from 'jspdf';
import { FeePayment, Student, Batch, InstituteSettings } from '../types';
import { formatCurrency, formatDate, formatMonthName } from './formatters';

export const generateReceiptPDF = (
  payment: FeePayment,
  student: Student,
  batch: Batch | undefined,
  remainingBalance: number,
  settings: InstituteSettings
) => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a5', // A5 standard tuition fee voucher
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  // Background subtle tint & clean border
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.setLineWidth(0.5);
  doc.roundedRect(8, 8, pageWidth - 16, 194, 3, 3, 'S');

  // Header Bar
  doc.setFillColor(15, 23, 42); // slate-900 / navy
  doc.rect(8, 8, pageWidth - 16, 26, 'F');

  // Institute Name
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(15);
  doc.setFont('helvetica', 'bold');
  doc.text(settings.name.toUpperCase(), pageWidth / 2, 17, { align: 'center' });

  // Institute Tagline
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(settings.tagline, pageWidth / 2, 23, { align: 'center' });

  doc.setFontSize(7.5);
  doc.text(
    `${settings.address} | Ph: ${settings.contactNumber}`,
    pageWidth / 2,
    29,
    { align: 'center' }
  );

  // Receipt Badge Banner
  doc.setFillColor(239, 246, 255); // blue-50
  doc.setDrawColor(191, 219, 254); // blue-200
  doc.roundedRect(12, 38, pageWidth - 24, 11, 1.5, 1.5, 'FD');

  doc.setTextColor(30, 64, 175); // blue-800
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('CASH FEE PAYMENT RECEIPT', 16, 45);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`Receipt No: ${payment.receiptNo}`, pageWidth - 16, 45, { align: 'right' });

  // Metadata Box (Date & Month)
  doc.setTextColor(71, 85, 105);
  doc.setFontSize(8.5);
  doc.text(`Date of Payment: ${formatDate(payment.date)}`, 14, 56);
  doc.text(`Fee For: ${formatMonthName(payment.monthFor)}`, pageWidth - 14, 56, { align: 'right' });

  // Student Information Box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(12, 60, pageWidth - 24, 32, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(8.5);
  doc.text('STUDENT INFORMATION', 16, 66);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);

  doc.text(`Student Name:`, 16, 73);
  doc.setFont('helvetica', 'bold');
  doc.text(student.name, 45, 73);

  doc.text(`Roll / ID No:`, 16, 80);
  doc.text(student.rollNo || 'N/A', 45, 80);

  doc.text(`Class / Batch:`, 16, 87);
  doc.text(batch?.name || 'Regular Batch', 45, 87);

  doc.text(`Parent Name:`, 88, 73);
  doc.text(student.parentName || 'Parent / Guardian', 115, 73);

  doc.text(`Contact:`, 88, 80);
  doc.text(student.parentContact || 'N/A', 115, 80);

  doc.text(`Admission Date:`, 88, 87);
  doc.text(formatDate(student.admissionDate), 115, 87);

  // Payment Breakdown Table
  let y = 98;
  doc.setFillColor(241, 245, 249);
  doc.rect(12, y, pageWidth - 24, 8, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(30, 41, 59);
  doc.text('PARTICULARS / DESCRIPTION', 16, y + 5.5);
  doc.text('AMOUNT (INR)', pageWidth - 16, y + 5.5, { align: 'right' });

  y += 8;

  // Monthly Tuition Fee
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);
  doc.text(`Monthly Tuition Fee (${formatMonthName(payment.monthFor)})`, 16, y + 6);
  doc.text(formatCurrency(student.monthlyFee), pageWidth - 16, y + 6, { align: 'right' });

  doc.setDrawColor(241, 245, 249);
  doc.line(12, y + 9, pageWidth - 12, y + 9);
  y += 10;

  // Amount Paid Row (Cash)
  doc.setFillColor(236, 253, 245); // emerald-50
  doc.rect(12, y, pageWidth - 24, 9, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(6, 95, 70); // emerald-800
  doc.text(`CASH RECEIVED (Paid in Full/Part)`, 16, y + 6);
  doc.text(formatCurrency(payment.amount), pageWidth - 16, y + 6, { align: 'right' });

  y += 11;

  // Remaining Balance Row
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(remainingBalance > 0 ? 185 : 71, remainingBalance > 0 ? 28 : 85, remainingBalance > 0 ? 28 : 105);
  doc.text(`Outstanding / Balance Due:`, 16, y + 5);
  doc.setFont('helvetica', 'bold');
  doc.text(formatCurrency(remainingBalance), pageWidth - 16, y + 5, { align: 'right' });

  y += 9;

  // Payment Mode and Details: Cash Only
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(12, y, pageWidth - 24, 18, 1.5, 1.5, 'FD');

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.setFontSize(8);
  doc.text(`Payment Mode:`, 16, y + 6);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('Cash Payment at Institute Counter', 45, y + 6);

  if (payment.remarks) {
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text(`Notes: ${payment.remarks}`, 16, y + 12);
  }

  // Footer notes & Stamp/Signature
  y += 28;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.text('Note: This is an official cash payment receipt voucher.', 14, y);
  doc.text('Fees once paid are non-refundable and non-transferable.', 14, y + 4);

  // Signature Block
  doc.setDrawColor(148, 163, 184);
  doc.line(pageWidth - 55, y + 8, pageWidth - 16, y + 8);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(30, 41, 59);
  doc.text('Cashier / Authorized Signatory', pageWidth - 35, y + 12, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.text(settings.name, pageWidth - 35, y + 15, { align: 'center' });

  // Save the PDF
  const filename = `Cash_Receipt_${payment.receiptNo}_${student.name.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`;
  doc.save(filename);
};

export const generateReportPDF = (
  reportTitle: string,
  headers: string[],
  rows: (string | number)[][],
  settings: InstituteSettings,
  summaryNotes?: string
) => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  // Header
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageWidth, 28, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(settings.name, 14, 12);

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.text(`${settings.address} | Ph: ${settings.contactNumber}`, 14, 18);
  doc.text(`Generated on: ${formatDate(new Date().toISOString().split('T')[0])}`, 14, 23);

  // Report Title
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text(reportTitle.toUpperCase(), 14, 38);

  if (summaryNotes) {
    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(71, 85, 105);
    doc.text(summaryNotes, 14, 44);
  }

  // Simple Table
  let y = summaryNotes ? 50 : 44;
  const colWidth = (pageWidth - 28) / headers.length;

  // Table Header
  doc.setFillColor(241, 245, 249);
  doc.rect(14, y, pageWidth - 28, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(30, 41, 59);

  headers.forEach((h, idx) => {
    doc.text(h, 16 + idx * colWidth, y + 5.5);
  });

  y += 8;

  // Table Body
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);

  rows.forEach((row) => {
    if (y > 275) {
      doc.addPage();
      y = 20;
    }

    doc.setTextColor(51, 65, 85);
    doc.setDrawColor(241, 245, 249);
    doc.line(14, y + 7, pageWidth - 14, y + 7);

    row.forEach((val, cIdx) => {
      doc.text(String(val), 16 + cIdx * colWidth, y + 5);
    });

    y += 7.5;
  });

  doc.save(`${reportTitle.replace(/[^a-zA-Z0-9]/g, '_')}_ClassFlow.pdf`);
};
