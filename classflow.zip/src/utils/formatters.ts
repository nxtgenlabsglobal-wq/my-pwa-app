import { Student, Batch, FeePayment, InstituteSettings, ClassTest, TestResult } from '../types';

export const formatCurrency = (amount: number, symbol = '₹'): string => {
  if (isNaN(amount)) return `${symbol}0`;
  const formatted = new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 0,
  }).format(amount);
  return `${symbol}${formatted}`;
};

export const formatDate = (dateStr: string): string => {
  if (!dateStr) return '';
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      const d = new Date(year, month, day);
      return d.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });
    }
    const d = new Date(dateStr);
    return isNaN(d.getTime())
      ? dateStr
      : d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return dateStr;
  }
};

export const formatMonthName = (monthKey: string): string => {
  if (!monthKey || !monthKey.includes('-')) return monthKey;
  const [year, month] = monthKey.split('-');
  const d = new Date(parseInt(year, 10), parseInt(month, 10) - 1, 1);
  return d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
};

export const cleanPhoneNumber = (phone: string): string => {
  const digits = phone.replace(/\D/g, '');
  if (digits.length === 10) return `91${digits}`;
  if (digits.length === 12 && digits.startsWith('91')) return digits;
  return digits;
};

// Cash only: No UPI / online payment mentions
export const generateWhatsAppFeeReminder = (
  student: Student,
  batch: Batch | undefined,
  pendingAmount: number,
  settings: InstituteSettings,
  monthName: string,
  dueDateStr: string
): string => {
  return `*Fee Reminder - ${settings.name}*

Dear Parent,
This is a gentle reminder regarding tuition fees for *${student.name}* (${batch?.name || 'Class'}).

• *Month:* ${monthName}
• *Pending Amount:* ${formatCurrency(pendingAmount, settings.currencySymbol)}
• *Due Date:* ${dueDateStr}
• *Payment Mode:* Cash at Institute Counter

Kindly deposit the pending cash fee at the institute counter by the due date. If already paid, please ignore this message.

Thank you,
*${settings.name}*
${settings.contactNumber ? `Contact: ${settings.contactNumber}` : ''}`;
};

// Cash only receipt
export const generateWhatsAppReceiptMessage = (
  payment: FeePayment,
  student: Student,
  batch: Batch | undefined,
  remainingBalance: number,
  settings: InstituteSettings
): string => {
  return `*Cash Fee Payment Receipt - ${settings.name}*

Dear Parent,
We have received the cash tuition fee for *${student.name}* (${batch?.name || 'Class'}).

• *Receipt No:* ${payment.receiptNo}
• *Amount Paid:* ${formatCurrency(payment.amount, settings.currencySymbol)} (Cash)
• *Payment Date:* ${formatDate(payment.date)}
• *Month:* ${formatMonthName(payment.monthFor)}
• *Remaining Balance:* ${formatCurrency(remainingBalance, settings.currencySymbol)}

Thank you for your timely payment!

*${settings.name}*
${settings.address ? `${settings.address}\n` : ''}${settings.contactNumber ? `Ph: ${settings.contactNumber}` : ''}`;
};

export const generateWhatsAppAttendanceMessage = (
  student: Student,
  batch: Batch | undefined,
  status: 'present' | 'absent' | 'late',
  date: string,
  settings: InstituteSettings
): string => {
  const statusLabel =
    status === 'present'
      ? '✅ PRESENT'
      : status === 'absent'
      ? '❌ ABSENT'
      : '⚠️ LATE';

  return `*Attendance Update - ${settings.name}*

Dear Parent,
This is to notify you that *${student.name}* was marked *${statusLabel}* for *${batch?.name || 'Class'}* on *${formatDate(date)}*.

${status === 'absent' ? 'Please ensure regular attendance for academic progress. If you have an update, kindly contact us.' : ''}

Regards,
*${settings.name}*
Ph: ${settings.contactNumber}`;
};

// Test Marks Report WhatsApp template
export const generateWhatsAppTestReport = (
  student: Student,
  batch: Batch | undefined,
  test: ClassTest,
  result: TestResult | undefined,
  settings: InstituteSettings
): string => {
  const marks = result?.marksObtained ?? 0;
  const pct = Math.round((marks / (test.totalMarks || 100)) * 100);

  return `*Test Performance Report - ${settings.name}*

Dear Parent,
Here is the performance report for *${student.name}* (${batch?.name || 'Class'}).

• *Test Title:* ${test.title}
• *Subject:* ${test.subject}
• *Test Date:* ${formatDate(test.date)}
• *Marks Obtained:* ${marks} / ${test.totalMarks} (${pct}%)
${result?.remarks ? `• *Teacher's Note:* ${result.remarks}\n` : ''}
Please encourage ${student.name} to maintain regular study and practice.

Warm regards,
*${settings.name}*
Ph: ${settings.contactNumber}`;
};

export const getWhatsAppUrl = (phone: string, text: string): string => {
  const cleanPhone = cleanPhoneNumber(phone);
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
};

export const exportToCSV = (filename: string, rows: Record<string, any>[]) => {
  if (!rows || !rows.length) return;
  const separator = ',';
  const keys = Object.keys(rows[0]);
  const csvContent =
    keys.join(separator) +
    '\n' +
    rows
      .map((row) => {
        return keys
          .map((k) => {
            let cell = row[k] === null || row[k] === undefined ? '' : row[k];
            cell = cell instanceof Date ? cell.toLocaleString() : cell.toString();
            cell = cell.replace(/"/g, '""');
            if (cell.search(/("|,|\n)/g) >= 0) cell = `"${cell}"`;
            return cell;
          })
          .join(separator);
      })
      .join('\n');

  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
