import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/navigation/Sidebar';
import { MobileNav } from './components/navigation/MobileNav';
import { ToastContainer } from './components/common/ToastContainer';
import { LoginView } from './components/auth/LoginView';
import { DashboardView } from './components/views/DashboardView';
import { StudentsView } from './components/views/StudentsView';
import { AttendanceView } from './components/views/AttendanceView';
import { FeesView } from './components/views/FeesView';
import { ReportsView } from './components/views/ReportsView';
import { SettingsView } from './components/views/SettingsView';
import { AddStudentModal } from './components/modals/AddStudentModal';
import { RecordPaymentModal } from './components/modals/RecordPaymentModal';
import { StudentProfileModal } from './components/modals/StudentProfileModal';
import { ReceiptModal } from './components/modals/ReceiptModal';
import { WhatsAppModal } from './components/modals/WhatsAppModal';
import { GraduationCap } from 'lucide-react';

const AppContent: React.FC = () => {
  const { activeTab, authUser, authLoading } = useApp();

  // Loading state while checking persistent session
  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 rounded-2xl bg-slate-900 text-white flex items-center justify-center shadow-md shadow-slate-900/10 mb-3 animate-pulse">
          <GraduationCap className="w-6 h-6 text-blue-400" />
        </div>
        <p className="text-sm font-bold text-slate-700">ClassFlow</p>
        <p className="text-xs text-slate-400 mt-1">Checking secure session...</p>
      </div>
    );
  }

  // If not authenticated, show secure Login View
  if (!authUser) {
    return <LoginView />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row antialiased text-slate-900">
      {/* Desktop Navigation Sidebar */}
      <Sidebar />

      {/* Mobile Top Bar & Bottom Navigation */}
      <MobileNav />

      {/* Main Content Viewport */}
      <main className="flex-1 min-w-0 overflow-y-auto">
        <div className="max-w-7xl mx-auto px-3.5 sm:px-6 lg:px-8 py-4 sm:py-6">
          {activeTab === 'dashboard' && <DashboardView />}
          {activeTab === 'students' && <StudentsView />}
          {activeTab === 'attendance' && <AttendanceView />}
          {activeTab === 'fees' && <FeesView />}
          {activeTab === 'reports' && <ReportsView />}
          {activeTab === 'settings' && <SettingsView />}
        </div>
      </main>

      {/* Global Modals & Drawers */}
      <AddStudentModal />
      <RecordPaymentModal />
      <StudentProfileModal />
      <ReceiptModal />
      <WhatsAppModal />

      {/* Toast Notification Container */}
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
